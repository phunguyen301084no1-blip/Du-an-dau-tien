# docx-cli troubleshooting

## `docx: command not found`

The binary isn't on PATH. Install it. The simplest path is npm, if Bun is available:

```sh
bun add -g bun-docx      # or: npm install -g bun-docx   (needs Bun >= 1.3)
```

No Bun? Run `sh SKILL_DIR/scripts/bootstrap.sh` (the folder containing SKILL.md) — it pins to the latest release, downloads
the prebuilt binary, and verifies its SHA-256 against the release's published
`SHA256SUMS` before installing (and, run again, updates a stale install — unless an admin
set `DOCX_CLI_VERSION` or `DOCX_CLI_NO_UPDATE=1`, which keep the present binary).

It **refuses to install** rather than skip verification, so it aborts if the
machine has no `sha256sum`, `shasum`, or `openssl`, if the release publishes no
`SHA256SUMS`, or if the digest doesn't match. Use `bun add -g bun-docx` in that
case. It also aborts — loudly, naming the culprit — when the install lands but
`docx` on PATH still resolves elsewhere.

It installs to `~/.local/bin/docx` by default. Make sure that directory is on
your `PATH` (`export PATH="$HOME/.local/bin:$PATH"`). Set `PREFIX=/usr/local/bin`
before the install to choose another location.

## macOS kills the standalone binary at startup

An invalid code signature can cause a startup kill (reported for v0.25.0 on
macOS 27). Verify the actual standalone executable, not a version-manager shim:

```sh
# For a mise-managed installation:
codesign --verify --strict --verbose=2 "$(mise which docx)"
# For a standalone binary directly on PATH (not a shim):
codesign --verify --strict --verbose=2 "$(command -v docx)"
```

With Bun installed, the package is a fallback. Run its explicit path so an
older mise installation or shim earlier on PATH cannot shadow it:

```sh
bun add -g bun-docx
"$(bun pm bin -g)/docx" --version
```

Use that explicit path for subsequent commands, or adjust PATH and check
`command -v docx` before using the bare command. A binary that cannot start
cannot run `docx upgrade`; reinstall externally when a fixed release is available.
The updated release workflow ad-hoc signs and verifies macOS binaries before
generating `SHA256SUMS`; existing release assets are unchanged. Ad-hoc signing
does not provide Developer ID identity or Apple notarization.

## `docx upgrade` on Windows says `sh` is not on PATH

Upgrade runs its embedded installer with `sh`, so on Windows run it from Git
Bash. Windows won't overwrite a running `.exe`, so it installs into a staging
folder and swaps the verified binary in, leaving the old one as `docx.exe.old`
until the next upgrade. A failed or interrupted upgrade leaves `docx.exe` as it
was.

Windows binaries up to v0.28.0 refuse to upgrade themselves, so replace those by
hand once, or reinstall with `install.sh` from Git Bash.

## `docx render` fails or hangs

`render` is the **only** command that needs an external app. Everything else
operates on the `.docx` zip directly. For `render` you need one of:

- **Word** (macOS or Windows) — highest-fidelity output.
- **LibreOffice** (`soffice`) — cross-platform; auto-used when Word isn't present.

If neither is installed, every other verb still works — you just can't rasterize
pages. And you usually don't need to: `docx read` already proves content changes
through the write→read loop. Render only when the open question is LAYOUT
(columns, page/section breaks, image sizing, table geometry), and then once.

## "Did my change apply?" — read the exit code

Exit code is the contract: `0` ok, `1` error, `2` usage, `3` not-found. Every
command also prints a one-line confirmation, so you never have to re-read just to
learn whether a mutation landed. For the full structured ack, add `--verbose`.

## A locator points at the wrong thing

Block ids (`pN`, `tN`, `sN`, …) are **positional** and shift after structural
edits (insert/delete that add or remove blocks). Two fixes:

1. **Re-read** (`docx read FILE` or `--ast`) after a structural edit to get fresh ids.
2. **Batch** instead: `--batch FILE.jsonl` applies many changes from a single
   read, so every locator stays valid across the whole batch. This is the right
   tool for filling a form or applying a multi-point review.

To get an exact span locator without counting characters, run
`docx find FILE "phrase"` and paste the result into `--at`.

## My literal text got mangled (a URL autolinked, prose got reformatted)

The `--markdown`/`--from` channels parse GFM (+ math + CriticMarkup + inline
HTML), which can transform literal prose. When you need text in **verbatim**, use
the parser-free channel: `insert` and `create` take `--text-file PATH` (`-` =
stdin). Every character lands as-is; each newline starts a new paragraph.

## Accents or CJK text look garbled in PowerShell output

`docx` writes UTF-8, and PowerShell decodes captured output using its own console
encoding, which may be an older code page such as IBM437. The document is fine,
but what you see isn't, so don't write that text back. Set this once per session
before running `docx`, or use Git Bash:

```powershell
[Console]::OutputEncoding = [Text.Encoding]::UTF8
```

## I edited a file and lost some unusual formatting

You shouldn't — docx-cli mutates the underlying XML **in place** and leaves
constructs it doesn't model untouched. If you rebuilt the document instead
(`read` → `create`), that round-trips through a view and can drop what the view
doesn't carry. Prefer in-place `edit`/`replace`/`insert`/`delete` over
read-then-recreate. `git` is your undo (there's no journal).
