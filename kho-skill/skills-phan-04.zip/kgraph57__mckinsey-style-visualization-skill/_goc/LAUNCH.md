# Launch Kit

Use this file to announce releases, collect demand signals, and avoid rewriting launch copy from scratch.

## Launch Goal

Get the skill in front of agent users who create business, strategy, board, investment, or consulting-style materials.

Primary outcome: marketplace listings, GitHub stars, forks, saves, replies, and inbound requests for rendered slide examples or paid templates.

## Prerelease v3.0.0-rc.1

The GitHub preview release is described in [RELEASE.md](RELEASE.md). It includes
the six-page English/Japanese motion editions and static companions. It is not
a stable release or a marketplace submission. No social announcement is sent
by publishing the GitHub release.

## Draft stable release copy — v3.0.0, do not publish

Project Relay demonstrates a restrained interactive decision deck: eight
pages, four purposeful interactions, a deterministic presenter demo, and a
static conclusion that prints to an eight-page PDF. Explicit dynamic requests
build both classic and companion HTML; ordinary and “animated” requests remain
classic. All example values are illustrative.

Automated evidence currently covers Python contracts, Chromium/Firefox
behavior, Chromium visual/PDF checks, deterministic audit output, package
validation, and site drift. Do not change this heading to “released” or send
the copy until the manual/physical/hosted checklist is signed and a v3 tag is
created for the stable release.

## Release Copy (v2.4.0)

Lead with the complete loop: scaffold a template → animated HTML deck → print-to-PDF, then point to the live landing page and the public case study. Attach `assets/readme/demo.gif` (the primary social asset) to every post.

Links to include everywhere:

- Live landing page (the deck plays in the browser): https://kgraph57.github.io/mckinsey-style-visualization-skill/
- Public case study (raw notes → reviewed board slide, 2-minute read): https://github.com/kgraph57/mckinsey-style-visualization-skill/blob/main/examples/case-studies/saas-board-update.md

### Show HN (Hacker News)

```text
Title: Show HN: Scaffold a full consulting-style board deck with one command – animated HTML, print to PDF (zero deps)

v2.4.0 rounds out the presentation system: one deck manifest now
builds four deliverables — an animated deck, an A4 report, a speaker
script, and a top-to-bottom article page. Everything is Python 3
stdlib — no installs, no API keys, no network calls, single-file
outputs.

- scaffold_deck.py copies a complete 9-12 slide archetype (6 ship,
  one in native Japanese — not a translation); swap the illustrative
  data for yours, one command builds an animated HTML deck, and
  pressing "p" in the browser prints it straight to PDF.
- 22 patterns render to real SVG — the charts plus the deck furniture
  nobody ships (covers, section dividers, agendas, closings, back
  covers). The README gallery is committed renderer output; CI fails
  if any of it drifts from the code.
- New since 2.3: any slide spec can carry "notes" (spoken narration).
  The same manifest then builds a podium speaker script (slide left,
  script right, one A4 page per slide) and a serialized-column
  article page for reading the deck top to bottom.
- We also published the first public case study — one real pass on a
  SaaS board update: raw notes -> weak first draft -> the packaged
  reviewer rejects it (14/20) -> decision-first revision passes
  (20/20) -> the committed rendered slides:
  https://github.com/kgraph57/mckinsey-style-visualization-skill/blob/main/examples/case-studies/saas-board-update.md

Live demo (the deck plays in the page):
https://kgraph57.github.io/mckinsey-style-visualization-skill/

Install: npx skills add kgraph57/mckinsey-style-visualization-skill
Repo: https://github.com/kgraph57/mckinsey-style-visualization-skill
```

### X Version (EN)

```text
Scaffold a complete consulting-style board deck with one command. Press "p" in the browser — it's a PDF.

v2.4.0 of my strategy-visualization skill:
- 22 render patterns: charts + covers, dividers, agendas, closings
- 6 deck templates (one in native Japanese): scaffold -> swap data -> animated HTML deck
- Same manifest also builds an A4 report, a speaker script, and an article page
- New: a 2-minute public case study — raw notes -> reviewed, rendered board slide

Zero dependencies. Zero API keys. Zero network calls.
Install: npx skills add kgraph57/mckinsey-style-visualization-skill

Live demo: https://kgraph57.github.io/mckinsey-style-visualization-skill/
Case study: https://github.com/kgraph57/mckinsey-style-visualization-skill/blob/main/examples/case-studies/saas-board-update.md
```

### X Version (JP)

```text
1コマンドで、表紙から裏表紙まで揃った戦略コンサル風デッキが出てくる。ブラウザで「p」を押せばそのままPDF。

v2.4.0の目玉:
- 描画22パターン（グラフ＋表紙・小扉・アジェンダ・クロージング）
- デッキテンプレ6種（日本語ネイティブの役員会デッキ含む）: scaffold → データ差し替え → アニメ付きHTMLデッキ
- 同じマニフェストからA4レポート・発表原稿・記事ページもビルド
- 新公開: 2分で読める導入事例 — 生メモ → レビュー差し戻し → 改訂合格 → 役員会スライド

依存ゼロ・APIキー不要・ネットワーク通信なし。
インストール: npx skills add kgraph57/mckinsey-style-visualization-skill

ライブデモ: https://kgraph57.github.io/mckinsey-style-visualization-skill/
導入事例: https://github.com/kgraph57/mckinsey-style-visualization-skill/blob/main/examples/case-studies/saas-board-update.md
```

## Release Copy (v2.0.0)

Lead with the "one command → full deck" demo: scaffold a template, build the HTML deck, show the print-to-PDF. The story is completeness — covers, dividers, agenda, closing, back cover, deck templates, and browser documents, not just charts.

### Show HN (Hacker News)

```text
Title: Show HN: Full consulting-style decks and reports from one command – templates, structural slides, HTML docs (zero deps)

v2.0.0 turns my slide renderer into a complete presentation system.
Everything is still Python 3 stdlib — no installs, no API keys, no
network calls, single-file outputs.

- 22 patterns now render to real SVG: the 16 charts plus the deck
  furniture nobody ships — section dividers, agenda (with current-item
  tracking), action-title bullet slides, key-takeaways/next-steps
  closings, quotes, and back covers. A whole deck, cover to "thank you",
  renders from JSON.
- 6 deck templates (board update, strategy recommendation, project
  status, market entry, sales proposal, and a native-Japanese board
  deck): scaffold_deck.py copies one, you swap the data, one command
  builds an animated HTML deck that prints straight to PDF.
- New report mode: write Markdown, reference slide specs as exhibits,
  and build_html_report.py emits a self-contained consulting-style HTML
  document — auto-numbered exhibits, TOC, A4 print stylesheet.
- CI still enforces that every committed render is byte-identical to
  what the code produces, now across templates and reports too.

https://github.com/kgraph57/mckinsey-style-visualization-skill
```

### X Version (EN)

```text
One command in. A complete consulting-style deck out.

v2.0.0 of my strategy-visualization skill:
- 22 render patterns: charts + the deck furniture (dividers, agenda, closings, back covers)
- 6 ready deck templates: scaffold -> swap data -> animated HTML deck -> PDF
- New: Markdown -> consulting-style HTML report with auto-numbered exhibits
- Japanese board decks are a first-class template, not a translation

Still zero dependencies. Zero API keys.
https://github.com/kgraph57/mckinsey-style-visualization-skill
```

### X Version (JP)

```text
テンプレを選んでデータを差し替えると、表紙から裏表紙まで揃った戦略コンサル風デッキが1コマンドで出てくる。

v2.0.0の目玉:
- 描画22パターン: グラフ16種＋小扉・アジェンダ・箇条書き・クロージング・引用・裏表紙
- デッキテンプレ6種（役員報告・戦略提言・進捗報告・市場参入・営業提案＋日本語ネイティブの役員会デッキ）
- 新機能: Markdownを書くとExhibit自動採番つきのコンサル風HTML文書に（ブラウザ印刷でA4 PDF）
- committed済みレンダリングとコードの一致をCIが全数検証

依存ゼロ・APIキー不要は据え置き。
https://github.com/kgraph57/mckinsey-style-visualization-skill
```

## Release Copy (v1.9.0)

Attach `assets/readme/demo.gif` to every post — the animated deck carries the message. For platforms that need stills, use the gallery SVGs exported to PNG.

### Show HN (Hacker News)

```text
Title: Show HN: Turn messy notes into board-ready slides – SVG, animated HTML, PDF (zero deps)

I built an agent skill + renderer that turns raw notes and metrics into
consulting-style slides. Everything is Python 3 stdlib — no installs, no
API keys, no network calls.

- 16 chart patterns render to real SVG (waterfall, 2x2, heatmap, small
  multiples, scatter...); the gallery in the README is committed renderer
  output, and CI fails if it drifts from the code.
- One command bundles slides into a self-contained animated HTML deck:
  staggered reveals, keyboard nav, and a print stylesheet so the browser
  exports it straight to PDF. SVGs also drop into PowerPoint/Keynote.
- Japanese business documents are first-class: CJK-aware wrapping,
  dedicated profiles for board papers and approval documents.
- The part I enjoyed most: I ran the whole visual system through a
  five-perspective design review (Tufte's data-ink rules, an ex-McKinsey
  chart lens, Swiss grid typography, FT data journalism, modern design
  engineering), and they found real bugs — waterfalls drawing off-canvas
  on negative bridges, palette colors that collapse in greyscale print,
  WCAG contrast failures. v1.9.0 ships every fix, with the integrity
  rules (Lie Factor, contrast, greyscale separation) asserted in tests
  instead of promised in prose.

https://github.com/kgraph57/mckinsey-style-visualization-skill
```

### X Version (EN)

```text
Messy notes in. Board-ready slides out.

v1.9.0 of my strategy-visualization skill:
- 16 patterns render to real SVG (CI-verified gallery)
- 1 command -> animated HTML deck -> print -> PDF
- SVGs drop into PowerPoint / Keynote
- Japanese business docs supported (CJK wrapping that actually works)
- reviewed & hardened by a 5-perspective design panel (Tufte, ex-McKinsey, Swiss grid, FT, design engineering)

Zero dependencies. Zero API keys.
https://github.com/kgraph57/mckinsey-style-visualization-skill
```

### X Version (JP)

```text
雑なメモを入れると、役員会スライドが出てくる。

v1.9.0の目玉:
- 16パターンを本物のSVGスライドに描画（ギャラリーはCIが鮮度検証）
- 1コマンドでアニメ付きHTMLデッキ → ブラウザ印刷でそのままPDF
- SVGはPowerPoint/Keynoteに直接挿入OK
- 日本語対応が本物（CJK折返し・稟議書/役員会資料プロファイル）
- Tufte・元McKinsey・スイス派・FT・デザインエンジニアの5視点パネルに酷評させて全部修正

依存ゼロ・APIキー不要。
https://github.com/kgraph57/mckinsey-style-visualization-skill
```

### Reddit (r/ClaudeAI or r/LocalLLaMA)

```text
Title: I made my agent's charts survive a design audit — 5-perspective panel review, then fixed everything (open source, zero deps)

Most AI-generated charts look fine until someone checks the numbers. I
wanted charts I could defend, so after building a slide renderer for my
agent, I convened a brutal five-perspective design review — Tufte
data-ink rules, an ex-McKinsey chart discipline lens, Swiss grid
typography, FT-style data journalism, and modern design engineering.

They tore it apart (5.8/10 average): waterfalls drew off-canvas on
negative bridges, the palette collapsed in greyscale print, Japanese
text overflowed the canvas, heatmap text failed WCAG contrast.

v1.9.0 ships every fix, with the integrity rules asserted in the test
suite. It renders 16 chart patterns to SVG, bundles them into animated
HTML decks (print -> PDF), and the whole thing is Python stdlib.

The full panel transcripts and fix list are in the changelog. Repo:
https://github.com/kgraph57/mckinsey-style-visualization-skill
```

## Release Copy (v1.8.0)

Attach the hero image (`assets/readme/hero-before-after.svg` exported to PNG) to every post. The image carries the message; the text supports it.

### Short Post

```text
I released Strategy Consulting Visualization Skill v1.8.0.

Messy notes in, board-ready slide out. It now renders actual SVG slides —
not just specs — across 12 patterns: waterfalls, funnels, gantts,
heatmaps, scorecards, 2x2s, benchmark tables, and more, with role packs
for sales, PMO, HR, engineering, and research.

One command, zero dependencies:
python3 scripts/render_slide_spec.py spec.json

It also generalized beyond board slides: reports, proposals, training
materials, technical diagrams, and infographics, with input triage that
maps any input — numbers, prose, processes — to the right pattern.

https://github.com/kgraph57/mckinsey-style-visualization-skill
```

### X Version (EN)

```text
v1.8.0: the skill now RENDERS slides — and has packs for every role.

Messy notes -> consulting-style SVG slide, one command, zero deps.

- 12 rendered patterns (waterfall, funnel, gantt, heatmap...)
- 28 visualization patterns total
- works for reports, proposals, docs, infographics too
- input triage: feed it anything

https://github.com/kgraph57/mckinsey-style-visualization-skill
```

### X Version (JP)

```text
v1.8.0をリリース。実際にスライドを描画でき、職種別パックも揃いました。

雑なメモ → コンサル風SVGスライド。1コマンド、依存ライブラリゼロ。

- ウォーターフォール・ファネル・ガント等12パターンをレンダリング
- 可視化パターンは全28種
- 役員会資料だけでなくレポート・提案書・研修資料・図解にも対応
- 数値でも文章でもプロセスでも、何を投げてもOK

https://github.com/kgraph57/mckinsey-style-visualization-skill
```

### Show HN Draft

```text
Title: Show HN: An agent skill that turns messy notes into consulting-style slides

First comment:
I kept seeing AI-generated business charts that looked like generic
dashboards, so I built a SKILL.md package that gives agents a stricter
operating system: insight-led headlines, honest scales, restrained
palette, explicit assumptions.

Recent releases added a renderer — spec JSON to styled SVG slide,
Python stdlib only — input triage so it can visualize anything, and
role packs for sales, PMO, HR, engineering, and research.

What it does NOT do: render PPTX, invent data, or imply affiliation
with any consulting firm. Scope and caveats are in the README.
```

### Reddit Draft (r/ClaudeAI)

```text
Title: I built a Claude skill that turns messy notes into board-ready slides (now with an actual SVG renderer)

Body: Walk through one real example end to end: paste raw notes, show
the generated spec, show the rendered SVG. Include the before/after
hero image. Close with the repo link and ask what patterns or document
types readers want next.
```

### LinkedIn Version

```text
I published Strategy Consulting Visualization Skill v1.8.0.

The skill helps AI agents turn raw input into executive-ready visuals.
New in recent releases: an SVG renderer (spec JSON to finished slide,
no dependencies), role-based packs with rendered examples for nine
business roles, Japanese document profiles, and generalization beyond
board slides to reports, proposals, training materials, and diagrams.

Use cases include board updates, vendor selection, investment memos,
capacity gaps, process bottleneck analysis, and competitive benchmarks.

Repository:
https://github.com/kgraph57/mckinsey-style-visualization-skill
```

### Community Post

```text
I built an open-source SKILL.md package for professional visualization.

The goal: give an AI agent enough structure to turn any input into a
disciplined visual — insight-led headline, right pattern, honest data —
instead of a generic chart prompt.

What is included:
- portable SKILL.md entrypoint
- input triage: maps numbers, prose, processes to the right pattern
- 28 visualization patterns, 18 document-type profiles
- SVG renderer for 12 patterns (Python stdlib only)
- persona playbook for 9 business roles
- style system, prompt templates, quality rubric
- draft -> review -> revise examples and local validation

Repo:
https://github.com/kgraph57/mckinsey-style-visualization-skill
```

## Social Asset

Primary: `assets/readme/demo.gif` (the animated board deck — the same asset the README leads with).
Stills: `assets/readme/hero-before-after.svg` exported to PNG (messy notes -> rendered slide), `assets/social/launch-card.svg`, or any gallery SVG exported to PNG.

Alt text: Strategy Consulting Visualization Skill turns raw notes into a rendered, board-ready deck with one command — SVG slides, an animated HTML deck, and print-to-PDF.

### X Thread (JP, 7 posts)

Post 1 is the hook with the hero image; the repo link goes in the last post only. Image files referenced below are the committed SVGs exported to PNG.

```text
1/ (画像: hero-before-after)
「雑なメモ → 役員会に出せるスライド」を1コマンドでやるClaude Skillを作りました。

AIにありがちな"それっぽいだけのグラフ"ではなく、コンサルの作法(結論ファーストの見出し・正直な軸・抑えた配色)で描画します。

何ができるか、ツリーで説明します🧵

2/ (画像: arr-waterfall)
仕組みはシンプル。
メモや数値を渡す → スキルが「問い → 見出し → パターン選択 → スペックJSON」まで設計 → 付属レンダラーがSVGスライドを描画。

Python標準ライブラリのみ、依存ゼロ。
python3 scripts/render_slide_spec.py spec.json

3/ (画像4枚: sales-pipeline-funnel, pmo-rollout-gantt, marketing-channel-heatmap, hr-talent-scorecard)
職種別パックがあります。

営業:パイプラインのファネル
PMO:クリティカルパス入りガント
マーケ:チャネル×セグメントのヒートマップ
人事:タレントスコアカード

すべてコピペ用プロンプト付き。

4/ (画像4枚: product-priority-two-by-two, eng-incident-flow, research-outcomes-before-after, executive-summary)
さらに:

PdM:工数×インパクトの2x2
エンジニア:障害ポストモーテムのフロー
研究・医療:過大主張しないアウトカム比較
経営者:取締役会向けサマリー

レンダリング12パターン、設計レベルでは28パターン。

5/
入力は何でもOKです。
数値データ、議事録、プロセスの説明、ただの文章 — 「入力トリアージ」が入力の種類を最適なパターンに対応付けます。

稟議書・週報・学会抄録・提案書など、日本のビジネス文書プロファイルも入っています。

6/
こだわりは"正直さ"です。

・数値を捏造しない(足りないデータは明示)
・軸を誇張しない
・出典と仮定を必ず書く

見た目より先に、意思決定に使える資料であること。

7/
オープンソース(MIT)です。インストールは1行:

git clone https://github.com/kgraph57/mckinsey-style-visualization-skill.git ~/.claude/skills/strategy-consulting-visualization

リポジトリはこちら。スターしてもらえると励みになります⭐
https://github.com/kgraph57/mckinsey-style-visualization-skill
```

## Persona Content Calendar

Nine weekly posts, one role each. Format: role-targeted hook + the rendered example image + repo link. Post JP and EN versions; the rendered SVGs convert to PNG with any SVG tool.

| Week | Role | Hook (JP) | Asset |
| --- | --- | --- | --- |
| 1 | 営業 | CRMのエクスポートを貼るだけでQBRのファネルができます | `assets/rendered/sales-pipeline-funnel.svg` |
| 2 | PM/PMO | クリティカルパス入りのロードマップ、ガント図を手で描くのは今日で終わり | `assets/rendered/pmo-rollout-gantt.svg` |
| 3 | マーケター | チャネル×セグメントのヒートマップで予算再配分の議論が5分で終わる | `assets/rendered/marketing-channel-heatmap.svg` |
| 4 | 人事 | 経営会議に出すタレントスコアカード、メトリクスを箇条書きで渡すだけ | `assets/rendered/hr-talent-scorecard.svg` |
| 5 | PdM | 機能の優先順位、工数×インパクトの2x2に自動でマッピング | `assets/rendered/product-priority-two-by-two.svg` |
| 6 | エンジニア | ポストモーテムのタイムライン、ボトルネックを強調したフロー図に | `assets/rendered/eng-incident-flow.svg` |
| 7 | 研究職・医療職 | 抄読会のアウトカム比較、過大な主張をしないビフォーアフターに | `assets/rendered/research-outcomes-before-after.svg` |
| 8 | 財務 | 予実差異のウォーターフォール、数字が必ず合う形で | `assets/rendered/arr-waterfall.svg` |
| 9 | 経営者 | 取締役会の3つのメッセージ、サマリーストリップ1枚に | `assets/rendered/executive-summary.svg` |

Each post doubles as a Zenn/Qiita article seed: expand the hook into a 5-minute walkthrough (input -> spec -> rendered slide).

## 7-Day Launch Plan

| Day | Action | Success Signal |
| --- | --- | --- |
| 1 | Post short copy on X/Threads and LinkedIn | Replies, reposts, bookmarks |
| 1 | Submit to P0 marketplace targets | Submission received or listing live |
| 2 | Post community version in relevant agent/Claude/Codex communities | Comments asking how it works |
| 3 | Publish one mini case study: raw notes -> draft -> review -> revised spec | Saves and example requests |
| 4 | Submit to P1 marketplace targets | Additional listings |
| 5 | Ask 5 target users to try a board-update prompt | Usability feedback |
| 6 | Add any requested example scenario | New issue, fork, or PR |
| 7 | Summarize metrics and decide premium-pack scope | Evidence for next release |

## Metrics

Track these weekly:

| Metric | Why It Matters |
| --- | --- |
| GitHub stars | Lightweight discovery and trust signal |
| Forks | Developer interest |
| Issues/discussions | Real usage and confusion points |
| Marketplace listings | Distribution footprint |
| Marketplace installs/saves | Demand signal |
| Social bookmarks | Buyer/user intent |
| Replies requesting PPTX/PDF | Premium pack signal |
| Direct messages | Sales and acquisition signal |

Record the weekly numbers in [TRACTION.md](TRACTION.md).

## Launch Claims To Avoid

- Do not claim affiliation with any consulting firm.
- Do not claim the skill renders final PowerPoint decks by itself.
- Do not claim marketplace approval before a listing is live.
- Do not claim revenue or usage traction until tracked.

## Follow-Up Case Study Format

```text
Input:
[Paste 4-8 lines of raw business notes]

Draft:
[Show the first slide-spec output]

Review:
[Show 3-5 review findings]

Revision:
[Show the revised decision headline, chart choice, assumptions, and quality score]
```
