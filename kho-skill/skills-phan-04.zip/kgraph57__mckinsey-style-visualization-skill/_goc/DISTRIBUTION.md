# Distribution Kit

Use this file to list the skill, announce updates, and test demand.

## Primary URL

https://github.com/kgraph57/mckinsey-style-visualization-skill

## Release URL

https://github.com/kgraph57/mckinsey-style-visualization-skill/releases/tag/v2.4.0

This remains the stable release. The v3 preview is published separately:
https://github.com/kgraph57/mckinsey-style-visualization-skill/releases/tag/v3.0.0-rc.1

Do not submit the draft marketplace copy below as a stable release until the
manual gates in `tests/manual/interactive-release.md` are completed.

## Draft v3 listing — do not submit

Strategy Consulting Visualization Skill turns business inputs into
assertion-led slides and optional interactive decision decks. Explicit dynamic
requests produce both a static/print baseline and a self-contained companion
with bounded scenarios, exact what-if controls, evidence, and deterministic
presenter operation. Project Relay is original and entirely illustrative.

Core HTML generation uses Python's standard library, makes no automatic
network request, and writes explicit destinations. Browser/PDF/audit checks
use optional pinned tools. This draft does not claim Safari, physical device,
screen-reader, projector, or hosted-header verification.

## Awesome-List Submission Kit

Ready-to-submit entries for community lists. House rule: a human reviews every outbound PR diff before it is opened, one list per PR, and the PR body discloses AI assistance.

Candidate lists (verify each list's contribution rules first):

- awesome-claude-code (skills / workflows section)
- awesome-claude-skills style lists
- awesome-ai-agents (tools section)
- awesome-dataviz (generators section)

One-line entry (adapt to each list's format):

```text
[Strategy Consulting Visualization Skill](https://github.com/kgraph57/mckinsey-style-visualization-skill) - Turn messy notes into board-ready slides: 16 chart patterns rendered to SVG, animated HTML decks with PDF export, Japanese business documents supported. Python stdlib only.
```

PR body template:

```text
Adds Strategy Consulting Visualization Skill: an agent skill + renderer
that turns raw notes/metrics into consulting-grade slides (SVG, animated
HTML deck, PDF via print). Zero dependencies, CI-verified example gallery,
MIT licensed. Disclosure: the project is developed with AI assistance and
every release is validated by tests and a package validator.
```

## Short Pitch

Strategy Consulting Visualization Skill turns messy business notes into board-ready visualization specs: waterfalls, 2x2 maps, benchmark tables, timelines, gap visuals, investment memos, and executive summary strips.

## One-Line Listing

Create executive-ready strategy visualization specs from raw business metrics, with insight-led headlines, reusable slide specs, quality checks, and iterative review loops.

## Category

Agent skill, visualization, strategy, consulting, executive presentations, board materials, data storytelling.

## Best-Fit Marketplaces

Submit to SKILL.md and agent-skill directories first. Prioritize places that allow GitHub-based listings:

- SkillsMP
- SkillHQ
- SkillsMarket
- Skill Vault
- skill.broker
- ClaudSkills
- Skillhound
- Skiln
- AgenticSkills
- GitHub awesome lists for agent skills

See [Marketplace Targets](MARKETPLACE_TARGETS.md) for URLs, priority, and submission angles.

Open a marketplace listing issue with `.github/ISSUE_TEMPLATE/marketplace-listing.md` for each submission.

## Submission Checklist

- [ ] Use the short pitch above.
- [ ] Link to README, not only the release page.
- [ ] Mention visual examples in `assets/readme/`.
- [ ] Mention the review loop and `scripts/review_slide_spec.py`.
- [ ] Mention no required network access.
- [ ] Mention non-affiliation with consulting firms.
- [ ] Include tags: `SKILL.md`, `agent-skills`, `data-visualization`, `executive-presentations`, `board-slides`, `strategy-consulting`.

## Announcement Copy

```text
I released Strategy Consulting Visualization Skill.

It turns messy business notes into board-ready visualization specs:
- ARR waterfalls
- 2x2 market maps
- benchmark tables
- capacity gap visuals
- investment memo visuals
- executive summary strips

It also includes visual examples, a validation script, and a draft -> review -> revise loop so outputs can be scored before publishing.

https://github.com/kgraph57/mckinsey-style-visualization-skill
```

## Proof Points

- 13 README visual examples.
- 4 iterative review-loop scenarios.
- v1 drafts intentionally fail review; v2 drafts pass.
- Local validation script.
- Public reference corpus.
- Security policy and marketplace manifest.
