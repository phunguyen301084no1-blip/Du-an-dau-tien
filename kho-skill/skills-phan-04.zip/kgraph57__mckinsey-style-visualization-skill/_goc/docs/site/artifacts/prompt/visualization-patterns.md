# Visualization Patterns

Use the pattern that best supports the decision, not the one that looks most impressive. If the input is not an obvious chart request, start with `references/input-triage.md` to map it to a pattern family.

## Step 0 — Name the Comparison Before Picking a Pattern

Every quantitative chart encodes one of five basic comparison types (Zelazny's discipline). Name the comparison first; only then pick a pattern. This prevents choosing a chart shape before understanding what is actually being compared.

| Comparison Type | You Are Saying | Pattern Families |
| --- | --- | --- |
| Component (share of a whole) | "X is n% of the total" | Market share / adoption, Stacked composition |
| Item (ranking) | "A is bigger / better than B" | Gap visualization, Benchmark table, Investment / scale |
| Time series | "X is rising / falling / flat" | Time-series growth, Before-after, Waterfall, Small multiples, Gantt |
| Frequency distribution | "Most cases fall in this range" | Distribution chart, Heatmap matrix |
| Correlation | "X moves (or does not move) with Y" | Scatter / correlation, 2x2 framework |

Qualitative structures (process, hierarchy, cycle, decision logic) skip this table and go straight to the structural patterns below.

## Rendering Support

The bundled renderer (`scripts/render_slide_spec.py`) turns specs into SVG for the patterns marked **✓ SVG** below (16:9 canvas only). Patterns marked *spec-only* produce a structured spec or an image-generation prompt — not a rendered file. Say which you are delivering; never imply a spec-only pattern will render.

## Core Strategy Patterns

| Pattern | Renderer | Use When | Strategic Question |
| --- | --- | --- | --- |
| Time-series growth | ✓ SVG | Showing adoption, revenue, usage, or performance over time | Is momentum accelerating or stalling? |
| Gap visualization | ✓ SVG | Comparing current vs. target or leader vs. laggard | How large is the gap and why does it matter? |
| Before-after comparison | ✓ SVG | Demonstrating intervention impact | What changed and is it enough to justify action? |
| Market share / adoption | spec-only | Showing penetration or composition | Where is the center of gravity? |
| Investment / scale infographic | spec-only | Comparing operating scale, investment, or capacity | Who has the scale advantage? |
| Timeline | spec-only | Showing sequence, milestones, regulation, or rollout | What must happen, and when? |
| Contrast diagram | spec-only | Comparing regions, strategies, or operating models | Where are the structural differences? |
| 2x2 strategic framework | ✓ SVG | Positioning players or options across two drivers | Which position is attractive or exposed? |
| Competitive benchmark table | ✓ SVG | Comparing multiple players across criteria | Who leads on the dimensions that matter? |
| Waterfall chart | ✓ SVG | Explaining bridge, variance, or cumulative change | What drives the delta? |
| Cover slide | ✓ SVG | Opening a deck or section | What is this argument about? |
| Executive summary strip | ✓ SVG | Compressing 3-5 takeaways into a decision memo visual | What should the executive remember? |

## Universal Patterns

These patterns extend the skill beyond board slides to reports, proposals, training materials, technical docs, and explainers. They follow the same style system and quality rubric.

| Pattern | Renderer | Use When | Reader Question |
| --- | --- | --- | --- |
| Process flow | ✓ SVG | Showing steps, handoffs, or a workflow | What happens, in what order, and who owns each step? |
| Funnel | ✓ SVG | Showing staged conversion or attrition | Where do we lose the most, stage by stage? |
| Cycle diagram | spec-only | Showing recurring loops or feedback systems | What sustains or breaks this loop? |
| Hierarchy / tree | spec-only | Showing org structures, taxonomies, or breakdowns | How is this organized, and where does X sit? |
| Pyramid | spec-only | Showing layered arguments, priorities, or maturity levels | What is the foundation and what sits on top? |
| Concept / system map | spec-only | Showing how entities, ideas, or components relate | How do the parts interact? |
| Gantt / roadmap | ✓ SVG | Showing workstreams, phases, and dependencies over time | Are we on track, and what blocks what? |
| Heatmap matrix | ✓ SVG | Showing intensity across two categorical dimensions | Where are the hot spots? |
| Scatter / correlation | ✓ SVG | Showing relationship between two continuous variables | Do these move together, and who are the outliers? |
| Distribution chart | ✓ SVG | Showing spread, concentration, and outliers | What is typical, and what is extreme? |
| Small multiples | ✓ SVG | Comparing one metric's trend across many segments on a shared scale | Does the pattern hold everywhere, or only in some segments? |
| Stacked composition | spec-only | Showing how composition shifts across items or time | What is the mix, and how is it changing? |
| KPI scorecard | ✓ SVG | Showing many metrics with status at a glance | What is healthy and what needs attention? |
| Decision tree | spec-only | Showing branching logic, eligibility, or escalation rules | Given my situation, what do I do? |
| Flow / allocation (Sankey-style) | spec-only | Showing how a quantity splits and flows between stages | Where does the volume actually go? |
| Checklist / maturity grid | spec-only | Showing completion or capability levels against a standard | What is done, and what is the next level? |
| Annotated map | spec-only | Showing geographic concentration or coverage | Where is this happening? |

## Pattern Notes

### Time-Series Growth

Use a line or bar chart with direct labels, restrained gridlines, and one annotation that explains the inflection or strategic implication.

### Gap Visualization

Use horizontal bars when contrast matters more than exact trend. Keep the larger comparator visually dominant and label the gap in business terms.

### Before-After Comparison

Use paired bars or paired scorecards. Include the absolute delta and, when useful, the relative improvement. Do not hide the baseline.

### Market Share / Adoption

Use a donut only when part-to-whole composition matters and there are few segments. Use ranked bars when precise comparison matters more than composition.

### Investment / Scale Infographic

Use side-by-side columns with comparable metrics. Avoid unmatched vanity numbers unless the mismatch is the argument.

### Timeline

Use evenly spaced nodes for conceptual phases and proportional spacing for actual dates. Call out dependencies and decision gates.

### Contrast Diagram

Use mirrored columns with the same row labels to make asymmetry obvious. Avoid strawman comparisons.

### 2x2 Strategic Framework

Label axes in business language, not abstract nouns. Put quadrant implications in the chart, not only in surrounding text.

### Competitive Benchmark Table

Rank the criteria by decision relevance. Use numeric alignment, leader highlighting, and clear caveats for subjective scores.

### Waterfall Chart

Use for bridges from one value to another. Positive and negative movements must be visually distinct and additive.

### Cover Slide

Use restrained typography, title, subtitle, date, audience, and confidentiality marker if needed. Avoid decorative chart previews.

### Executive Summary Strip

Use three to five insight blocks. Each block should combine a claim, proof point, and implication in one compact unit.

## Universal Pattern Notes

### Process Flow

Use left-to-right or top-to-bottom boxes with labeled arrows. Mark owners, inputs, and outputs where they change. Highlight the bottleneck or failure point in blue, not every step.

### Funnel

Keep stage widths proportional to real values and label both absolute counts and stage-to-stage conversion rates. Annotate the single largest drop.

### Cycle Diagram

Use 3-6 nodes in a closed loop with directional arrows. Label what flows between nodes, not just node names. Mark the reinforcing or breaking point.

### Hierarchy / Tree

Limit visible depth to three levels per visual; link to detail views for deeper structures. Keep sibling order meaningful (size, priority, or sequence), not arbitrary.

### Pyramid

Use 3-5 layers with the governing claim or foundation clearly anchored. State what qualifies an item for each layer; a pyramid without layer criteria is decoration.

### Concept / System Map

Limit to roughly 12 nodes per view. Use line styles to distinguish relationship types (depends on, feeds, blocks) and add a small legend. Cluster related nodes spatially.

### Gantt / Roadmap

Show plan vs. actual when tracking, not just plan. Mark dependencies and decision gates explicitly. Use one row per workstream, not per task, in executive views.

### Heatmap Matrix

Use a single-hue intensity ramp for non-negative intensity data. When values carry sign (variance, YoY change, deviation from target), use a diverging ramp anchored at zero — blue for positive, red for negative, neutral at zero — so the sign is visible in the color, not only in a minus sign. The renderer switches automatically when the data spans zero. Label the extremes with actual values and order rows and columns by a meaningful sort so the pattern is visible.

### Scatter / Correlation

Label outliers and the quadrant or trend that carries the message. State correlation honestly; never imply causation in the headline without support.

### Distribution Chart

Show the shape (histogram or summary bands) plus the marker that matters: median, target, or threshold. Note sample size.

### Small Multiples

Use one shared scale across all panels — per-panel scales silently exaggerate flat segments. Highlight at most one or two panels; the value of the pattern is the honest side-by-side density, not per-panel decoration. This is the analytical, high-density counterpart to one-message slides.

### Stacked Composition

Use 100% stacked bars when share matters and absolute stacked bars when scale matters. Limit to 5-6 segments; group the rest as "Other" with a note.

### KPI Scorecard

Group metrics by theme, show value, trend, and target per metric, and reserve color for status against target. Limit to what fits one glance; link the rest.

### Decision Tree

Phrase each branch as a yes/no or small-choice question a reader can answer about their own case. Every leaf must be an action, not another question.

### Flow / Allocation (Sankey-Style)

Keep band widths proportional and totals reconciled between stages. Label the largest flows directly; aggregate small flows.

### Checklist / Maturity Grid

Define each level or check objectively enough that two readers score the same way. Show current state and target state in the same visual.

### Annotated Map

Use a map only when geography itself is the message; otherwise ranked bars by region are clearer. Annotate the few locations that carry the story.

## Structural / Deck Patterns

These patterns are deck furniture, not chart types: they open, orient, transition, and close a deck so the argument-carrying content slides do not have to. They follow the same style system, but none of them encode data — do not reach for one when the reader's question is quantitative; go back to the comparison-type gate instead.

| Pattern | Renderer | Use When | Reader Question |
| --- | --- | --- | --- |
| Section divider (小扉) | ✓ SVG | Opening a new act inside a deck (e.g. "Where to play", "How to win") | What phase of the argument am I entering now? |
| Agenda | ✓ SVG | Orienting the reader before the first content slide, or marking progress mid-deck | What will this deck cover, and where are we right now? |
| Bullet list (action-title) | ✓ SVG | Stating constraints, context, or risks that are true but not yet a chart | What are the plain facts I need to hold before the next visual? |
| Closing (takeaways / next steps) | ✓ SVG | Ending a deck with the decision ask, owners, and timing | What do I need to remember, and what happens next? |
| Quote | ✓ SVG | Grounding a claim in a verbatim customer or stakeholder statement | Is this actually happening, in someone else's words? |
| End cover (裏表紙) | ✓ SVG | Closing a deck | Who do I follow up with? |

## Structural Pattern Notes

### Section Divider (小扉)

Full-bleed navy, same family as `cover`. Use one per act, not per slide — a deck with a divider every two slides has no acts, just decoration. Carry the running section list so the reader always knows where they are; keep it out if it would overflow the available width rather than shrink it into illegibility.

### Agenda

State what the deck covers in the reader's language, not a table of contents copied from slide titles. If the deck is long enough to revisit the agenda mid-deck, mark `current` once and only once — a "you are here" needs a single unambiguous marker, not a running theme.

### Bullet List (Action-Title Text Slide)

This is the fallback for a true statement that is not a comparison, trend, or relationship — use it deliberately, not because a chart felt like too much work. Keep the top-level list to what a reader can hold in one glance (six items is already a lot); a seventh point is a sign the slide should split in two. At most one bullet earns the strongest emphasis — if the whole slide feels like the takeaway, the takeaway is not stated yet.

### Closing (Key Takeaways / Next Steps)

Separate what happened (`takeaways`) from what happens next (`next_steps`) — do not blend a summary bullet and an action item in the same list, the reader needs to know which is which. Every next step needs an owner; "next steps" without owners is a wish list, not a plan. The `call_to_action` line is the one sentence a reader should still remember a week later — state the decision being asked for, not a recap.

### Quote

Use only a real, attributable statement — never a fabricated or composited quote presented as verbatim. If the source cannot be named specifically (a customer under NDA, an anonymized interview), attribute by role and context instead of inventing a name. One quote per slide; a wall of testimonials dilutes the one voice that was supposed to carry the room.

### End Cover (裏表紙)

The quietest slide in the deck — a closing mark and a way to follow up, not a second closing argument. Do not repeat the takeaways here; that is what `closing` is for.
