// The mail-app contact form (the website-contact-form skill), installed as
// public/js/mail-form.js and loaded by src/components/MailForm.astro. A file of the
// site's own, not an inline script, so a strict Content-Security-Policy
// (script-src 'self') lets it run. Plain JavaScript: it is served exactly as written.
//
// It shows the form (hidden without JavaScript, where it could do nothing), and on
// the button builds a mailto: link from the fields and opens it. Nothing leaves the
// visitor's browser except through their own email program.
(function () {
  'use strict';

  document.querySelectorAll('form[data-mail-form]').forEach(function (form) {
    var status = form.querySelector('[data-mail-form-status]');
    form.hidden = false;

    form.addEventListener('submit', function (event) {
      // The browser has already checked the required fields: an empty one stops it
      // before this runs.
      event.preventDefault();

      // `required` lets a field of spaces through; the mail would arrive without it.
      // Emptied, the browser stops it the way it stops an empty one.
      Array.prototype.forEach.call(form.elements, function (field) {
        if (field.required && typeof field.value === 'string' && !field.value.trim()) field.value = '';
      });
      if (!form.reportValidity()) return;

      // Said before anything else: whether the mail program opened, and whether the
      // visitor pressed Send there, the site never learns. The line also points to the
      // address under the form, for when nothing opens.
      if (status) status.textContent = status.dataset.opened;

      // The address, decoded as EmailLink decodes it (src/lib/obfuscate.ts).
      var to;
      try {
        // A % in the address is the one character the starter's encoding allows that a
        // mailto: link must escape.
        to = atob(form.dataset.to).split('').reverse().join('').replace(/%/g, '%25');
      } catch (e) {
        console.error('mail form: the address could not be decoded', e);
        return;
      }

      // The mail: the site's greeting, the message as typed less any empty space
      // (spaces, tabs, blank lines) at its very start and end, every other field the
      // visitor filled in as "Label: value" (a list gives every chosen entry, a ticked
      // checkbox or radio button its label alone), and the sign-off last. The visitor's
      // mail program adds who they are.
      var details = [];
      Array.prototype.forEach.call(form.elements, function (field) {
        // A named <fieldset> or <output> has no value of its own to send.
        if (!field.name || field.name === 'message' || field.type === 'submit' || field.type === 'button' || typeof field.value !== 'string') return;
        var label = field.labels && field.labels[0] ? field.labels[0].textContent.trim() : field.name;
        if (field.type === 'checkbox' || field.type === 'radio') {
          if (field.checked) details.push(label);
          return;
        }
        var value = field.tagName === 'SELECT'
          ? Array.prototype.map.call(field.selectedOptions, function (option) { return option.text.trim(); }).join(', ')
          : field.value.trim();
        if (value) details.push(label + ': ' + value);
      });
      var message = form.elements.message ? form.elements.message.value.trim() : '';
      var lines = [form.dataset.greeting, '', message];
      if (details.length) lines.push('', details.join('\n'));
      lines.push('', form.dataset.signoff);
      var body = lines.join('\n');

      // RFC 6068: a line break in a mailto: body is %0D%0A. A broken character pasted
      // into a field (half of an emoji) makes encoding throw; the status line already
      // points to the address below.
      var href;
      try {
        href = 'mailto:' + to
          + '?subject=' + encodeURIComponent(form.dataset.subject)
          + '&body=' + encodeURIComponent(body.replace(/\r?\n/g, '\r\n'));
      } catch (e) {
        console.error('mail form: the message could not be put into a link', e);
        return;
      }

      // Count the press as an "Email Tap" event, the same one the starter's email link
      // sends: the visitor asked to write (whether a mail program opens, the site never
      // learns). window.plausible exists only on the live build with analytics on, so
      // elsewhere nothing happens. Nothing the visitor typed goes with it; Plausible adds the
      // page and the referrer, as to every event.
      try {
        if (typeof window.plausible === 'function') window.plausible('Email Tap');
      } catch (e) {
        /* counting must never get in the way of opening the mail program */
      }

      window.location.href = href;
    });
  });
})();
