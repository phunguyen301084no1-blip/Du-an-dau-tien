# AI Generation Reference

**AI generation is optional.** kiln's default is Claude scripting Blender — no AI
model, nothing to install. Generation is offered for organic or realistic forms, the
user chooses, and a local install is never required.

**When the user picks AI, in this order:**

| # | Backend | Needs | Licence |
|---|---|---|---|
| 1 | **TRELLIS.2 Space** `microsoft/TRELLIS.2` — textured (PBR) | `gradio_client`, free quota | MIT — but send an alpha cut-out, see below |
| 2 | **TRELLIS Space** `trellis-community/TRELLIS` | same | MIT; background removal by `rembg` (MIT) + U²-Net (Apache-2.0) |
| 3 | **TripoSR Space** `stabilityai/TripoSR` | same | MIT |
| 4 | **Local TRELLIS.2** — offline only, never required | 31 GB of weights, 24 GB of memory | MIT, two dependencies are not — see below |
| — | **Hunyuan3D** (Space, local, MCP native) — **only on explicit request** | see its sections | **does not apply in the EU, the UK or South Korea** |
| — | **Hyper3D Rodin / Tripo / Meshy / Premium** (MCP native) | paid | rule 5 — never spend |

Stages read on 2026-10-09 through `https://huggingface.co/api/spaces/<id>`:
`microsoft/TRELLIS.2` RUNNING, `trellis-community/TRELLIS` RUNNING,
`stabilityai/TripoSR` **RUNTIME_ERROR**, `microsoft/TRELLIS`
CONFIG_ERROR. Read them again before each session; skip any Space not `RUNNING`.
None of these three Spaces has completed a generation in this project yet.

**The TRELLIS.2 Space's background removal is non-commercial.** Its `app.py`
(read 2026-10-09) keeps an image whose alpha channel is not fully opaque and sends
any other one to the `briaai/BRIA-RMBG-2.0` Space — RMBG-2.0, **CC BY-NC 4.0**. So
cut the subject out first (a transparent PNG) or use TRELLIS (row 2). Its image
encoder, DINOv3, is under Meta's own DINOv3 licence.

**Hunyuan3D, whichever path.** The first line of its `LICENSE`, 2.0 and 2.1 alike
(`Tencent-Hunyuan/Hunyuan3D-2`, `-2.1`): *"THIS LICENSE AGREEMENT DOES NOT APPLY IN THE
EUROPEAN UNION, UNITED KINGDOM AND SOUTH KOREA"*. Never propose it first; when the user
asks for it, quote that line and wait for a yes before any call.

---

## Contents
- MCP-Native Backend — Hunyuan3D, Rodin, Tripo, Meshy: on request only
- Local Backend — Hunyuan3D-2 Mini
  - Requirements
  - Available Models
  - Local API Flow
  - Error Handling (Local)
- HF Spaces Backend — Hunyuan3D 2.x (on request only, licence above)
  - Setup
  - API — verified signature
- Free cloud quota — the real ceiling
  - Whose account pays the quota — say it, every session
- TRELLIS.2 — locally on Apple Silicon (measured)
  - Install — five fixes the project's `setup.sh` does not make
  - Licences — run it MIT-only
  - Its Space, for reference
- Concept Art
  - Default — FLUX.1-schnell HF Space
  - When the quota is spent
  - Not the default any more

## MCP-Native Backend — Hunyuan3D, Rodin, Tripo, Meshy: on request only

The Blender MCP server ships 3D generation through providers that need the user's API keys
or a paid plan: Hunyuan3D (Tencent Cloud keys or a local API, licence above), Hyper3D Rodin,
Meshy, Tripo, and the server's own "Premium" generators (paid). It needs no Python
environment — which does not make it the default.

**`mcp-for-blender` 2.1.9 and later — one tool**

```
get_addon_status()                         → "generators": {"hunyuan3d": "off", "hyper3d": "off", …}
generate_3d(prompt=… | image=…, provider=…) → waits up to 45 s, imports; else a job handle
generate_3d(job=…, name=…)                 → resume waiting (never re-request: it may pay again)
```

`provider="auto"` prefers the server's Premium generators, then the user's own keys: always
name the provider. Never point the user to Premium (rule 5).

**Older servers — one tool set per backend**

```
get_hunyuan3d_status()              → is the integration on?
generate_hunyuan3d_model(...)       → returns a job
poll_hunyuan_job_status(job_id)     → wait for completion
import_generated_asset_hunyuan(...) → straight into the scene

get_hyper3d_status()                     → Hyper3D Rodin, a second, independent backend
generate_hyper3d_model_via_text(...)     → returns a job
poll_rodin_job_status(job_id)            → wait for completion
import_generated_asset(...)              → straight into the scene
```

**Rule 23 applies here too.** Generators are OFF in a default install. On the current server
`get_addon_status()` says so in `generators`. On older ones the addon does not register their
commands while off — the call answers `Unknown command type`, not "disabled": call
`get_hunyuan3d_status()` / `get_hyper3d_status()` first and show the remediation from the
`message` field. The checkboxes live in the MCP panel of the 3D Viewport sidebar (press N if
hidden).

Rule 5 still binds: Rodin, Meshy, Tripo, Premium and some Hunyuan tiers are credit-based. Confirm with
the user before spending anything, and prefer a free backend when one is set up.

---

## Local Backend — Hunyuan3D-2 Mini

Only on explicit request: offline generation of a specific variant. It is a real
install — say so — and the licence excludes the EU, the UK and South Korea (above).

### Requirements

- Python 3.10+
- Hunyuan3D-2 repo cloned + `hy3dgen` installed
- Model weights downloaded (~25 GB for all variants)
- Device: CUDA (full pipeline) / MPS (shape only) / CPU (shape only, slow)

### Available Models

| Model | Params | Speed | Quality | Use case |
|---|---|---|---|---|
| `hunyuan3d-dit-v2-mini` | 0.6B | ~16s (CUDA) | Best | Final quality |
| `hunyuan3d-dit-v2-mini-fast` | 0.6B | ~12s (CUDA) | Good | Good balance |
| `hunyuan3d-dit-v2-mini-turbo` | 0.6B | ~8s (CUDA) | Preview | Fast iteration |

On MPS/CPU: expect 3-10x slower than CUDA times above.

### Local API Flow

```python
import torch
from hy3dgen.shapegen import Hunyuan3DDiTFlowMatchingPipeline
from hy3dgen.texgen import Hunyuan3DPaintPipeline  # CUDA only

# Auto-detect device
device = 'cuda' if torch.cuda.is_available() else ('mps' if torch.backends.mps.is_available() else 'cpu')

# Step 1: Shape generation (works on all devices)
shape_pipeline = Hunyuan3DDiTFlowMatchingPipeline.from_pretrained(
    '{models_path}/Hunyuan3D-2mini',
    subfolder='hunyuan3d-dit-v2-mini',  # or mini-fast, mini-turbo
    use_safetensors=True,
    device=device
)

mesh = shape_pipeline(image="concept.png")
mesh.export("output_shape.glb")

# Step 2: Texture generation (CUDA only — skip on MPS/CPU)
if device == 'cuda':
    tex_pipeline = Hunyuan3DPaintPipeline.from_pretrained(
        '{models_path}/Hunyuan3D-2mini',
        subfolder='hunyuan3d-paint-v2-mini'
    )
    textured_mesh = tex_pipeline(mesh, image="concept.png")
    textured_mesh.export("output_textured.glb")
else:
    # No texture — proceed to skill TEXTURING phase
    pass
```

### Error Handling (Local)

| Error | Action |
|---|---|
| OOM (out of memory) | Ask user: switch to smaller model (turbo), reduce resolution, or fallback to HF Spaces |
| Model not found | Guide to `/kiln setup` for download |
| MPS not supported op | Fallback to CPU for that operation, warn user about speed |
| Any crash | Ask user: "Switch to HF Spaces for this asset?" — never switch silently |

---

## HF Spaces Backend — Hunyuan3D 2.x (on request only, licence above)

**Check the Space is awake before using it.** A community Space pauses when its
owner stops paying for the GPU. The HTTP endpoint still answers 200, so a browser
or a `curl` of the page tells you nothing — but `gradio_client` refuses outright,
which is the useful signal:

```
ValueError: The current space is in the invalid state: PAUSED.
            Please contact the owner to fix this.
```

That is `Jbowyer/Hunyuan3D-2.1`, the previous default here, measured 2026-08-26.
To check before connecting:

```bash
curl -s https://huggingface.co/api/spaces/<owner>/<name> \
  | python3 -c "import json,sys; print(json.load(sys.stdin)['runtime']['stage'])"
# RUNNING  -> usable
# PAUSED / SLEEPING / BUILD_ERROR -> pick another Space
```

Candidates, measured 2026-08-26:

| Space | Stage | Likes |
|---|---|---:|
| `tencent/Hunyuan3D-2` | RUNNING (again on 2026-10-09) | 3,370 |
| `Jbowyer/Hunyuan3D-2.1` | **PAUSED** | 62 |

Prefer the vendor's own Space over a community duplicate: a duplicate depends on
one person continuing to pay, which is exactly how the old default died.

**State on 2026-09-29, measured by the quality bench** (`bench/`): the Space is
RUNNING, `/shape_generation` works, and **`/generation_all` fails server-side**
with `AppError: 'NameError'` — so there is no free *textured* path here today.
Fall back to `/shape_generation` and texture in Blender (PHASE 5b). Textured
generation on a Mac needs CUDA locally, so a local install does not fix this.

**Version drift.** This path was last exercised on 2026-09-29 against
`gradio_client` 2.7.1.
The Gradio API here is auto-generated, so it can change shape with the Space or
the client. Treat the snippet below as a starting point and print
`client.view_api()` if a call fails, rather than assuming the argument list.

### Setup

- `gradio_client`, installed in a venv:
  `python3 -m venv ~/.hunyuan3d/venv && ~/.hunyuan3d/venv/bin/pip install gradio_client`
  (a bare `pip3 install` fails on any PEP 668 Python — Homebrew, most Linux distros)
- Python 3.10+ recommended

### API — verified signature

Inspected live on `tencent/Hunyuan3D-2`, 2026-08-26, `gradio_client` 2.6.1. The
Space exposes 12 named endpoints; two matter:

| Endpoint | Returns |
|---|---|
| `/shape_generation` | 4 values — mesh `filepath`, `str`, `Dict`, `float` |
| `/generation_all` | 5 values — mesh + textured `filepath`, `str`, `Dict`, `float` |

Both take the **same 13 parameters**, all with defaults, so pass only what you need:

| Parameter | Type | Default |
|---|---|---|
| `caption` | str | None |
| `image` | filepath | None |
| `mv_image_front` / `_back` / `_left` / `_right` | filepath | None |
| `steps` | float | 30 |
| `guidance_scale` | float | 5.0 |
| `seed` | float | 1234 |
| `octree_resolution` | float | 256 |
| `check_box_rembg` | bool | True |
| `num_chunks` | float | 8000 |
| `randomize_seed` | bool | True |

```python
from gradio_client import Client, handle_file

client = Client("tencent/Hunyuan3D-2")        # refuses if the Space is paused

result = client.predict(
    image=handle_file("concept.png"),
    steps=30,
    guidance_scale=5.0,
    octree_resolution=256,
    check_box_rembg=True,
    randomize_seed=False,                      # reproducibility
    seed=1234,
    api_name="/generation_all",                # or /shape_generation for untextured
)
mesh_path = gradio_path(result[0])
```

**`gradio_client` 2.x does not always return a path.** On 2.7.1 the Hunyuan3D
Space returns `result[0]` as a dict (`{"value": path, ...}`) and a copy with
`shutil` fails with `TypeError: ... not dict` — measured. The FLUX Space returns
a plain string. Unwrap both, always:

```python
def gradio_path(x):
    """A file path out of whatever gradio_client handed back."""
    if isinstance(x, dict):
        x = x.get("path") or x.get("value") or x.get("name")
        if isinstance(x, dict):                    # {"value": {"path": ...}}
            return gradio_path(x)
    if not isinstance(x, str):
        raise TypeError(f"no file path in gradio result: {x!r}")
    return x
```

`randomize_seed` defaults to **True**, which makes runs non-reproducible. Set it
False and fix `seed` when comparing outputs or re-running a batch.

**If a call fails, print the signature rather than guessing** — this API is
auto-generated and changes with the Space:

```python
print(client.view_api(return_format="dict")["named_endpoints"]["/generation_all"])
```


---

## Free cloud quota — the real ceiling

Every free Space here runs on **ZeroGPU**, and its quota is per user and per day:
**2 minutes without a Hugging Face account, 3.5 minutes with a free one**,
resetting 24 h after the first use (Hugging Face's own reference,
`huggingface/skills`, `huggingface-zerogpu/references/how-quota-works.md`). One
TRELLIS.2 generation requests 60–120 s: measured on 2026-09-29 on a **free
logged-in account**, the quota ran out after one FLUX image and one Hunyuan3D
shape, with `You have exceeded your free ZeroGPU quota (120s requested vs. 0s left)`.

**`gradio_client` sends the locally saved Hugging Face token by default** (its own
docstring: "the locally saved token is used if there is one"). So whether a
session is anonymous depends on `~/.cache/huggingface/token`, not on the code.
Check it with `hf auth whoami` before quoting a quota.

### Whose account pays the quota — say it, every session

The skill carries no credential and never names an account. Whatever token a
Space call uses is the **current user's own**, from their machine — and
`gradio_client` uses it silently. So, before the first Space call of a session:

1. Run `hf auth whoami` (or `uvx --from huggingface_hub hf auth whoami`).
2. If it names an account, tell the user: "Space calls will count against your
   Hugging Face account `<name>`'s free GPU quota." Offer anonymous calls instead.
3. Anonymous means `Client("<space>", token=False)` — measured: `token=None` (the
   default) sends the saved token, `token=False` sends none. Setting
   `HF_HUB_DISABLE_IMPLICIT_TOKEN=1` does the same for a whole process.

Never read, print, copy or write a token anywhere — not into a script, a log, a
manifest or a message. Needing one means asking the user to run `hf auth login`
themselves.

**A call reserves the Space's declared duration, not the time it runs.** FLUX.1-schnell
produces an image in 5.6 s, yet a call is refused with `90s requested vs. 0s left`;
TRELLIS.2 asks 60–120 s. Budget in reservations, not in seconds of work.

**And the day does not start at midnight.** Measured on a free account: first Space
call on 2026-09-29 at ~15:00, quota spent by ~16:00, and the next morning at 12:45
FLUX was still refused — the reset comes 24 h after the *first* call, so ~15:00.
Plan around it: once the quota is spent, **no Space works for the rest of that
window, concept art included.**

So the free cloud path is **one or two generations a day**. Say so before a batch
of AI assets, never promise it, and never suggest the paid PRO plan (rule 5).

## TRELLIS.2 — locally on Apple Silicon (measured)

`microsoft/TRELLIS.2` (MIT) outputs a mesh **with baked PBR textures**, which is
exactly what the Hunyuan3D Space's broken `/generation_all` no longer gives. Measured
on 2026-10-01 through `shivampkumar/trellis-mac` (`d58628f`), on an M4 Pro with 24 GB:
5–7 min a model, pipeline load included; **19.5–22.5 GB peak memory** — a 24 GB machine
is the floor; 160–190k triangles, one material, 1024² PBR, ~11 MB GLB.

Disk: **31 GB of weights** (TRELLIS.2-4B 28 GB, DINOv3 2.3 GB, BiRefNet 0.8 GB), plus a
1 GB venv — not the 15 GB the project's README states.

**What it gives, and what it does not.** Its proportions are good — better than a single
photo's, which perspective bends — but the raw output is a *starting point*, never an
asset:

- **always 1 m tall** — set the real size (the BRIEF phase);
- **far above any tier**, with non-manifold and open edges — decimate (rule 6) and clean;
- **one material** — glass and metal come out as one; split them and rebuild each;
- **a drawn concept's ink lines are baked into the texture** as black cracks and blots —
  ask for a concept without outlines, or repaint.

**Its best use is as a measuring template** for scripted modeling (`reference-fidelity.md`
§ 2, `tools/template_profile.py`): proportions from the mesh, a clean model from the
measures, materials from the photo. Finished directly instead, it keeps its weaknesses:

- **thin parts are rebuilt, not decimated** — a simplifier breaks wires, bails and loops
  whatever the budget. Rebuild each as a curve with a round bevel: its centreline from the
  high-poly (slice the part along its length, one centroid per slice), its radius from the
  slices' size. Decimate only the solid body;
- **after decimating, count open and non-manifold edges** and look at a close render of
  every thin part before reporting — a good silhouette score is not a pass.

### Install — five fixes the project's `setup.sh` does not make

Measured, in the order they failed:

1. **Metal toolchain** absent from a fresh Xcode: `xcodebuild -downloadComponent MetalToolchain`
   (or `SKIP_METAL=1` — texture baking then falls back to CPU).
2. **C++20**: the Metal extensions (`deps/mtldiffrast`, `deps/mtlgemm`, …) build with
   `-std=c++17` and fail against the current PyTorch headers; set `-std=c++20` in their
   `setup.py`.
3. **Eigen** for `o-voxel`: `brew install eigen`, and build with
   `CPATH=$(brew --prefix eigen)/include/eigen3`.
4. **`einops`** — needed by BiRefNet, missing from the requirements: `.venv/bin/pip install einops`, inside trellis-mac's own venv.
5. **`PYTORCH_ENABLE_MPS_FALLBACK=1`** at run time: `aten::segment_reduce` has no MPS kernel
   and the run aborts without it.

### Licences — run it MIT-only

TRELLIS.2 is MIT, but its `pipeline.json` loads two models that are not:

- **RMBG-2.0** (background removal) — **CC BY-NC 4.0, non-commercial**, and gated. Swap it
  for **`ZhengPeng7/BiRefNet` (MIT)**, the model RMBG-2.0 is built on, by wrapping the
  pipeline's `BiRefNet` class rather than editing the clone. That model loads with
  float16 weights while the class feeds float32 — *"Input type (float) and bias type
  (c10::Half) should be the same"* on the first image without alpha — so cast it with
  `.float()` after loading. An image that already has an alpha channel skips removal, so a
  photo with a cut-out never exercises this path: **test with an opaque image.**
- **DINOv3** (image encoder) — Meta's own licence, gated on Hugging Face. Accepting it is
  the user's call, on their account; say so before recommending the local path for
  anything commercial.

Never fetch these weights with the user's token without saying whose account it is
(see *Whose account pays the quota* above).

### Its Space, for reference

| Endpoint | Takes | Note |
|---|---|---|
| `/start_session` | — | call first; state lives in the client session |
| `/preprocess_image` | `input` | background removal — RMBG-2.0 (CC BY-NC) unless the image has alpha; returns a path |
| `/image_to_3d` | `image`, `seed`, `resolution` ("1024"), sampler settings | |
| `/extract_glb` | `decimation_target`, `texture_size` | **rejects a target under 100,000** — decimate in Blender after (rule 6) |

Read live on 2026-09-29; no Space generation has completed on the free quota.

## Concept Art

SKILL.md sends text-prompt concept art here; this section did not exist until the
quality bench found the gap on 2026-09-29.

### Default — FLUX.1-schnell HF Space

Free, no key, **Apache-2.0** (model card, checked 2026-09-29), and it runs through
the same `gradio_client` venv as the 3D Spaces — nothing new to install. Measured:
one 1024×1024 image in **5.6 s**, no watermark.

```python
from gradio_client import Client

client = Client("black-forest-labs/FLUX.1-schnell")
result = client.predict(
    prompt="<asset>, <style>, centered, isolated on a plain white background, "
           "three-quarter view, single object",
    seed=42, randomize_seed=False,               # reproducible
    width=1024, height=1024, num_inference_steps=4,
    api_name="/infer",
)
image_path = gradio_path(result[0])              # a .webp; result[1] is the seed
```

The Space returns **WebP**. Convert before feeding a 3D Space that expects PNG:
`sips -s format png concept.webp --out concept.png` on macOS.

**It does not always obey "no ground".** Measured: grass and a drop shadow under
the subject despite the prompt. Hunyuan3D's `check_box_rembg=True` removes the
background; inspect the result before generating anyway.

Like every ZeroGPU Space it has a per-user quota and can pause. Check
`https://huggingface.co/api/spaces/black-forest-labs/FLUX.1-schnell/runtime`
for `"stage": "RUNNING"` first — a paused Space still answers HTTP 200.

### When the quota is spent

FLUX runs on the same ZeroGPU quota as the 3D Spaces, so a spent quota also means
no concept art. In order of preference, all free:

1. **The user's own image** — a sketch, a photo, a screenshot. Ask for it first.
2. **A CC0 reference from PolyHaven**: every asset has an official preview,
   `thumbnail_url` in `https://api.polyhaven.com/info/<id>` — replace its query
   (`?width=256&height=256&v=…`) with `?width=1024&height=1024`, measured to work —
   transparent PNG, and the real model exists for comparison. Credit it (ToS 2.5).
3. **Scripted modeling from the brief alone**, which needs no image at all.
4. **Wait for the reset** — say when, from the time of the first call.

Never suggest the paid PRO plan to get the quota back (rule 5).

### Not the default any more

| Source | State | Use |
|---|---|---|
| **Pollinations** | **HTTP 402 `Payment-Required` after one free image** (measured 2026-09-29) | Only if it answers 200. On 402, switch source — never pay (rule 5), and never paint over its watermark |
| **nano-banana MCP** | bills a Gemini API key | only on the user's explicit request |
| **mflux** (local FLUX on Apple Silicon, MIT) | not measured here — model size and speed unverified | an offline option to evaluate, not to recommend yet |
