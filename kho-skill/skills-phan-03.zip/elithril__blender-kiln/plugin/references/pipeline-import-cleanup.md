# Pipeline — [4] IMPORT and [5] CLEANUP

> Read before [4] IMPORT. Rule numbers are SKILL.md's Iron Rules.

## Contents
- [4] IMPORT
- [5] CLEANUP

## [4] IMPORT

```
get_scene_info() → import via execute_blender_code
→ get_scene_info(fields=["size", "ground"]) → verify the box   (rules 14, 24)
→ RENAME to SM_PascalCase, data-block to SM_..._Mesh   (rule 15)
→ center + normalize scale if needed (1 unit = 1 meter)
→ alert if dimensions seem wrong ("Asset is 0.002m tall. Scale issue?")
→ look(mode="angles", target=[name])     (rules 2, 22)
```

**Measure the pose (rule 13) — characters only.** Do it here, before anything
downstream assumes a rest pose. Measure **shoulder to hand**, never a horizontal
slice of the mesh: a slice picks up hip and thigh vertices and reported -17 deg
on a body whose arms were actually at -71 deg.

```python
cos = [v.co for v in mesh.data.vertices]
H = max(c.z for c in cos)
right = [c for c in cos if c.x > 0]
hand = max(right, key=lambda c: c.x)
torso_w = max(c.x for c in cos if abs(c.z - H * 0.75) < H * 0.02)
shoulder = max((c for c in right if abs(c.x - torso_w) < 0.03), key=lambda c: c.z)
angle = math.degrees(math.atan2(hand.z - shoulder.z, hand.x - shoulder.x))
```

**A big head (over a third of the height, a chibi): the slice at 0.75 × H is the head**, and the
snippet reads −54° on a true T-pose (kiln's mascot, the 3.0 bench's chibi). Measure the arm itself —
its axis between two sections, inner and outer, near the hand's height:

```python
hand = max(cos, key=lambda c: c.x)
def section(a, b):
    q = [c for c in cos if a * hand.x <= c.x <= b * hand.x and abs(c.z - hand.z) < 0.15 * H]
    return sum(q, Vector()) / len(q)
inner, outer = section(0.55, 0.65), section(0.85, 0.95)
angle = math.degrees(math.atan2(outer.z - inner.z, outer.x - inner.x))   # the mascot: -3.3 deg
```

| Angle | Pose | Action |
|---|---|---|
| within ±15 deg | T-pose | proceed |
| -15 to -45 deg | A-pose | convert — see `references/characters.md` § Converting a pose to T-pose |
| below -45 deg | I-pose, arms at the sides | convert; this is the hardest case, the arms touch the torso |

A T-pose also shows in the silhouette: **wingspan ≈ height**. The reference body
measured 1.68 m across for 1.69 m tall once converted.

**Rename on import — every method, not just scripted.** A marketplace download
lands under whatever name the source file carried (`ClassicNightstand_01`), and an
AI-generated mesh under whatever the importer chose. Neither satisfies rule 15, so
rename here, in IMPORT, before anything downstream reads the name:

```python
obj.name = "SM_ClassicNightstand"
obj.data.name = "SM_ClassicNightstand_Mesh"
```

**Frame before you screenshot.** `look(mode="angles", target=[name])` frames the target
itself. A viewport capture — `look()` in its default viewport mode, or
`get_viewport_screenshot` on older servers — captures the viewport as it is aimed. On a wide-angle view a 0.7 m prop is a handful of pixels at the
origin, so the screenshot rule 2 relies on shows an apparently empty scene — which
reads as "the operation deleted everything". Frame the subject first:

```python
bpy.ops.object.select_all(action='DESELECT')
obj.select_set(True)
bpy.context.view_layer.objects.active = obj
for area in bpy.context.screen.areas:
    if area.type == 'VIEW_3D':
        for region in area.regions:
            if region.type == 'WINDOW':
                with bpy.context.temp_override(area=area, region=region):
                    bpy.ops.view3d.view_selected()
```

**Output format:**
```
── ✅ IMPORT ────────────────────────────────
{name} │ {faces} faces │ {x}×{y}×{z}m │ {file_size}
```

For scripted assets: import is implicit (already in Blender).

## [5] CLEANUP

Load `references/validation-checklist.md` and execute:

Execute the full cleanup sequence from `references/validation-checklist.md` § Execution Order. Check poly budget against tier from `references/topology-rules.md`.

**Print set in CONFIG: not the same sequence.** Its 0.1 mm merge broke a printable model
(PASS → FAIL) while its own count read 0; the print variant is under § Execution Order —
no merge on a model built closed, `print_check` on the STL as the count, no tier decimation.

**Poly check:** report the count against the tier. Past **2× the tier's top** → **propose decimate with before/after** (always interactive, even in auto mode); below that, say where the triangles go and keep them.

**Thin parts are never decimated** — wires, bails, loops: anything an order of magnitude
thinner than the body. A simplifier breaks them whatever the budget, and silhouette scores do not see the
holes it leaves. Rebuild each as a curve with a round bevel along the
high-poly's centreline; decimate the body only. **After decimating, compare open and
non-manifold edge counts with before, and look at a close render of every thin part.**
More than before is a failed decimation: undo it, never split the fused edges to hide them.
On a closed shell (after a voxel remesh), decimate with Blender's Collapse: measured on a
115,600-tri remeshed shell to 5,400, Collapse stayed closed (0 / 0); meshoptimizer
(`gltfpack -si`) stalled at 13,900, and with `-sa` reached it with 54 non-manifold and 35
open edges. v3.0's bench repair of a TRELLIS GLB shipped 326 open edges that way.
**When Collapse at the tier's top damages thin parts, decimate less** — up to the 2× the Poly
check allows — or rebuild those parts; never go back to `-sa`. The same repair, both on
2026-10-23: one session called Collapse at 4,600 tris crumpled and shipped `-sa` (840
non-manifold, 641 open); the other kept Collapse at 9,000 (0 / 0, wires intact).

**A creature to animate:** its voxel skin goes through QuadriFlow (merge by distance first),
then the weights are checked on fixed poses before any loop is built by hand
(`references/characters.md` § Retopology: QuadriFlow first). No session did it unasked.

**Auto mode:** non-destructive cleanup runs automatically. Decimate remains interactive.
**Guided mode:** show each step, wait for validation.

**Print set in CONFIG:** after any repair (union, remesh, decimate), run `tools/print_check.py`
with `--reference` on the file it was repaired from (`references/print.md` § The tool): a
sealed, sliceable result can have lost most of the object, and only that comparison sees it.
