#!/usr/bin/env python3
"""Ready-made humanoid motions (walk, run, jump, dance, …) played on a kiln-named rig.

    python3 plugin/tools/presets.py list
    python3 plugin/tools/presets.py animate --asset SK_Child_rigged.glb --motion walk,run,jump,dance \\
        [--loop] [--speed 1.0] [--take A|B] [--out ./anim] [--stiff-fingers]

Writes {out}/{asset}_animated.glb with ONE clip per motion, named exactly as asked (`walk`,
`run`…) — with --loop, a cyclic motion gives two: the whole take (`run`, with its start and its
end, travelling) and its in-place cycle (`run_loop`) — {asset}_animated.measures.json (tools/motion_measure.py on every clip of the file
written) and {asset}_animated.provenance.json (where each motion comes from, its licence).

The clips are image-to-3dlab's (AssetFurnace) presets, generated once with NVIDIA Kimodo
(Kimodo-SOMA-RP-v1.1) for its 77-joint SOMA skeleton and shipped in tools/motions/: 21
motions in two takes (A, B), and a woman's walk — 43 clips, 2.1 MB. The retarget is
upstream's, adapted in tools/retarget.py (Apache-2.0, plugin/NOTICE). The motions:
"Licensed by NVIDIA Corporation under the NVIDIA Open Model License"; NVIDIA claims no
ownership of the outputs, and commercial use is allowed.

The rig must carry kiln's names (references/characters.md § Animation-ready skeleton), as
tools/autorig.py writes them: bones are found by name, not by the tree's shape.

`animate` runs Blender (BLENDER, then `blender` on PATH, then the macOS default) on this file;
inside Blender:

    blender --background --factory-startup --python-exit-code 1 --python presets.py -- \\
        animate --asset X_rigged.glb --motion walk ...

Standard library outside Blender.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
MOTIONS = HERE / "motions"
SOURCE = dict(
    name="image-to-3dlab (AssetFurnace) Animate presets",
    url="https://github.com/Bingeljell/image-to-3dlab",
    version="v0.4.4", commit="91879333e88a0571945b15b0e21e4bc95ec59e31",
    code_licence="Apache-2.0 (tools/retarget.py adapts scripts/kimodo_retarget.py and scripts/arm_clearance.py)",
    motion_generator="NVIDIA Kimodo, Kimodo-SOMA-RP-v1.1",
    motion_licence="Licensed by NVIDIA Corporation under the NVIDIA Open Model License; "
                   "NVIDIA claims no ownership of outputs; commercial use allowed",
)
# Motions that repeat, for which --loop adds a seamless in-place cycle. The rest are one-shots.
CYCLIC = ("idle", "walk", "walk_woman", "run", "sneak", "fight_stance")


def catalogue() -> dict:
    data = json.loads((MOTIONS / "presets.json").read_text())
    out = {}
    for p in data["presets"]:
        base = p["id"][:-2] if p["id"].endswith("_b") else p["id"]
        take = "B" if p["id"].endswith("_b") else "A"
        out.setdefault(base, {"seconds": p["seconds"], "prompt": p["prompt"], "takes": {}})
        out[base]["takes"][take] = p
    return out


def find_blender() -> str | None:
    for cand in (os.environ.get("BLENDER"), shutil.which("blender"),
                 "/Applications/Blender.app/Contents/MacOS/Blender"):
        if cand and Path(cand).exists():
            return cand
    return None


def cmd_list(_args) -> int:
    cat = catalogue()
    print(f"{len(cat)} motions, {sum(len(m['takes']) for m in cat.values())} clips "
          f"(Kimodo, NVIDIA Open Model License — commercial use allowed)")
    for name, m in cat.items():
        kind = "cycle" if name in CYCLIC else "one-shot"
        print(f"  {name:13s} {m['seconds']:>4} s  takes {'/'.join(sorted(m['takes'])):3s}  {kind:8s}  {m['prompt']}")
    return 0


def parse(argv):
    ap = argparse.ArgumentParser(prog="presets.py", description=__doc__.splitlines()[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("list")
    an = sub.add_parser("animate")
    an.add_argument("--asset", required=True, type=Path, help="kiln-named rigged GLB")
    an.add_argument("--motion", required=True, help="comma-separated, e.g. walk,run,jump,dance")
    an.add_argument("--out", type=Path, help="output folder (default: next to the asset)")
    an.add_argument("--loop", action="store_true", help="also cut each cyclic motion into a seamless in-place cycle, clip {motion}_loop")
    an.add_argument("--speed", type=float, default=1.0, help="play faster (>1) or slower (<1)")
    an.add_argument("--take", choices=("A", "B"), default="A")
    an.add_argument("--stiff-fingers", action="store_true", help="fingers follow the hand rigidly")
    an.add_argument("--calm", action="store_true", help="a calmer gait for walk, walk_woman, run, sneak: "
                    "hips, spine and head swing less (retarget.CALM) — for a chibi or a big head")
    an.add_argument("--blink", action="store_true", help="blinks in every clip, on the eye bones LeftEye/RightEye "
                    "(squashed along the face's up axis; LeftEyeShine/RightEyeShine shrink) — characters.md")
    an.add_argument("--no-measure", action="store_true", help="skip the measures JSON (faster)")
    an.add_argument("--no-fix", default="", help="leave out kiln's corrections, for comparison: feet,arms")
    return ap.parse_args(argv)


def check_motions(args) -> list[str]:
    cat = catalogue()
    names = [m.strip() for m in args.motion.split(",") if m.strip()]
    unknown = [m for m in names if m not in cat]
    if unknown:
        sys.exit(f"presets: no preset {unknown} — `presets.py list` shows the {len(cat)}; for anything else, "
                 "references/animation.md § Pick the route from the subject")
    if len(set(names)) != len(names):
        sys.exit("presets: a motion is asked twice")
    return names


def cmd_animate(args, argv) -> int:
    check_motions(args)
    blender = find_blender()
    if not blender:
        sys.exit("presets: Blender not found: set BLENDER=/path/to/blender")
    r = subprocess.run([blender, "--background", "--factory-startup", "--python-exit-code", "1",
                        "--python", str(Path(__file__).resolve()), "--", *argv])
    return r.returncode


# ── inside Blender ───────────────────────────────────────────────────────────────────────

def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


# Blinks (characters.md § Charm): 3 frames closing, 1 held, 4 opening at 24 fps — resampled to the
# clip's rate; one in a walk or a run, three in an idle with a double, one in any other clip of 2 s+.
BLINK = (0.35, 0.8, 1.0, 1.0, 0.75, 0.45, 0.2, 0.05)
BLINK_AT = {"idle": (0.25, 0.62), "walk": (0.6,), "walk_woman": (0.6,), "run": (0.6,), "sneak": (0.6,)}


def blink_frames(name: str, n: int, fps: float, looped: bool) -> list[float]:
    """How shut the eyes are on each of n frames (0 open, 1 shut). A loop's blinks stay clear of its seam."""
    curve = [BLINK[min(len(BLINK) - 1, int(i * 24 / fps))] for i in range(round(len(BLINK) * fps / 24))]
    at = BLINK_AT.get(name, (0.5,) if n / fps >= 2 else ())
    starts = [round(a * n) for a in at]
    if name == "idle" and starts:
        starts.append(starts[-1] + len(curve) + 2)      # a double
    k = [0.0] * n
    for s0 in starts:
        for i, v in enumerate(curve):
            if 0 <= s0 + i < n - (2 if looped else 0):
                k[s0 + i] = max(k[s0 + i], v)
    return k


def blender_animate(args) -> int:  # pragma: no cover - needs bpy
    import bpy
    import numpy as np
    from mathutils import Matrix

    sys.path.insert(0, str(HERE))
    import retarget as R

    names = check_motions(args)
    skip = {x.strip() for x in args.no_fix.split(",") if x.strip()}
    cat = catalogue()
    asset = args.asset.resolve()
    out = (args.out or asset.parent).resolve()
    out.mkdir(parents=True, exist_ok=True)
    stem = asset.stem
    path = out / f"{stem}_animated.glb"

    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.ops.import_scene.gltf(filepath=str(asset))
    arm = next((o for o in bpy.data.objects if o.type == "ARMATURE"), None)
    if arm is None:
        sys.exit(f"presets: {asset.name} has no armature — rig it first (tools/autorig.py)")
    bones = arm.data.bones
    parents = {b.name: (b.parent.name if b.parent else None) for b in bones}
    try:
        mapping = R.kiln_to_soma(parents)
    except R.MappingError as e:
        sys.exit(f"presets: {e}")
    if args.stiff_fingers:
        mapping = R.stiffen_fingers(mapping)
    arm_rot = np.array(arm.matrix_world.to_3x3().normalized())
    up = arm_rot.T @ np.array([0.0, 0.0, 1.0])
    inv = np.array(arm.matrix_world.inverted())
    points, owners, weights = [], [], []
    for mesh in (o for o in bpy.data.objects if o.type == "MESH" and o.find_armature() == arm):
        to_arm = inv @ np.array(mesh.matrix_world)
        gname = {g.index: g.name for g in mesh.vertex_groups}
        for v in mesh.data.vertices:
            best = max(v.groups, key=lambda g: g.weight, default=None)
            if best is None or gname.get(best.group) not in parents:
                continue
            points.append((to_arm @ np.append(np.array(v.co), 1.0))[:3])
            owners.append(gname[best.group])
            weights.append({gname[x.group]: x.weight for x in v.groups if x.weight > 0 and gname.get(x.group) in parents})
    rig = R.Rig(rest={b.name: np.array(b.matrix_local) for b in bones},
                tails={b.name: np.array(b.tail_local) for b in bones},
                parents=parents, up=up, points=np.array(points), owners=owners, weights=weights)
    arms_kiln = "arms" not in skip
    proxy = R.build_proxy(rig, mapping, R.BODY_ROLES, R.BODY_PERCENTILE, R.MAX_SWING_DEG) if arms_kiln else \
        R.build_proxy(rig, mapping, R.UPSTREAM_BODY_ROLES, R.UPSTREAM_BODY_PERCENTILE, 180.0)

    eyes = [s + "Eye" for s in ("Left", "Right") if s + "Eye" in bones]
    if args.blink and len(eyes) != 2:
        sys.exit("presets: --blink needs the bones LeftEye and RightEye (characters.md § Blink on flat eyes)")
    if args.blink:   # the eye bone's own axis that the face's up runs along: the squash axis
        mw = arm.matrix_world @ bones["LeftEye"].matrix_local
        squash = max(range(3), key=lambda i: abs(mw.col[i].z))
    sc = bpy.context.scene
    sc.render.fps, sc.render.fps_base = 30, 1
    for pb in arm.pose.bones:
        pb.rotation_mode = "QUATERNION"
    ad = arm.animation_data_create()
    report, prov = {}, []
    jobs = []                                      # (clip, motion, looped)
    for name in names:
        jobs.append((name, name, False))
        if args.loop and name in CYCLIC:
            jobs.append((f"{name}_loop", name, True))
        elif args.loop:
            print(f"presets: {name} is a one-shot, kept whole (not looped)")
    clips = [j[0] for j in jobs]
    for clip, name, looped in jobs:
        take = args.take if args.take in cat[name]["takes"] else "A"
        preset = cat[name]["takes"][take]
        npz = MOTIONS / f"{preset['id']}.npz"
        g, joints0, hips, fps = R.load_motion(npz)
        g, hips = R.resample(g, hips, args.speed)
        frames, info = R.retarget(rig, g, joints0, hips, mapping)
        contacts = R.soma_contacts(g, joints0, hips, fps, args.speed)
        tread, loop = None, None
        if looped:
            frames, contacts, tread, loop = R.cut_loop(rig, frames, contacts, fps, mapping)
        calmed = None
        if args.calm and name in R.GAITS:          # before the feet are locked: they go back where they stood
            frames, calmed = R.calm(rig, frames)
        swings = R.clear_arms(rig, frames, proxy, cyclic=looped,
                              upper_points=R.UPPER_ARM_POINTS if arms_kiln else ()) if proxy else {}
        swing = None
        if "feet" not in skip:                     # toes no longer pointing down in the air; lock_feet then plants them
            frames, swing = R.ease_swing_feet(rig, frames, contacts, cyclic=looped)
        feet = R.lock_feet(rig, frames, fps, contacts, cyclic=looped, tread=tread) if "feet" not in skip else {}
        if looped:
            frames = frames + [frames[0]]          # key P = key 0 (animation.md rule 5)
        act = bpy.data.actions.new(clip)
        ad.action = act
        for t, basis in enumerate(R.bases(rig, frames)):
            for b, mtx in basis.items():
                pb = arm.pose.bones[b]
                pb.matrix_basis = Matrix(mtx.tolist())
                pb.keyframe_insert("rotation_quaternion", frame=t)
                if parents[b] is None:
                    pb.keyframe_insert("location", frame=t)
        if args.blink:
            blinks = blink_frames(name, len(frames), fps, looped)
            for side in ("Left", "Right"):
                pe, ps = arm.pose.bones[side + "Eye"], arm.pose.bones.get(side + "EyeShine")
                for t in range(len(frames)):
                    k = blinks[t]
                    sc_ = [1.0, 1.0, 1.0]; sc_[squash] = 1.0 - 0.9 * k
                    pe.scale = sc_; pe.keyframe_insert("scale", frame=t)
                    if ps:
                        g = max(0.0, 1.0 - 2.0 * k); ps.scale = (g, g, g); ps.keyframe_insert("scale", frame=t)
        track = ad.nla_tracks.new()
        track.name = clip
        strip = track.strips.new(clip, 0, act)
        if getattr(act, "slots", None) and hasattr(strip, "action_slot"):
            strip.action_slot = act.slots[0]
        ad.action = None
        report[clip] = dict(frames=len(frames), seconds=round((len(frames) - 1) / fps, 2),
                            hip_scale=round(info["hip_scale"], 3), arm_swing=swings, feet=feet, swing_foot_pitch=swing,
                            loop=loop, calm=calmed, blinks=args.blink and sum(
                                1 for t in range(1, len(frames)) if blinks[t] >= 1.0 > blinks[t - 1]))
        prov.append(dict(clip=clip, preset=preset["id"], take=take, prompt=preset["prompt"],
                         made_with=preset["made_with"], seed=preset["seed"], speed=args.speed,
                         looped=bool(looped), root_speed_m_s=loop and loop["root_speed_m_s"],
                         frames=len(frames), fps=fps, file=f"tools/motions/{npz.name}", sha256=sha256(npz)))
        print(f"presets: {clip} {json.dumps(report[clip])}")
    for pb in arm.pose.bones:
        pb.matrix_basis = Matrix.Identity(4)
    sc.frame_start, sc.frame_end = 0, max(r["frames"] for r in report.values()) - 1
    # the meshes at the scene's root, their Armature modifier kept: under the armature's node, the glTF
    # validator reports NODE_SKINNED_MESH_NON_ROOT on every one (pipeline-optimize-export.md)
    for o in [o for o in bpy.data.objects if o.type == "MESH" and o.parent == arm]:
        m = o.matrix_world.copy(); o.parent = None; o.matrix_world = m
    bpy.ops.export_scene.gltf(filepath=str(path), export_format="GLB", export_animations=True,
                              export_animation_mode="NLA_TRACKS", export_force_sampling=True)
    print(f"presets: {path} — clips {[t.name for t in ad.nla_tracks]}")
    (out / f"{stem}_animated.provenance.json").write_text(json.dumps(dict(
        output=path.name, asset=asset.name, asset_sha256=sha256(asset), source=SOURCE,
        notice="Motions: Licensed by NVIDIA Corporation under the NVIDIA Open Model License. "
               "Retarget: adapted from image-to-3dlab (Apache-2.0). See blender-kiln plugin/NOTICE.",
        clips=prov), indent=1))
    if not args.no_measure:
        import motion_measure as M
        measures = {}
        for clip in clips:
            measures[clip] = M.measure(str(path), name=clip)
            measures[clip]["presets"] = report[clip]
            fs, fl, sk = measures[clip]["foot_slide"], measures[clip]["floor"], measures[clip]["skin"]
            print(f"presets: measured {clip}: slide {fs['mm_s']} mm/s, below floor {fl['below_mm']} mm, "
                  f"arms in body {sk['mean_arm_body_mm2']} mm², seam {measures[clip]['seam_x_step']}x a step")
        (out / f"{stem}_animated.measures.json").write_text(json.dumps(measures, indent=1))
    return 0


def main() -> int:
    if "--" in sys.argv:                              # inside Blender
        argv = sys.argv[sys.argv.index("--") + 1:]
        return blender_animate(parse(argv))
    argv = sys.argv[1:]
    args = parse(argv)
    if args.cmd == "list":
        return cmd_list(args)
    return cmd_animate(args, argv)


if __name__ == "__main__":
    sys.exit(main())
