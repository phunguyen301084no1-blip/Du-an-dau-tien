#!/usr/bin/env python3
"""Check that the skill's own documentation is still true.

Text only: no Blender, no network, runs in seconds. Every check here exists
because the corresponding mistake was actually made in this repository — the
comments say which.

    python3 plugin/tools/verify_docs.py

The plugin lives in plugin/ (what an install ships); the repository around it holds
the README, the CI, the bench and the marketplace. Paths resolve against the root of
the file that names them: README and repository files against the repository, the
skill's own docs against the plugin.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

PLUGIN = Path(__file__).resolve().parent.parent
REPO = PLUGIN.parent
SKILL = PLUGIN / "SKILL.md"
README = REPO / "README.md"
BATCH = PLUGIN / "references" / "batch-mode.md"
DOCS = [SKILL, README] + sorted((PLUGIN / "references").glob("*.md"))

failures: list[str] = []
notes: list[str] = []


def fail(check: str, msg: str) -> None:
    failures.append(f"{check}: {msg}")


def rule_block(path: Path, header: str) -> dict[int, str]:
    """Parse a fenced, numbered iron-rules block into {number: text}."""
    text = path.read_text()
    if header not in text:
        fail("rules", f"{path.name} has no section {header!r}")
        return {}
    body = text[text.index(header):]
    body = body[body.index("```") + 3:]
    body = body[:body.index("```")]
    out: dict[int, str] = {}
    num, cur = None, []
    for line in body.split("\n"):
        m = re.match(r"^\s*(\d+)\.\s+(.*)", line)
        if m:
            if num is not None:
                out[num] = " ".join(cur)
            num, cur = int(m.group(1)), [m.group(2)]
        elif num is not None and line.strip():
            cur.append(line.strip())
    if num is not None:
        out[num] = " ".join(cur)
    return out


# ── 1. Iron rules form one unbroken sequence.
# Three renumberings happened here; two left the sequence or a reference wrong.
core = rule_block(SKILL, "## Iron Rules")
batch = rule_block(BATCH, "### Iron Rules (batch-specific)")
rules = {**core, **batch}
if rules:
    expected = list(range(1, len(rules) + 1))
    if sorted(rules) != expected:
        missing = set(expected) - set(rules)
        dupes = [n for n in rules if list(rules).count(n) > 1]
        fail("rules", f"not a 1..N sequence — missing {sorted(missing)}, repeated {dupes}")
    else:
        notes.append(f"rules: {len(core)} core + {len(batch)} batch = {len(rules)}, unbroken")

# ── 2. Every cited rule number exists.
cited: dict[int, list[str]] = {}
for doc in DOCS:
    for m in re.finditer(r"\b[Rr]ules?\s+(\d+)\b", doc.read_text()):
        cited.setdefault(int(m.group(1)), []).append(doc.name)
unknown = {n: srcs for n, srcs in cited.items() if n not in rules}
if unknown:
    for n, srcs in sorted(unknown.items()):
        fail("xref", f"rule {n} cited in {sorted(set(srcs))} does not exist")
else:
    notes.append(f"xref: {len(cited)} distinct rule numbers cited, all resolve")

# ── 3. Cited rules mean what the citation claims.
# A renumbering left rule 28 pointing at a "Rule 23 (no prompts)" that had
# become the get_object_info rule. Resolving is not enough; the sense matters.
SEMANTIC = {
    "no prompts": "prompt",
    "frame the viewport": "frame",
    "integration status": "integration",
    "get_object_info": "get_object_info",
    "naming convention": "nam",
}
for doc in DOCS:
    text = doc.read_text()
    for phrase, expect in SEMANTIC.items():
        # Tight window only. A 40-char window matched "Rule 6 is overridden —
        # Rule 28 (no prompts)" against rule 6, which is a false positive, and a
        # check that fires on correct text gets ignored.
        for m in re.finditer(rf"[Rr]ule\s+(\d+)\s*\(?{re.escape(phrase)}", text):
            n = int(m.group(1))
            if n in rules and expect.lower() not in rules[n].lower():
                fail("semantics", f"{doc.name} says rule {n} is about {phrase!r}, "
                                  f"but rule {n} reads {rules[n][:60]!r}")

# A table row that names a tool and cites a rule must cite the rule that names
# that tool. The tool-surface table survived a renumbering pointing its status
# row at rule 22 (framing) and get_object_info at rule 23 (integration status),
# because the phrase-based check above only reads "Rule N (phrase" forms.
for doc in DOCS:
    for i, line in enumerate(doc.read_text().split("\n"), 1):
        m = re.match(r"^\|\s*`([a-z_]+)`[^|]*\|\s*[Rr]ule\s+(\d+)\b", line)
        if not m:
            continue
        tool, n = m.group(1), int(m.group(2))
        if n in rules and tool not in rules[n]:
            fail("semantics", f"{doc.name}:{i} row `{tool}` cites rule {n}, which does not "
                              f"mention {tool}: {rules[n][:60]!r}")

# The README's key-rules list names each rule by number. It was once a Markdown
# ordered list, which renumbers itself 1, 2, 3: twelve of its thirteen entries
# pointed at the wrong rule. Now every "**Rule N**" bullet must share its code
# spans with rule N's text — a mis-numbered entry names a tool the rule lacks.
for i, line in enumerate(README.read_text().split("\n"), 1):
    m = re.match(r"^- \*\*Rule (\d+)\*\* — (.*)", line)
    if not m:
        continue
    n = int(m.group(1))
    spans = re.findall(r"`([^`]+)`", m.group(2))
    body = rules.get(n, "")
    for span in spans:
        key = span.split("(")[0].split("=")[0]
        if key and key not in body:
            fail("semantics", f"README.md:{i} says rule {n} is about `{span}`, "
                              f"but rule {n} reads {body[:60]!r}")

_rd = README.read_text()
# A heading, or a folded <details> block whose summary names it (README 3.0 folds its reference).
_m = re.search(r"^## Iron rules\n|<summary><b>Iron rules</b></summary>", _rd, re.M)
if not _m:
    fail("semantics", "README.md has no Iron rules section (a `## Iron rules` heading or a <details> "
                      "block summarised `Iron rules`): the key-rules checks would check nothing")
_sec = _rd[_m.start():] if _m else ""
_ends = [i for i in (_sec.find("\n## ", 4), _sec.find("</details>")) if i > 0]
_sec = _sec[:min(_ends)] if _ends else _sec
if re.search(r"^\d+\. ", _sec, re.M):
    fail("semantics", "README.md § Iron rules uses an ordered list — Markdown renumbers it "
                      "1, 2, 3 whatever the rule numbers; write '- **Rule N** — …'")

# ── 4. The rule count advertised in the README matches reality.
m = re.search(r"enforces (\d+) rules \((\d+) core \+ (\d+) batch", README.read_text())
if not m:
    fail("count", "README does not state the rule count in the expected form")
elif (int(m.group(1)), int(m.group(2)), int(m.group(3))) != (len(rules), len(core), len(batch)):
    fail("count", f"README says {m.group(1)} ({m.group(2)}+{m.group(3)}), "
                  f"actual {len(rules)} ({len(core)}+{len(batch)})")
else:
    notes.append(f"count: README matches at {len(rules)}")

# ── 4b. Per-file line counts in the structure table.
# Three of twelve had drifted by 23-54% after eight pull requests. The total was
# checked; the rows were not, which is how a stale number survives a review.
for m in re.finditer(r"\| `(?:plugin/)?references/([\w.-]+)` \|[^|]+\| ~(\d+) \|", README.read_text()):
    name, claimed = m.group(1), int(m.group(2))
    ref = PLUGIN / "references" / name
    if not ref.exists():
        fail("counts", f"README lists references/{name}, which does not exist")
        continue
    actual = len(ref.read_text().split("\n"))
    if abs(actual - claimed) / max(claimed, 1) > 0.15:
        fail("counts", f"references/{name}: README says ~{claimed}, actual {actual}")

# The tools' rows drifted the same way, unchecked: fidelity_check.py said ~245 at 685 lines.
for m in re.finditer(r"\| `plugin/tools/([\w.-]+)` \|[^|]+\| ~(\d+) \|", README.read_text()):
    name, claimed = m.group(1), int(m.group(2))
    tool = PLUGIN / "tools" / name
    if not tool.exists():
        fail("counts", f"README lists tools/{name}, which does not exist")
        continue
    actual = len(tool.read_text().split("\n"))
    if abs(actual - claimed) / max(claimed, 1) > 0.15:
        fail("counts", f"tools/{name}: README says ~{claimed}, actual {actual}")

m = re.search(r"\*\*Total: ~([\d,]+) lines\*\*", README.read_text())
if m:
    claimed = int(m.group(1).replace(",", ""))
    actual = sum(len(f.read_text().split("\n"))
                 for f in [SKILL] + sorted((PLUGIN / "references").glob("*.md")))
    if abs(actual - claimed) / max(claimed, 1) > 0.15:
        fail("counts", f"README total says ~{claimed:,}, actual {actual:,}")
    else:
        notes.append(f"counts: structure table within 15% ({actual:,} lines)")

# ── 4c. Stated minimum Blender versions do not contradict each other.
# The README badge said "4.x+" while its own Reproduce section said "Needs
# Blender 5.x", and nothing had ever been run on 4.x.
#
# Three attempts at this check, and the shape is the scar tissue. Matching every
# "Blender N.N" flagged history: "Since Blender 4.0+, bone layers were replaced"
# requires nothing. Blacklisting history words then silenced the check entirely,
# because the real requirement lines say "verified" and "measured on" too. A
# blacklist of history phrasings is unbounded — any new way of writing history
# defeats it. So this is a WHITELIST of requirement phrasings: the version has to
# be the thing being demanded, not a qualifier on an API note. "Blender 4.4+:
# F-curves live in a channelbag" and "(Blender 4.x+)" state where a feature
# exists and are correctly invisible here.
FLOOR = re.compile(
    r"(?:needs?|requires?|minimum)\s+(?:of\s+)?Blender\s*v?(\d+\.(?:\d+|x))"
    r"|Blender\s*v?(\d+\.(?:\d+|x))\+?\s+or\s+(?:newer|later|above)"
    r"|badge/Blender-(\d+\.(?:\d+|x))",
    re.I)
floors: dict[str, set[str]] = {}
for doc in DOCS:
    for line in doc.read_text().split("\n"):
        for m in FLOOR.finditer(line):
            floors.setdefault(next(g for g in m.groups() if g), set()).add(doc.name)
if not floors:
    fail("versions", "no minimum Blender version is stated as a requirement — "
                     "the README must say what it needs")
elif len(floors) > 1:
    fail("versions", f"more than one minimum stated: "
                     f"{ {k: sorted(v) for k, v in floors.items()} }")
else:
    v, where = next(iter(floors.items()))
    notes.append(f"versions: one stated minimum, Blender {v}+ "
                 f"(stated in {', '.join(sorted(where))})")

# ── 5. Referenced files exist.
# SKILL.md once pointed at ../creative-excellence/ and two other skills that
# existed nowhere, and outside the plugin directory besides.
for doc in DOCS:
    base = REPO if doc == README else PLUGIN
    for m in re.finditer(r"`((?:\.\./|plugin/|references/|examples/|tools/|studio/|docs/)[\w./-]+\.\w+)`", doc.read_text()):
        rel = m.group(1)
        if rel.startswith("../"):
            fail("paths", f"{doc.name} references {rel} — outside the plugin directory")
        elif not (base / rel).exists():
            fail("paths", f"{doc.name} references {rel}, which does not exist")

# ── 6. README images resolve.
imgs = re.findall(r'src="([^"]+\.(?:webp|png|jpg))"', README.read_text())
missing_imgs = [i for i in imgs if not (REPO / i).exists()]
if missing_imgs:
    fail("images", f"missing: {missing_imgs}")
else:
    notes.append(f"images: {len(imgs)}/{len(imgs)} resolve")

# ── 7. No bare pip3 install.
# All six in this repo failed on any PEP 668 Python, including the very first
# command the recommended path proposed.
for doc in DOCS:
    for i, line in enumerate(doc.read_text().split("\n"), 1):
        # No backtick exemption: a prescription in markdown IS written in
        # backticks, and the old lookbehind let `pip3 install gradio_client`
        # through in the README for the whole audit. Exempt only the forms that
        # are actually correct — a venv path, uv pip — and prose that is
        # explicitly warning about bare pip.
        if re.search(r"\bpip3?\s+install\b", line) \
           and "venv" not in line \
           and not re.search(r"\buv\s+pip\b", line) \
           and not re.search(r"fail|never|not enough|instead|PEP 668|bare pip", line, re.I):
            fail("pip", f"{doc.name}:{i} bare pip install — use a venv: {line.strip()[:70]}")

# ── 7b. Every headless Blender command fails loud.
# Blender exits 0 when a --python script raises, unless given
# --python-exit-code; an explicit sys.exit(1) does propagate. So a crash in
# verify_blender.py outside its try blocks passed CI green, and the skill's own
# headless export fallback (rule 21) reported a failed export as a success.
# Only commands are checked — code fences in docs, and command lines in scripts
# and workflows — not prose that names the command in passing.
CMD_FILES = DOCS + [REPO / "CONTRIBUTING.md"] \
    + sorted((REPO / ".github" / "workflows").glob("*.yml")) \
    + sorted((REPO / "examples").rglob("*.sh")) + sorted((REPO / "examples").rglob("*.py")) \
    + sorted((PLUGIN / "tools").glob("*.py"))
blender_cmds = 0
for f in CMD_FILES:
    if not f.exists() or f.name == "verify_docs.py" or f.name.startswith("test_"):
        continue
    md = f.suffix == ".md"
    in_fence = False
    logical, start = "", 0
    for i, line in enumerate(f.read_text().split("\n"), 1):
        if md and line.lstrip().startswith("```"):
            in_fence = not in_fence
            continue
        if md and not in_fence:
            continue
        if not logical:
            start = i
        logical += line.rstrip("\\") + " "
        if line.rstrip().endswith("\\"):
            continue
        cmd, logical = logical.strip(), ""
        if not re.match(r'^(blender|"?\$BLENDER"?|\S*/Blender)\b', cmd):
            continue
        if "--background" not in cmd or "--python" not in cmd:
            continue
        blender_cmds += 1
        if "--python-exit-code" not in cmd:
            fail("exitcode", f"{f.relative_to(REPO)}:{start} headless Blender without "
                             f"--python-exit-code 1 — a crash would exit 0: {cmd[:70]}")
notes.append(f"exitcode: {blender_cmds} headless Blender command(s), all fail loud")

# ── 8. The plugin manifest is loadable and self-consistent.
mf = REPO / ".claude-plugin" / "marketplace.json"
if not mf.exists():
    fail("manifest", "marketplace.json is missing")
else:
    try:
        data = json.loads(mf.read_text())
    except json.JSONDecodeError as e:
        fail("manifest", f"invalid JSON: {e}")
        data = None
    if data:
        if not isinstance(data.get("owner"), dict):
            fail("manifest", "owner must be an object, per the marketplace schema")

        # The version lives in two manifests and a release edits both by hand. A
        # mismatch installs the plugin under the wrong number, silently, while
        # every other check passes.
        pj = PLUGIN / ".claude-plugin" / "plugin.json"
        if pj.exists():
            pv = json.loads(pj.read_text()).get("version")
            mv = (data.get("metadata") or {}).get("version")
            if pv != mv:
                fail("manifest", f"manifest versions disagree: "
                                 f"plugin.json {pv!r} vs marketplace.json {mv!r}")
            elif pv:
                notes.append(f"manifest: both manifests agree on version {pv}")

        for plugin in data.get("plugins", []):
            src = plugin.get("source")
            if not isinstance(src, str) or not src.startswith("./"):
                fail("manifest", f"source {src!r} must be a path starting with ./")
            elif not (REPO / src).is_dir():
                fail("manifest", f"source {src!r} is not a directory")
            elif not (REPO / src / "SKILL.md").exists():
                # A SKILL.md at the plugin root is what makes the source load as a skill.
                fail("manifest", f"source {src!r} has no SKILL.md at its root")
            elif not (REPO / src / ".claude-plugin" / "plugin.json").exists():
                fail("manifest", f"source {src!r} has no .claude-plugin/plugin.json")

# ── 9. Documented slash commands use the form that actually resolves.
# Twelve /kiln:<sub> commands were documented; a colon addresses plugin:skill,
# so none of them resolved to anything.
for doc in DOCS:
    for i, line in enumerate(doc.read_text().split("\n"), 1):
        if re.search(r"/kiln:[a-z]", line) and not re.search(
                r"colon|resolve|never tell|Unknown command|instead", line, re.I):
            fail("commands", f"{doc.name}:{i} uses /kiln:<sub>; the invocable form is "
                             f"/kiln <sub>: {line.strip()[:70]}")

print("── verify_docs")
for n in notes:
    print(f"  ok   {n}")
for f in failures:
    print(f"  FAIL {f}")
print(f"── {len(failures)} failure(s)")
sys.exit(1 if failures else 0)
