#!/usr/bin/env python3
"""Seed what fidelity_check.py claims to measure, and check it does.

    python3 tools/test_fidelity_check.py            # needs Blender at $BLENDER or the macOS default

Every session reviewing against a reference trusts this tool's numbers, so it gets
the same treatment as verify_docs.py: known inputs, known answers. No network — the
test writes its own tiny HDRI. Cases:

- a model measured against its own render: IoU near 1, no shape gap;
- the same model 20 % wider: the width gap is reported, and close to +20 %;
- its lower body 14 % wider, a camera 15° above: told as the photo's perspective, last; with no
  elevation, a shape gap (3.0's lantern narrowed its tubes for such a gap and lost 0.05 IoU);
- a texture that is not loaded: refused, exit 1 — it would render black;
- a reference with no transparency (a phone photo on its white table): refused, exit 1 —
  measured as it was, a pumpkin scored 0.62 instead of 0.93, with exit 0;
- a .blend: measured, with the warning that the shipped file is what counts;
- --max-tris: a guide, not a cap — under twice the limit listed last and kept, past it a
  reduction proposed; silent below;
- a metal with a dark base colour: reported — it renders as a black mirror (lantern v7);
  the same colour as non-metal, and a bright metal, silent;
- a metallic mask in hard-edged scattered islands: reported (lantern v9's camouflage); one
  soft region, silent; a metal painted mostly as non-metal: reported (v10's grey tank);
- joints: a rod's flat end resting on a sphere is rendered up close (two views); a rod sunk
  into it, and a free one, are not;
- --view and --azimuth on a 2 x 1 x 1 box: 2:1 from the front, 1:1 from the side or at 90°,
  and 2.12:1 at 45° (2 cos 45° + sin 45°) — the 3/4 view most product photos are;
- face details, on a vase with two dark eyes and a mouth: its own render matches them in
  place; the same vase without them keeps its silhouette IoU but scores 0 and every detail
  is reported missing; the face 3 cm lower is reported lower, by about that much, and still
  matches once slid; a reference one stop brighter changes nothing.
"""
import hashlib, json, os, subprocess, sys, tempfile

BLENDER = os.environ.get("BLENDER", "/Applications/Blender.app/Contents/MacOS/Blender")
TOOL = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fidelity_check.py")

BUILD = r'''
import bpy, sys, math
d = sys.argv[sys.argv.index("--") + 1]
def fresh():
    bpy.ops.wm.read_factory_settings(use_empty=True)
def vase(sx=1.0):
    fresh()
    bpy.ops.mesh.primitive_cylinder_add(vertices=48, radius=0.1, depth=0.3, location=(0, 0, 0.15))
    bpy.ops.mesh.primitive_cone_add(vertices=48, radius1=0.1, radius2=0.03, depth=0.15, location=(0, 0, 0.375))
    for o in bpy.context.scene.objects:
        o.scale.x = sx
    m = bpy.data.materials.new("m"); m.use_nodes = True
    m.node_tree.nodes["Principled BSDF"].inputs["Base Color"].default_value = (0.4, 0.2, 0.1, 1)
    for o in bpy.context.scene.objects:
        o.data.materials.append(m)
def export(path):
    bpy.ops.export_scene.gltf(filepath=path, export_format="GLB")
# the HDRI: a small flat-grey Radiance file
img = bpy.data.images.new("env", 16, 8, float_buffer=True)
img.pixels = [0.8, 0.8, 0.8, 1.0] * (16 * 8)
img.filepath_raw = f"{d}/env.hdr"; img.file_format = "HDR"; img.save()
vase(1.0); export(f"{d}/vase.glb"); bpy.ops.wm.save_as_mainfile(filepath=f"{d}/vase.blend")
vase(1.2); export(f"{d}/vase_wide.glb")
vase(1.0)
for o in bpy.context.scene.objects:
    if o.location.z < 0.2: o.scale.x = 1.14   # the lower body 14 % wider: a photo's perspective
export(f"{d}/vase_foot.glb")
# the reference: the vase's own silhouette, front, orthographic, alpha — as a photo would be
vase(1.0)
cam = bpy.data.objects.new("c", bpy.data.cameras.new("c")); bpy.context.scene.collection.objects.link(cam)
cam.data.type = "ORTHO"; cam.data.ortho_scale = 0.46
cam.location = (0, -2, 0.225); cam.rotation_euler = (math.pi / 2, 0, 0); bpy.context.scene.camera = cam
sc = bpy.context.scene; sc.render.engine = "BLENDER_WORKBENCH"; sc.render.film_transparent = True
sc.render.resolution_x = sc.render.resolution_y = 512; sc.render.image_settings.color_mode = "RGBA"
sc.render.filepath = f"{d}/ref.png"; bpy.ops.render.render(write_still=True)
# the same vase photographed from 15 deg above (still orthographic: only the elevation differs)
e = math.radians(15); cam.location = (0, -2 * math.cos(e), 0.225 + 2 * math.sin(e)); cam.rotation_euler = (math.pi / 2 - e, 0, 0)
sc.render.filepath = f"{d}/ref_high.png"; bpy.ops.render.render(write_still=True)
cam.location = (0, -2, 0.225); cam.rotation_euler = (math.pi / 2, 0, 0)
# a model whose texture points nowhere
fresh(); bpy.ops.mesh.primitive_cube_add(); o = bpy.context.object
m = bpy.data.materials.new("lost"); m.use_nodes = True
t = m.node_tree.nodes.new("ShaderNodeTexImage"); t.image = bpy.data.images.new("lost", 8, 8)
t.image.source = "FILE"; t.image.filepath = "/nonexistent/lost.png"; o.data.materials.append(m)
bpy.ops.wm.save_as_mainfile(filepath=f"{d}/lost.blend")
# metals: a dark metal — textured, as a bake ships, through the GLB — must be reported; the
# same base colour as non-metal, and a bright metal, must not
def metal_vase(name, base, metallic):
    vase(1.0)
    m = bpy.data.materials["m"]; nt = m.node_tree; b = nt.nodes["Principled BSDF"]
    img = bpy.data.images.new(name, 8, 8); img.pixels = [*base, 1.0] * 64
    img.filepath_raw = f"{d}/{name}.png"; img.file_format = "PNG"; img.save()
    t = nt.nodes.new("ShaderNodeTexImage"); t.image = img; nt.links.new(t.outputs["Color"], b.inputs["Base Color"])
    b.inputs["Metallic"].default_value = metallic
    export(f"{d}/{name}.glb")
metal_vase("dark_metal", (0.05, 0.04, 0.03), 1.0)
metal_vase("dark_paint", (0.05, 0.04, 0.03), 0.0)
metal_vase("bright_metal", (0.45, 0.35, 0.20), 1.0)
# metallic masks, bright metal: hard-edged scattered islands (lantern v9) must be reported;
# one soft region following the height — wear on the lower half — must not
import random
def masked_vase(name, mask):
    vase(1.0)
    m = bpy.data.materials["m"]; nt = m.node_tree; b = nt.nodes["Principled BSDF"]
    b.inputs["Base Color"].default_value = (0.45, 0.35, 0.20, 1)
    img = bpy.data.images.new(name, 256, 256); img.pixels = [c for v in mask for c in (v, v, v, 1.0)]
    img.filepath_raw = f"{d}/{name}.png"; img.file_format = "PNG"; img.save()
    t = nt.nodes.new("ShaderNodeTexImage"); t.image = img; t.image.colorspace_settings.name = "Non-Color"
    nt.links.new(t.outputs["Color"], b.inputs["Metallic"])
    export(f"{d}/{name}.glb")
random.seed(1)
cells = [[random.random() < 0.35 for _ in range(32)] for _ in range(32)]   # 8-texel islands, at 256 px
masked_vase("confetti", [1.0 if cells[y // 8][x // 8] else 0.0 for y in range(256) for x in range(256)])
masked_vase("soft_wear", [min(1.0, max(0.0, (200 - y) / 64)) for y in range(256) for x in range(256)])   # mean 0.66
masked_vase("mostly_painted", [min(1.0, max(0.0, (90 - y) / 64)) for y in range(256) for x in range(256)])   # mean 0.23
# grain: a vase textured with fine noise, rendered under the HDRI as the "photo"; the same
# vase plain must read too clean against it, the textured one must not
import random as _r
_r.seed(3)
noise = [0.25 + 0.5 * _r.random() for _ in range(256 * 256)]
masked_vase("grainy", [1.0] * (256 * 256))
m = bpy.data.materials["m"]; nt = m.node_tree; b = nt.nodes["Principled BSDF"]
img = bpy.data.images.new("grain", 256, 256); img.pixels = [c for v in noise for c in (v, v * 0.8, v * 0.6, 1.0)]
img.filepath_raw = f"{d}/grain.png"; img.file_format = "PNG"; img.save()
t = nt.nodes.new("ShaderNodeTexImage"); t.image = img; nt.links.new(t.outputs["Color"], b.inputs["Base Color"])
b.inputs["Metallic"].default_value = 0.0; b.inputs["Roughness"].default_value = 0.6
export(f"{d}/grainy.glb")
w = bpy.data.worlds.new("w"); bpy.context.scene.world = w
env = w.node_tree.nodes.new("ShaderNodeTexEnvironment"); env.image = bpy.data.images.load(f"{d}/env.hdr")
w.node_tree.links.new(env.outputs["Color"], w.node_tree.nodes["Background"].inputs["Color"])
cam = bpy.data.objects.new("c", bpy.data.cameras.new("c")); bpy.context.scene.collection.objects.link(cam)
cam.data.type = "ORTHO"; cam.data.ortho_scale = 0.46; cam.location = (0, -2, 0.225); cam.rotation_euler = (math.pi / 2, 0, 0)
sc = bpy.context.scene; sc.camera = cam; sc.render.engine = "CYCLES"; sc.cycles.samples = 16; sc.render.film_transparent = True
sc.render.resolution_x = sc.render.resolution_y = 512; sc.render.image_settings.color_mode = "RGBA"
sc.view_settings.view_transform = "Standard"; sc.render.filepath = f"{d}/ref_grainy.png"; bpy.ops.render.render(write_still=True)
vase(1.0); bpy.data.materials["m"].node_tree.nodes["Principled BSDF"].inputs["Roughness"].default_value = 0.6
export(f"{d}/plain.glb")
# joints: a rod whose flat end rests on a sphere (to render), one sunk into it, one free
def rods(name, z_bottom):
    fresh()
    bpy.ops.mesh.primitive_uv_sphere_add(radius=0.1, location=(0, 0, 0.1))
    bpy.ops.mesh.primitive_cylinder_add(vertices=16, radius=0.008, depth=0.2, location=(0, 0, z_bottom + 0.1))
    export(f"{d}/{name}.glb")
rods("rod_resting", 0.1993)   # the UV sphere is faceted: 0.8 mm under its pole at 8 mm out
rods("rod_sunk", 0.17)
rods("rod_free", 0.25)
# face details: a vase with two dark eyes and a mouth on its front (the pumpkin whose carved
# face the silhouette could not see); the reference is its own Cycles render, then one stop
# brighter; the models: the same, the vase alone, the face 3 cm lower
def face_vase(name, dz=0.0, features=True):
    vase(1.0)
    if features:
        dark = bpy.data.materials.new("dark"); dark.use_nodes = True
        dark.node_tree.nodes["Principled BSDF"].inputs["Base Color"].default_value = (0.02, 0.02, 0.02, 1)
        for x, z, sx, sz in ((-0.045, 0.22, 0.03, 0.04), (0.045, 0.22, 0.03, 0.04), (0.0, 0.12, 0.1, 0.02)):
            bpy.ops.mesh.primitive_cube_add(size=1, location=(x, -0.1, z + dz)); b = bpy.context.object
            b.scale = (sx, 0.01, sz); b.data.materials.append(dark)
    export(f"{d}/{name}.glb")
face_vase("face"); face_vase("face_blank", features=False); face_vase("face_low", dz=-0.03)
face_vase("face")
w = bpy.data.worlds.new("w"); bpy.context.scene.world = w
env = w.node_tree.nodes.new("ShaderNodeTexEnvironment"); env.image = bpy.data.images.load(f"{d}/env.hdr")
w.node_tree.links.new(env.outputs["Color"], w.node_tree.nodes["Background"].inputs["Color"])
cam = bpy.data.objects.new("c", bpy.data.cameras.new("c")); bpy.context.scene.collection.objects.link(cam)
cam.data.type = "ORTHO"; cam.data.ortho_scale = 0.46; cam.location = (0, -2, 0.225); cam.rotation_euler = (math.pi / 2, 0, 0)
sc = bpy.context.scene; sc.camera = cam; sc.render.engine = "CYCLES"; sc.cycles.samples = 16; sc.render.film_transparent = True
sc.render.resolution_x = sc.render.resolution_y = 512; sc.render.image_settings.color_mode = "RGBA"
sc.view_settings.view_transform = "Standard"; sc.render.filepath = f"{d}/ref_face.png"; bpy.ops.render.render(write_still=True)
sc.view_settings.exposure = 1.0; sc.render.filepath = f"{d}/ref_face_bright.png"; bpy.ops.render.render(write_still=True)
# a 2 x 1 x 1 box: 2 m along X, so front is 2:1 and left is 1:1
fresh(); bpy.ops.mesh.primitive_cube_add(size=1, location=(0, 0, 0.5)); bpy.context.object.scale = (2, 1, 1)
bpy.ops.object.transform_apply(scale=True); export(f"{d}/box.glb")
# the reference flattened on white, every pixel opaque — what a phone photo is
im = bpy.data.images.load(f"{d}/ref.png"); w, h = im.size; px = list(im.pixels[:])
for i in range(0, len(px), 4):
    a = px[i + 3]; px[i:i + 4] = [c * a + (1 - a) for c in px[i:i + 3]] + [1.0]
op = bpy.data.images.new("opaque", w, h, alpha=True); op.pixels = px
op.filepath_raw = f"{d}/ref_opaque.png"; op.file_format = "PNG"; op.save()
'''


def blender(*a, check=True):
    r = subprocess.run([BLENDER, "--background", "--factory-startup", "--python-exit-code", "1", *a],
                       capture_output=True, text=True)
    if check and r.returncode != 0:
        sys.exit(f"blender failed ({r.returncode}):\n{r.stdout[-1500:]}\n{r.stderr[-1500:]}")
    return r


def measure(d, model, *extra, check=True, ref="ref.png"):
    out = os.path.join(d, "out_" + os.path.basename(model) + "_".join(extra).replace("-", "") + ref[:-4])
    r = blender("--python", TOOL, "--", "--reference", f"{d}/{ref}", "--model", model,
                "--hdri", f"{d}/env.hdr", "--out", out, "--samples", "2", *extra, check=check)
    line = next((l for l in r.stdout.splitlines() if l.startswith("FIDELITY ")), None)
    return r, (json.loads(line[len("FIDELITY "):]) if line else None), out


with tempfile.TemporaryDirectory() as d:
    open(f"{d}/build.py", "w").write(BUILD)
    blender("--python", f"{d}/build.py", "--", d)
    checks = []

    def check(name, ok, got):
        checks.append(ok); print(f"{'PASS' if ok else 'FAIL'}  {name}  ({got})")

    _, same, out = measure(d, f"{d}/vase.glb")
    shape_gaps = [g for g in same["gaps"] if g.startswith("band") and "width" in g]
    check("model vs its own render: IoU near 1", same["iou"] > 0.95, round(same["iou"], 3))
    check("model vs its own render: no shape gap", not shape_gaps, shape_gaps)
    saved = json.load(open(f"{out}/fidelity.json"))
    vase_hash = hashlib.sha1(open(f"{d}/vase.glb", "rb").read()).hexdigest()[:12]
    check("fidelity.json: the printed measure, with the model's hash and the view",
          saved["iou"] == same["iou"] and saved["model_hash"] == vase_hash and saved["view"] == "front",
          (saved.get("model_hash"), vase_hash))
    measure(d, f"{d}/vase.glb")
    rounds = open(f"{out}/fidelity_log.jsonl").read().splitlines()
    check("fidelity_log.jsonl: one line per run, kept across runs", len(rounds) == 2, len(rounds))

    _, wide, _ = measure(d, f"{d}/vase_wide.glb")
    body = [b for b in wide["shape"] if b["band"] >= 3]
    mean_w = sum(b["full_width"] for b in body) / len(body)
    check("20 % wider: width gap reported", any("width +" in g for g in wide["gaps"]), wide["gaps"][:2])
    check("20 % wider: measured close to +20 %", 0.15 < mean_w < 0.25, round(mean_w, 3))

    _, foot_high, _ = measure(d, f"{d}/vase_foot.glb", "--elevation", "15", ref="ref_high.png")
    _, foot_flat, _ = measure(d, f"{d}/vase_foot.glb")
    persp = [g for g in foot_high["gaps"] if "perspective" in g]
    check("base 14 % wider, camera 15 deg above: told as perspective, listed last",
          bool(persp) and foot_high["gaps"][-1] in persp and not any(g.startswith("band") and "check the overlay" in g
                                                                     for g in foot_high["gaps"]), foot_high["gaps"][-2:])
    check("the same base, no elevation given: a shape gap", any("check the overlay" in g for g in foot_flat["gaps"])
          and not any("perspective" in g for g in foot_flat["gaps"]), foot_flat["gaps"][:2])

    r, _, _ = measure(d, f"{d}/lost.blend", check=False)
    check("unloaded texture: refused with exit 1", r.returncode == 1 and "textures not loaded" in (r.stdout + r.stderr),
          r.returncode)

    r, _, _ = measure(d, f"{d}/vase.glb", check=False, ref="ref_opaque.png")
    check("opaque reference: refused with exit 1", r.returncode == 1 and "no transparent pixel" in (r.stdout + r.stderr),
          r.returncode)

    r, blend, _ = measure(d, f"{d}/vase.blend")
    check("a .blend: warned that the shipped file counts", "WARNING" in r.stdout and blend is not None,
          "WARNING" in r.stdout)

    _, over, _ = measure(d, f"{d}/vase.glb", "--max-tris", "10")
    _, under, _ = measure(d, f"{d}/vase.glb", "--max-tris", "100000")
    check("--max-tris: reported above the limit", any("triangles, above" in g for g in over["gaps"]), over["tris"])
    check("--max-tris: silent below it", not any("triangles, above" in g for g in under["gaps"]), under["tris"])
    check("--max-tris: past 2x, a reduction proposed", any("propose a reduction" in g for g in over["gaps"]), over["tris"])
    _, near, _ = measure(d, f"{d}/vase.glb", "--max-tris", str(int(over["tris"] / 1.5)))
    tri = [g for g in near["gaps"] if "triangles, above" in g]
    check("--max-tris: under 2x, listed last, not to cut",
          bool(tri) and "do not cut" in tri[0] and near["gaps"][-1] == tri[0], tri)

    for name, flagged in (("dark_metal", True), ("dark_paint", False), ("bright_metal", False)):
        _, r, _ = measure(d, f"{d}/{name}.glb")
        hit = [g for g in r["gaps"] if "black mirror" in g]
        check(f"{name}: dark-metal gap {'reported' if flagged else 'silent'}", bool(hit) == flagged,
              [round(m["base_median"], 3) for m in r["metals"]])

    for name, flagged in (("mostly_painted", True), ("soft_wear", False)):
        _, r, _ = measure(d, f"{d}/{name}.glb")
        hit = [g for g in r["gaps"] if "painted as non-metal" in g]
        check(f"{name}: mostly-non-metal gap {'reported' if flagged else 'silent'}", bool(hit) == flagged,
              [round(m.get("mask_mean", 1), 2) for m in r["metals"]])

    grains = {}
    for name in ("plain", "grainy"):
        _, r, _ = measure(d, f"{d}/{name}.glb", "--samples", "16", ref="ref_grainy.png")
        g = [m["grain"] for m in r["material"]["model"] if m and m.get("grain") is not None]
        grains[name] = sum(g) / len(g) if g else 0
        check(f"{name}: grain in the JSON, never in the gaps", bool(g) and not any("grain" in x for x in r["gaps"]), round(grains[name], 3))
    check("grain: a plain surface reads far below a noise-textured one", grains["plain"] < 0.2 * grains["grainy"],
          {k: round(v, 3) for k, v in grains.items()})

    for name, want in (("rod_resting", 2), ("rod_sunk", 0), ("rod_free", 0)):
        _, r, out = measure(d, f"{d}/{name}.glb")
        check(f"{name}: {want} joint render(s)", len(r["joints"]) == want and all(os.path.exists(f) for f in r["joints"]),
              len(r["joints"]))

    for name, flagged in (("confetti", True), ("soft_wear", False)):
        _, r, _ = measure(d, f"{d}/{name}.glb")
        hit = [g for g in r["gaps"] if "camouflage" in g]
        check(f"{name}: metallic-islands gap {'reported' if flagged else 'silent'}", bool(hit) == flagged,
              [(round(m.get("mask_soft", 1), 2), round(m.get("mask_largest", 1), 2)) for m in r["metals"]])

    for label, extra, want in (("--view front", ("--view", "front"), 2.0),
                               ("--view left", ("--view", "left"), 1.0),
                               ("--azimuth 90", ("--azimuth", "90"), 1.0),
                               ("--azimuth 45", ("--azimuth", "45"), 2 * 0.7071 + 0.7071)):
        view = label.replace("--", "").replace(" ", "_")
        _, _, out = measure(d, f"{d}/box.glb", *extra)
        probe = f"{d}/probe_{view}.py"
        open(probe, "w").write(
            "import bpy, numpy as np\n"
            f"im = bpy.data.images.load('{out}/_silhouette.png'); w, h = im.size\n"
            "m = np.array(im.pixels[:]).reshape(h, w, 4)[..., 3] > 0.5\n"
            "ys, xs = np.where(m); print('ASPECT', (np.ptp(xs) + 1) / (np.ptp(ys) + 1))\n")
        a = float(next(l for l in blender("--python", probe).stdout.splitlines() if l.startswith("ASPECT")).split()[1])
        check(f"{label}: 2x1x1 box silhouette {want:.2f}:1", abs(a - want) < 0.08, round(a, 2))

    faces = {}
    for name, ref in (("face", "ref_face.png"), ("face_blank", "ref_face.png"), ("face_low", "ref_face.png"),
                      ("face", "ref_face_bright.png")):
        _, r, _ = measure(d, f"{d}/{name}.glb", "--samples", "16", ref=ref)
        faces[(name, ref)] = r
    same, blank, low, bright = (faces[k] for k in faces)
    fg = lambda r: [g for g in r["gaps"] if g.startswith("face")]
    check("face: its own render matches the details in place", same["face"]["iou"] > 0.8 and max(map(abs, same["face"]["offset"])) < 0.02
          and not fg(same), (round(same["face"]["iou"], 3), [round(v, 3) for v in same["face"]["offset"]], fg(same)))
    check("face: without them the silhouette still matches", blank["iou"] > 0.95, round(blank["iou"], 3))
    check("face: without them it scores 0, every detail missing",
          blank["face"]["iou"] < 0.05 and sum("is missing" in g for g in fg(blank)) == len(blank["face"]["features"]) >= 3,
          (round(blank["face"]["iou"], 3), len(fg(blank)), len(blank["face"]["features"])))
    want = -0.03 / 0.45                                           # 3 cm on a 45 cm vase, as a share of its height
    check("face: 3 cm lower is reported lower, by about that much", any("lower" in g for g in fg(low))
          and abs(low["face"]["offset"][0] - want) < 0.015, (round(low["face"]["offset"][0], 3), round(want, 3)))
    check("face: 3 cm lower still matches once slid", low["face"]["iou"] > 0.8, round(low["face"]["iou"], 3))
    check("face: a reference one stop brighter changes nothing", abs(bright["face"]["iou"] - same["face"]["iou"]) < 0.05
          and not fg(bright), (round(bright["face"]["iou"], 3), round(same["face"]["iou"], 3)))

print(f"\n{sum(checks)}/{len(checks)}")
sys.exit(0 if all(checks) else 1)
