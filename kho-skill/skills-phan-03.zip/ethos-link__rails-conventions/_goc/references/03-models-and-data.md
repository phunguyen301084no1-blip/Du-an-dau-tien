# Models And Data

## Active Record Patterns

### Associations

Declare associations clearly with `dependent` behavior:

```ruby
class Card < ApplicationRecord
  belongs_to :account, default: -> { board.account }
  belongs_to :board
  belongs_to :creator, class_name: "User", default: -> { Current.user }

  has_many :comments, dependent: :destroy
  has_one :closure, dependent: :destroy
end
```

Use lambda defaults to derive context automatically:

```ruby
class Comment < ApplicationRecord
  belongs_to :account, default: -> { card.account }
  belongs_to :creator, class_name: "User", default: -> { Current.user }
end
```

### Validations

Keep validations minimal and focused on invariants:

```ruby
class Account < ApplicationRecord
  validates :name, presence: true
end

class Identity < ApplicationRecord
  validates :email_address, format: { with: URI::MailTo::EMAIL_REGEXP }
  normalizes :email_address, with: ->(value) { value.strip.downcase.presence }
end
```

Use contextual validations for form objects:

```ruby
class Signup
  validates :email_address, format: { with: URI::MailTo::EMAIL_REGEXP }, on: :identity_creation
  validates :full_name, :identity, presence: true, on: :completion
end
```

### Callbacks: Used Sparingly

Callbacks are for setup/cleanup, not business logic:

```ruby
# Good — setup callback
class MagicLink < ApplicationRecord
  before_validation :generate_code, on: :create
  before_validation :set_expiration, on: :create
end

# Good — side effect callback
class Card < ApplicationRecord
  after_create_commit :notify_watchers_later
end

# Bad — business logic in callback
class Invitation < ApplicationRecord
  after_create :process_payment_and_send_welcome_email
end
```

## State As Records Over Booleans

When state matters, create a separate record instead of a boolean column. This preserves who did it, when, and why:

```ruby
# Bad — boolean column
class Card < ApplicationRecord
  scope :closed, -> { where(closed: true) }
  scope :open, -> { where(closed: false) }
end

# Good — separate record
class Closure < ApplicationRecord
  belongs_to :card, touch: true
  belongs_to :user, optional: true
  # created_at gives you when
  # user gives you who
end

class Card < ApplicationRecord
  has_one :closure, dependent: :destroy

  scope :closed, -> { joins(:closure) }
  scope :open, -> { where.missing(:closure) }

  def closed?
    closure.present?
  end

  def close(user: Current.user)
    unless closed?
      transaction do
        create_closure! user: user
        track_event :closed, creator: user
      end
    end
  end
end
```

Use a boolean for intrinsic, low-value state with no actor, timestamp, reason,
history, or audit value. Use a state record when actor, timestamp, reason,
reversibility, audit, or workflow history matters.

### Query Patterns With State Records

```ruby
Card.open                    # where.missing(:closure)
Card.closed                  # joins(:closure)
Card.active                  # open.published.where.missing(:not_now)
Card.postponed               # open.published.joins(:not_now)
```

## Reliable Data Handling

Design writes to be atomic, idempotent where retried, and backed by database
constraints. Keep invariants close to the data: `NOT NULL`, foreign keys,
unique indexes, and check constraints.

Use transactions around multi-record state changes. Use row locks, unique
constraints, or both for concurrency-sensitive writes. Do not rely on
application-only checks for invariants that must hold under concurrent requests
or background jobs.

Separate canonical persisted data from derived data. If a value can be
recomputed and exists for read performance, document its owner and invalidation
path.

For background jobs, pass stable identifiers and make retry behavior safe. A
retried job should not duplicate state transitions, charges, emails, or external
side effects unless the domain explicitly allows it.

## POROs

POROs live under model namespaces. They are model-adjacent, not controller-adjacent.

### Presentation Logic

```ruby
class Event::Description
  attr_reader :event

  def initialize(event)
    @event = event
  end

  def to_s
    case event.action
    when "created"  then "#{creator_name} created this card"
    when "closed"   then "#{creator_name} closed this card"
    else "#{creator_name} updated this card"
    end
  end

  private

  def creator_name
    event.creator.name
  end
end
```

### View Context Bundling

```ruby
class User::Filtering
  attr_reader :user, :filter

  def initialize(user, filter, expanded: false)
    @user = user
    @filter = filter
    @expanded = expanded
  end

  def boards
    user.boards.accessible
  end

  def assignees
    user.account.users.active.alphabetically
  end
end
```

### Naming

Do not use `*Service`, `*Manager`, or `*Handler` suffixes. Use domain nouns.

```ruby
# Good
class SystemCommenter
class Event::Description
class User::Filtering

# Bad
class NotificationService
class PaymentProcessor
class InvitationManager
```

## Scope Naming

Name scopes for business concepts, not SQL:

```ruby
# Good
scope :active, -> { where.missing(:pop) }
scope :unassigned, -> { where.missing(:assignments) }
scope :golden, -> { joins(:goldness) }
scope :alphabetically, -> { order(title: :asc) }
scope :recently_updated, -> { order(updated_at: :desc) }

# Bad
scope :without_pop, -> { ... }
scope :no_assignments, -> { ... }
scope :by_title_asc, -> { ... }
```

## Migration Rules

Generate migrations with Rails — never invent migration filenames, timestamps,
or version numbers by hand. Run `bin/rails generate migration ...` (or the
model/scaffold generator), then edit the generated file. See Generator-Owned
Files in `SKILL.md`.

- Add indexes required for data integrity. For performance indexes, require a
  measured slow query and inspect its plan; see `references/08-performance-caching-and-db.md`.
- Use foreign keys for referential integrity unless the app has a documented
  reason not to.
- Add database constraints for critical invariants. Model validations improve
  error messages; they do not replace database integrity.
- Keep PostgreSQL enum migrations explicit. Adding enum values is supported,
  but removing values is not simple or reversible.
- Keep migrations additive and reversible where practical.
- Small inline backfills are fine in one migration (add column → SQL update →
  tighten constraint). Long-running or risky backfills leave the deploy
  migration path entirely.

### Staged Rollouts

Split risky schema work across deploys:

- **Column replacement**: add nullable column → dual-write/backfill → read from
  new column → enforce constraints → drop old column later.
- **Constraint hardening**: clean/backfill data first, then add the
  index/constraint, then rely on it in application code.
- **Destructive changes**: stop reads/writes in app code → deploy → drop
  columns/tables only after a confirmation window.

Safe default for required columns: add nullable → backfill → set `NOT NULL`.

### Script Backfills

Long-running data work belongs in a manual script (for example
`script/migrations/*.rb` or the app's existing ops path), not in
`db:migrate` during deploy:

- Document preconditions and run instructions in a header comment.
- Print a preflight scope before mutating.
- Make reruns safe (skip already-processed rows).
- Batch with `find_each` / `in_batches`.

If the app already has a backfill convention, follow it instead of inventing a
new directory.

### Never Reference Application Models

Migrations must not depend on application model code. If a model changes after
the migration runs, the migration will break on future runs. These examples use
the Rails 8.1 baseline; actual files retain their generator-selected migration
version. Do not rewrite historical migration versions during unrelated work.

```ruby
# Bad — depends on User model; breaks if User changes
class AddJobsCountToUser < ActiveRecord::Migration[8.1]
  def up
    add_column :users, :jobs_count, :integer, default: 0
    User.all.each { |u| u.update!(jobs_count: u.jobs.size) }
  end
end

# Good — pure SQL, no external dependencies
class AddJobsCountToUser < ActiveRecord::Migration[8.1]
  def up
    add_column :users, :jobs_count, :integer, default: 0
    execute <<-SQL
      UPDATE users SET jobs_count = (
        SELECT count(*) FROM jobs WHERE jobs.user_id = users.id
      )
    SQL
  end
end
```

If a model class is needed for data migrations, define an inline class within the migration:

```ruby
class BackfillData < ActiveRecord::Migration[8.1]
  class User < ActiveRecord::Base
    self.table_name = "users"
  end

  def up
    User.reset_column_information
    User.find_each do |user|
      # safe to use inline class
    end
  end
end
```

## Query Safety

- Use eager loading to prevent N+1 (`includes`, `preload`, `eager_load`).
- Use parameterized query APIs; avoid interpolated SQL.
- Measure heavy queries with EXPLAIN before and after changes.

## Performance: Database Over Ruby

Do in SQL what SQL does best. Load data into Ruby only when you need object-level behavior.

```ruby
# Bad — loads ALL records into Ruby memory
Order.all.select { |o| o.total > 100 }
Order.all.map(&:total).sum
user.posts.length

# Good — database does the work
Order.where("total > ?", 100)
Order.sum(:total)
user.posts.count       # SQL COUNT
user.posts.size        # uses counter cache if available
```

Use `find_each` or `in_batches` for large collections — never iterate with `.each` on unbounded queries:

```ruby
# Bad
User.where(active: true).each { |u| u.update!(verified: true) }

# Good
User.where(active: true).find_each { |u| u.update!(verified: true) }
```

### Rules

- Use `.count` not `.length` on associations (SQL vs Ruby).
- Use `.sum(:column)` not `.map(&:field).sum`.
- Use `.where(conditions)` not `.all.select { ... }`.
- Use `find_each` not `each` for large collections.
- Use counter caches instead of manual counting.

For PostgreSQL-specific datatypes, indexes, constraints, and views, load
`references/03a-active-record-postgresql.md`.

## Write-Time Over Read-Time

Pre-compute data at write time when it reduces expensive reads:

- Use counter caches instead of manual counting.
- Pre-compute roll-ups when saving, not when presenting.
- Use `touch: true` on associations for cache invalidation chains.

## Provider Parsing Contract

- Provider parsers must only map fields present in the source payload or HTML;
  do not invent fallback values during parsing.
- Do not set model defaults in parsers or import normalizers. Defaults belong on
  the persisted models or their write path.
- If stored/raw provider payloads are partial, normalize the payload shape in the
  orchestrator before calling the provider parser.
