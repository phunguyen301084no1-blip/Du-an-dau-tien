# Pre-flight

Run this before delivery.

In light-edit mode, only the Preservation check and Voice check can trigger changes. Run the other sections to spot errors you can name (see light-edit mode in `SKILL.md`); a "no" there is not by itself a reason to rewrite, and a text with nothing wrong goes back unchanged.

## Preservation check

- Have you kept every required fact, citation, quote, name, date, number, and constraint?
- Have you preserved the requested dialect and terminology?
- Have you kept exact wording where the user marked it as fixed?
- If you cut content, was cutting part of the request?
- If you added specificity, is it sourced by the user's material or clearly framed as a placeholder?
- Does every sentence in the rewrite say something the source states or directly implies? A next step, a claim about what has happened since, an opinion, or a joke that the source does not contain is an invention, however natural it sounds.
- Have qualifiers such as "may", "often", and "under these conditions" survived where they limit a claim?
- Read the last sentence against the source on its own. Endings are where inventions cluster: a closing line that states progress, a cause, or a result the source only hoped for or implied is an addition. Cut it and end on the previous fact. A hope the source did hold stays a hope, in about as many words as the source gave it; a thanks, a verdict, or a lesson wrapped around it is an addition.
- Have ranking and scope words survived: "only", "first", "most", "least", "never", "simultaneously"? Trimming a tricolon, a qualifier, or a bold label often takes them out, and each one is a claim.

## Anti-slop check

- No chatbot framing remains.
- No generic "in conclusion" ending remains unless the genre requires it.
- No decorative emoji or mechanical bold-label bullets remain unless appropriate.
- No em dashes or en dashes remain in strict de-AI rewrites, except en dashes in numeric and date ranges. End the sentence or use a comma; do not swap the dash for a colon or parentheses. Exempt literary and editorial long-form where dashes are the writer's voice — see Dash dependence in `ai-writing-patterns.md`.
- No repeated 'not X but Y'/'not just X but Y' scaffold remains; single contrast used once is not a tell — see Binary contrast in `structures-and-phrases.md`.
- No vague "experts say" claim remains without a named source.
- No promotional language remains in neutral copy.
- No sentence names a feeling where it could name a mechanism, a number, or a date.
- Swap test: no sentence could sit unchanged in another company's or project's copy.
- No fake precision, invented anecdote, or made-up metric was added.
- No change note lists what was preserved or left alone.
- No leaked tool artefacts, citation markup, tracking parameters, unedited assistant scaffolding, model disclaimers, or unfilled placeholders remain — see Near-conclusive artefacts in `ai-writing-patterns.md`. Examples include `oaicite`, `contentReference`, raw `**` or `##` in a plain-text destination, `?utm_source=chatgpt.com`, and `[Your Name]`. A deliberate gap marker for a missing fact, such as `[churn figure needed]`, is allowed; see the Preservation check.

## Taste check

Answer yes or no. Do not score; a number here is fake precision.

- Directness: does every sentence make its statement instead of announcing it?
- Specificity: can the reader see the actor, object, evidence, or consequence in each claim?
- Rhythm: do sentence and paragraph lengths vary?
- Voice fit: does it match the genre, audience, and any sample?
- Density: is nothing left that could be cut without losing meaning?
- Restraint: is everything stated at its actual size, or has something been puffed up or talked down?

Any "no" means revise that dimension before delivery. Quote the sentence that fails; if you cannot point to one, the answer is yes.

## Read-aloud check

Read the final text silently as if speaking it.

- Where would a person stumble?
- Where does it sound too polished to be believed?
- Where does it sound evasive?
- Where does it lecture instead of explain?
- Where does a sentence exist only to make the piece feel complete?

Fix those spots before sending.

## Structure check

- Uniform cadence: do short and long sentences both appear, or does everything sit at the same 18 to 24 words (count words, not tokens)? Vary the length; do not invent content to do it. Three consecutive sentences of the same length is the point to look at.
- Paragraph-reshuffle test: could the paragraphs be reordered without breaking the flow? If so, the piece lacks an order. Fix the order, not the connectives: if the paragraphs already hold their sequence, delete the "however" and "in addition" that were added to fake one. Add a link only where the order fails.
- Outline test: read the first sentence of every paragraph in order. If they form a clean summary of the piece, the structure is template-shaped. Exempt specs, runbooks, and other documents that are meant to be skimmed that way.
- Proportion: count the emphasised sentences (figures of speech, intensifiers, tricolons, punchlines). More than one per paragraph, or a punchline closing every paragraph, is the model's habit. Strip the extras to plain statement.
- Friction-free tone: is there any genuine spike of doubt, bluntness, humour, or irritation, or does every paragraph sit at the same pleasant altitude? Surface the tone that is already in the source or the brief. Never invent opinions, asides, or anecdotes the writer did not have.
- Uniform confidence: is every sentence equally sure? A piece with no "I think" and no unresolved point reads as machine house style even with every tell removed. Keep the writer's uncertainty where they had it. Do not manufacture it.
- Backtrack test: is there a sentence the reader has to re-read to parse? Split it. One idea per sentence.

## Voice check

For any brief that says keep my voice, light edit, or supplies a sample:

- Contractions, first-person pronouns, and hedges: count them in the source and the rewrite. If the rewrite has fewer, put them back. This is the measured direction of drift and it happens under a voice-preserving instruction too.
- Mean word length: if the rewrite's words are longer on average, the edit swapped plain words for formal ones. Reverse it.
- Unity: person, tense, and stance match the first paragraph all the way through.
- Every change has a reason: for each word changed on a light edit, name the error it fixes, or the filler it removes. "It is on a tell list" and "it reads better" are not reasons. Put back any change without one.
- Counts over feel: do not accept "it still sounds like them" in place of the numbers. In a 2026 study, people who post-edited model text judged it their own while it measured closer to the model's style than to their unassisted writing.
- Recognition: would the writer read the rewrite and recognise it as theirs? If a sentence would make them say "I would never put it that way", it goes back to how they put it.

## Per-sentence pass

Before delivery, read the piece once as a first-time reader and mark each sentence plus, minus, or zero. Act only on the minuses. This is cheaper than another full rewrite and it catches the sentence that exists only to make the piece feel complete.

## Delivery check

- Put the final text first unless the user asked for analysis.
- Keep notes short.
- If the user asked for a review, lead with findings and examples.
- If the user asked for options, make the options genuinely different.
- If facts are missing, say what is missing rather than inventing them.
