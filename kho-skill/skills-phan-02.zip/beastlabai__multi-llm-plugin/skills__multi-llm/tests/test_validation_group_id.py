#!/usr/bin/env python3
"""
Tests for group_id-based validation matching functionality.

Tests the following behaviors:
- apply_validation_to_groups() uses group_id for matching when available
- save_validation_results() includes group_id when groups are provided
- prepare_batched_validation_tasks() includes group_ids in batch metadata
- merge_batched_validation_results() uses group_id from metadata
- Reaggregation scenarios preserve validation across reordering
"""

import json
import re
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict, List

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent))

from utils.validation import (
    apply_validation_to_groups,
    save_validation_results,
    prepare_batched_validation_tasks,
    merge_batched_validation_results,
    load_validation_results,
)
from utils.state_manager import generate_group_id


# ============================================================================
# Test Fixtures
# ============================================================================

@pytest.fixture
def temp_dir():
    """Create a temporary directory for test files."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield tmpdir


@pytest.fixture
def sample_groups() -> List[Dict[str, Any]]:
    """Sample suggestion groups for testing."""
    return [
        {
            "theme": "Security Vulnerability",
            "category": "security",
            "models": ["model-a", "model-b"],
            "suggestions": [
                {
                    "title": "SQL Injection Risk",
                    "desc": "Sanitize user inputs in database queries",
                    "importance": "HIGH",
                    "type": "fix"
                }
            ]
        },
        {
            "theme": "Documentation",
            "category": "docs",
            "models": ["model-a"],
            "suggestions": [
                {
                    "title": "Add README",
                    "desc": "Document API endpoints",
                    "importance": "LOW",
                    "type": "addition"
                }
            ]
        },
        {
            "theme": "Performance",
            "category": "optimization",
            "models": ["model-b"],
            "suggestions": [
                {
                    "title": "Cache Results",
                    "desc": "Add caching layer for expensive queries",
                    "importance": "MEDIUM",
                    "type": "addition"
                }
            ]
        }
    ]


def make_group(importance: str = "MEDIUM", theme: str = "Test Theme", desc: str = "Test description") -> dict:
    """Helper to create a test group."""
    return {
        "theme": theme,
        "category": "test",
        "models": ["test-model"],
        "suggestions": [
            {
                "title": "Test suggestion",
                "desc": desc,
                "importance": importance,
                "type": "modification"
            }
        ]
    }


# ============================================================================
# Tests for apply_validation_to_groups() with group_id
# ============================================================================

class TestApplyValidationWithGroupId:
    """Unit tests for group_id-based validation matching in apply_validation_to_groups()."""

    def test_match_by_group_id_when_available(self):
        """Validation results with group_id should match by content hash, not index.

        This test simulates reaggregation where groups are reordered but validation
        results have group_ids that should still match correctly.
        """
        # Create two groups
        security_group = make_group("HIGH", "Security Issue", "Fix authentication bypass")
        docs_group = make_group("LOW", "Documentation", "Add API docs")

        # Original order: [security, docs]
        original_groups = [security_group, docs_group]

        # Compute group_ids
        security_gid = generate_group_id(security_group)
        docs_gid = generate_group_id(docs_group)

        # Validation results in ORIGINAL order with group_ids
        validation_results = [
            {
                "group_index": 0,
                "group_id": security_gid,
                "status": "valid",
                "reason": "Real security issue",
                "confidence": 0.95
            },
            {
                "group_index": 1,
                "group_id": docs_gid,
                "status": "invalid",
                "reason": "Not needed for MVP",
                "confidence": 0.8
            }
        ]

        # NEW order after reaggregation: [docs, security] (reversed)
        reordered_groups = [docs_group, security_group]

        # Apply validation to reordered groups
        result = apply_validation_to_groups(reordered_groups, validation_results)

        # Verify: docs (now at index 0) should get "invalid" status (its original validation)
        assert result[0]["validation_status"] == "invalid"
        assert result[0]["validation_reason"] == "Not needed for MVP"

        # Verify: security (now at index 1) should get "valid" status (its original validation)
        assert result[1]["validation_status"] == "valid"
        assert result[1]["validation_reason"] == "Real security issue"

    def test_fallback_to_index_when_no_group_id(self):
        """Backward compat - validation results without group_id should use index matching."""
        groups = [
            make_group("HIGH", "Group A"),
            make_group("LOW", "Group B")
        ]

        # Validation results WITHOUT group_id (old format)
        validation_results = [
            {
                "group_index": 0,
                "status": "valid",
                "reason": "Good suggestion",
                "confidence": 0.9
            },
            {
                "group_index": 1,
                "status": "invalid",
                "reason": "False positive",
                "confidence": 0.85
            }
        ]

        result = apply_validation_to_groups(groups, validation_results)

        # Should match by index
        assert result[0]["validation_status"] == "valid"
        assert result[1]["validation_status"] == "invalid"

    def test_partial_group_id_coverage(self):
        """Some results have group_id, some don't - verify each uses appropriate matching method."""
        group_a = make_group("HIGH", "Group A", "Description A")
        group_b = make_group("MEDIUM", "Group B", "Description B")
        group_c = make_group("LOW", "Group C", "Description C")

        groups = [group_a, group_b, group_c]

        gid_a = generate_group_id(group_a)
        gid_c = generate_group_id(group_c)

        # Mixed: group_a and group_c have group_id, group_b does not
        validation_results = [
            {
                "group_index": 0,
                "group_id": gid_a,  # Has group_id
                "status": "valid",
                "reason": "Matched by group_id",
                "confidence": 0.9
            },
            {
                "group_index": 1,
                # No group_id - will match by index
                "status": "invalid",
                "reason": "Matched by index",
                "confidence": 0.8
            },
            {
                "group_index": 2,
                "group_id": gid_c,  # Has group_id
                "status": "needs-human-decision",
                "reason": "Also matched by group_id",
                "confidence": 0.5
            }
        ]

        result = apply_validation_to_groups(groups, validation_results)

        # All should be matched correctly
        assert result[0]["validation_status"] == "valid"
        assert result[0]["validation_reason"] == "Matched by group_id"

        assert result[1]["validation_status"] == "invalid"
        assert result[1]["validation_reason"] == "Matched by index"

        assert result[2]["validation_status"] == "needs-human-decision"
        assert result[2]["validation_reason"] == "Also matched by group_id"

    def test_missing_validation_gets_default(self):
        """Groups without matching validation (neither by group_id nor index) should get needs-human-decision."""
        groups = [
            make_group("HIGH", "Group A"),
            make_group("MEDIUM", "Group B"),
            make_group("LOW", "Group C")  # No validation for this one
        ]

        # Only validate first two groups
        gid_a = generate_group_id(groups[0])
        gid_b = generate_group_id(groups[1])

        validation_results = [
            {
                "group_index": 0,
                "group_id": gid_a,
                "status": "valid",
                "reason": "Good",
                "confidence": 0.9
            },
            {
                "group_index": 1,
                "group_id": gid_b,
                "status": "invalid",
                "reason": "Bad",
                "confidence": 0.8
            }
            # Note: no entry for group C at index 2
        ]

        result = apply_validation_to_groups(groups, validation_results)

        # First two should have their validation
        assert result[0]["validation_status"] == "valid"
        assert result[1]["validation_status"] == "invalid"

        # Third should get default status
        assert result[2]["validation_status"] == "needs-human-decision"
        assert result[2]["validation_reason"] == "No validation result"


# ============================================================================
# Tests for save_validation_results() with group_id
# ============================================================================

class TestSaveValidationWithGroupId:
    """Unit tests for saving validation results with group_id."""

    def test_save_includes_group_id_when_groups_provided(self, temp_dir):
        """When groups parameter is provided, group_id should be computed and saved."""
        groups = [
            make_group("HIGH", "Security"),
            make_group("LOW", "Docs")
        ]

        validation_results = [
            {"group_index": 0, "status": "valid", "reason": "Good", "confidence": 0.9},
            {"group_index": 1, "status": "invalid", "reason": "Bad", "confidence": 0.8}
        ]

        output_path = Path(temp_dir) / "validation.json"

        # Save with groups parameter
        save_validation_results(
            validation_results=validation_results,
            output_path=output_path,
            model="test-model",
            groups=groups
        )

        # Load and verify group_ids were saved
        with open(output_path, 'r', encoding="utf-8") as f:
            saved_data = json.load(f)

        saved_groups = saved_data["groups"]

        # Verify each saved result has group_id matching the computed value
        expected_gid_0 = generate_group_id(groups[0])
        expected_gid_1 = generate_group_id(groups[1])

        assert saved_groups[0]["group_id"] == expected_gid_0
        assert saved_groups[1]["group_id"] == expected_gid_1

    def test_save_without_groups_preserves_existing_group_id(self, temp_dir):
        """When groups not provided, existing group_id in validation results should be preserved."""
        existing_gid = "abc123def456"

        validation_results = [
            {
                "group_index": 0,
                "group_id": existing_gid,  # Pre-existing group_id
                "status": "valid",
                "reason": "Already has group_id",
                "confidence": 0.9
            }
        ]

        output_path = Path(temp_dir) / "validation.json"

        # Save WITHOUT groups parameter
        save_validation_results(
            validation_results=validation_results,
            output_path=output_path,
            model="test-model"
            # groups not provided
        )

        # Load and verify existing group_id was preserved
        with open(output_path, 'r', encoding="utf-8") as f:
            saved_data = json.load(f)

        assert saved_data["groups"][0]["group_id"] == existing_gid


# ============================================================================
# Tests for prepare_batched_validation_tasks() with group_ids
# ============================================================================

class TestBatchPreparationWithGroupId:
    """Unit tests for batch preparation including group_ids."""

    def test_batch_metadata_includes_group_ids(self, temp_dir):
        """Batch metadata should include group_ids list parallel to group_indices.

        Verify each batch has group_ids matching the groups at those indices.
        """
        groups = [
            make_group("MEDIUM", f"Group {i}", f"Description {i}")
            for i in range(6)
        ]

        # Pre-compute expected group_ids
        expected_gids = [generate_group_id(g) for g in groups]

        result = prepare_batched_validation_tasks(
            groups=groups,
            context="Test context",
            output_dir=temp_dir,
            plan_file="/path/to/plan.md",
            max_per_batch=4
        )

        # Should have 2 batches (4 + 2)
        assert len(result["batches"]) == 2

        # Verify each batch has group_ids parallel to group_indices
        for batch in result["batches"]:
            assert "group_ids" in batch
            assert len(batch["group_ids"]) == len(batch["group_indices"])

            # Verify each group_id matches the expected value for that index
            for i, group_idx in enumerate(batch["group_indices"]):
                assert batch["group_ids"][i] == expected_gids[group_idx]

    def test_batch_prompt_names_the_global_index_group_index_not_index(self, temp_dir):
        """The request record's index field is `group_index`, matching the key
        the reply contract asks the subagent to echo back.

        Before this fix the prompt listed each group under a bare `"index"`
        while the reply schema asked for `"group_index"` — a name mismatch a
        run showed models resolving by falling back to a batch-local ordinal
        (0, 1, 2, ...) instead of the global index they were actually shown.
        """
        groups = [make_group("MEDIUM", f"Group {i}") for i in range(2)]
        result = prepare_batched_validation_tasks(
            groups=groups,
            context="Test context",
            output_dir=temp_dir,
            plan_file="/path/to/plan.md",
        )
        prompt = result["batches"][0]["prompt"]
        assert '"group_index": 0' in prompt
        assert '"group_index": 1' in prompt
        # The request no longer names the group's position under the bare
        # `"index"` key the reply never asked for.
        assert '"index":' not in prompt

    def test_the_reply_half_of_a_batch_prompt_offers_no_index_to_copy(self, temp_dir):
        """The request records carry real `group_index` numbers; the reply
        template must carry none.

        With a literal `"group_index": 0` in the reply schema, models copy the
        *example* rather than echoing their group's value — 18 of 32 verdicts in
        one run and 41 of 46 in the run before it came back numbered 0,1,2,3…
        The hash join absorbs it, but the template is where the habit starts,
        so the schema now shows an unfillable placeholder.
        """
        groups = [make_group("MEDIUM", f"Group {i}") for i in range(2)]
        result = prepare_batched_validation_tasks(
            groups=groups,
            context="Test context",
            output_dir=temp_dir,
            plan_file="/path/to/plan.md",
        )
        prompt = result["batches"][0]["prompt"]
        request_half, reply_half = prompt.split("## Reply", 1)
        # The records keep their numbers — that is the value to echo ...
        assert '"group_index": 0' in request_half
        # ... and the reply template offers no number to copy instead.
        assert re.search(r'"group_index":\s*\d', reply_half) is None
        assert '"group_index": <the group\'s group_index value>' in reply_half
        assert "the hash is what the" in reply_half


# ============================================================================
# Tests for merge_batched_validation_results() with group_id
# ============================================================================

class TestMergeBatchedWithGroupId:
    """Unit tests for merging batched results with group_id."""

    def test_merge_uses_group_id_from_metadata(self, temp_dir):
        """Merged results should include group_id from batch metadata."""
        groups = [make_group("MEDIUM", f"Group {i}") for i in range(4)]

        batch_metadata = prepare_batched_validation_tasks(
            groups=groups,
            context="Test context",
            output_dir=temp_dir,
            plan_file="/path/to/plan.md",
            max_per_batch=4
        )

        # Write batch result file (single batch for 4 groups)
        batch = batch_metadata["batches"][0]
        batch_results = {
            "groups": [
                {"group_index": i, "status": "valid", "reason": "OK", "confidence": 0.9}
                for i in range(4)
            ],
            "metadata": {"model": "test", "schema_version": "2.1"}
        }
        with open(batch["output_path"], 'w', encoding="utf-8") as f:
            json.dump(batch_results, f)

        # Merge results
        merged = merge_batched_validation_results(
            output_dir=temp_dir,
            batch_metadata=batch_metadata,
            total_groups=len(groups)
        )

        # Verify each merged result has group_id from metadata
        expected_gids = batch["group_ids"]
        for i, result in enumerate(merged):
            assert "group_id" in result
            assert result["group_id"] == expected_gids[i]

    def test_merge_tags_each_result_with_its_batch_source_model(self, temp_dir):
        """Merged results carry `_source_model` from their batch file's own
        `metadata.model`, which is what lets `save_validation_results` derive
        an overall model when its caller passes none."""
        groups = [make_group("MEDIUM", f"Group {i}") for i in range(4)]
        batch_metadata = prepare_batched_validation_tasks(
            groups=groups,
            context="Test context",
            output_dir=temp_dir,
            plan_file="/path/to/plan.md",
            max_per_batch=4,
        )
        batch = batch_metadata["batches"][0]
        batch_results = {
            "groups": [
                {"group_index": i, "status": "valid", "reason": "OK", "confidence": 0.9}
                for i in range(4)
            ],
            "metadata": {"model": "big-pickle", "schema_version": "2.1"},
        }
        with open(batch["output_path"], 'w', encoding="utf-8") as f:
            json.dump(batch_results, f)

        merged = merge_batched_validation_results(
            output_dir=temp_dir, batch_metadata=batch_metadata, total_groups=len(groups)
        )
        for result in merged:
            assert result["_source_model"] == "big-pickle"

    def test_merge_prints_one_summary_line_for_mismatched_group_index_echoes(
        self, temp_dir, capsys
    ):
        """A batch where every verdict echoes the wrong `group_index` (but the
        right `group_hash`) is joined correctly by hash and reported as ONE
        summary line, never one `[merge] Warning:` line per verdict.

        A correct 16-batch run used to print 41 per-verdict warning lines for
        exactly this — noise for a run whose join was never in doubt, since
        the hash is authoritative regardless of what index was echoed.
        """
        # 8 groups over max_per_batch=4 makes a second batch whose global
        # indices are [4, 5, 6, 7] — a batch-local ordinal (0..3) then
        # genuinely differs from every one of its global indices.
        groups = [make_group("MEDIUM", f"Group {i}") for i in range(8)]
        batch_metadata = prepare_batched_validation_tasks(
            groups=groups,
            context="Test context",
            output_dir=temp_dir,
            plan_file="/path/to/plan.md",
            max_per_batch=4,
        )
        batch = batch_metadata["batches"][1]
        assert batch["group_indices"] == [4, 5, 6, 7]
        # Every verdict echoes a batch-local ordinal (0..3) instead of the
        # global group_index it was shown; the hash is still correct.
        batch_results = {
            "groups": [
                {
                    "group_index": local_idx,
                    "group_hash": batch["group_ids"][local_idx],
                    "status": "valid",
                    "reason": "OK",
                    "confidence": 0.9,
                }
                for local_idx in range(4)
            ],
            "metadata": {"model": "test", "schema_version": "2.1"},
        }
        with open(batch["output_path"], 'w', encoding="utf-8") as f:
            json.dump(batch_results, f)
        # The other batch is left unfilled; give it a matching (non-mismatch)
        # reply so the merge has nothing else to warn about.
        other = batch_metadata["batches"][0]
        with open(other["output_path"], 'w', encoding="utf-8") as f:
            json.dump({
                "groups": [
                    {
                        "group_index": gidx,
                        "group_hash": other["group_ids"][local_idx],
                        "status": "valid",
                        "reason": "OK",
                        "confidence": 0.9,
                    }
                    for local_idx, gidx in enumerate(other["group_indices"])
                ],
                "metadata": {"model": "test", "schema_version": "2.1"},
            }, f)

        capsys.readouterr()
        merged = merge_batched_validation_results(
            output_dir=temp_dir, batch_metadata=batch_metadata, total_groups=len(groups)
        )
        out = capsys.readouterr().out

        # Still joined correctly by hash regardless of the mismatched echo.
        for i, result in enumerate(merged):
            assert result["group_index"] == i
            assert result["status"] == "valid"

        assert out.count("[merge] Warning: Batch") == 0
        assert "4 of 8 verdicts echoed a different group_index; all joined by hash" in out

    def test_merge_survives_a_verdict_that_copied_the_reply_placeholder(
        self, temp_dir, capsys
    ):
        """A `group_index` that is not an index joins by hash and is counted,
        never crashes.

        The reply template shows `group_index` as `<the group's group_index
        value>` so there is no number to copy; a model that copies the
        *placeholder* sends that string instead. The echo is advisory, so the
        merge must treat an unparseable one as "matches nothing" and let the
        hash do the join.
        """
        groups = [make_group("MEDIUM", f"Group {i}") for i in range(3)]
        batch_metadata = prepare_batched_validation_tasks(
            groups=groups,
            context="Test context",
            output_dir=temp_dir,
            plan_file="/path/to/plan.md",
        )
        batch = batch_metadata["batches"][0]
        with open(batch["output_path"], 'w', encoding="utf-8") as f:
            json.dump({
                "groups": [
                    {
                        "group_index": "<the group's group_index value>",
                        "group_hash": batch["group_ids"][local_idx],
                        "status": "valid",
                        "reason": "OK",
                        "confidence": 0.9,
                    }
                    for local_idx in range(len(batch["group_indices"]))
                ],
                "metadata": {"model": "test", "schema_version": "2.1"},
            }, f)

        capsys.readouterr()
        merged = merge_batched_validation_results(
            output_dir=temp_dir, batch_metadata=batch_metadata, total_groups=len(groups)
        )
        out = capsys.readouterr().out

        for i, result in enumerate(merged):
            assert result["group_index"] == i  # repaired from the hash
            assert result["status"] == "valid"
        assert "3 of 3 verdicts echoed a different group_index; all joined by hash" in out

    def test_merge_survives_a_placeholder_group_index_with_no_hash(
        self, temp_dir, capsys
    ):
        """Same non-index echo, but with no hash to fall back on: the verdict
        is unusable, and the merge says so instead of raising TypeError.

        Without a hash the result reaches the index-based fallbacks, whose last
        one compares the echo against `0 <= i < len(...)` — a comparison a raw
        string would have blown up on.
        """
        groups = [make_group("MEDIUM", f"Group {i}") for i in range(4)]
        batch_metadata = prepare_batched_validation_tasks(
            groups=groups,
            context="Test context",
            output_dir=temp_dir,
            plan_file="/path/to/plan.md",
        )
        batch = batch_metadata["batches"][0]
        # Two verdicts for a four-group batch, so neither the global-index nor
        # the positional strategy can claim them: Strategy 4 is what runs.
        with open(batch["output_path"], 'w', encoding="utf-8") as f:
            json.dump({
                "groups": [
                    {
                        "group_index": "<the group's group_index value>",
                        "status": "valid",
                        "reason": "OK",
                        "confidence": 0.9,
                    }
                    for _ in range(2)
                ],
                "metadata": {"model": "test", "schema_version": "2.1"},
            }, f)

        capsys.readouterr()
        merged = merge_batched_validation_results(
            output_dir=temp_dir, batch_metadata=batch_metadata, total_groups=len(groups)
        )
        out = capsys.readouterr().out

        # Nothing was placed; every group stays revalidatable.
        assert [r["group_index"] for r in merged] == [0, 1, 2, 3]
        for result in merged:
            assert result["status"] == "validation_failed"
            assert result["recoverable"] is True
        assert "[merge] Warning: Index -1 out of range" in out

    @pytest.mark.parametrize("echoed,expected", [
        (3, 3),
        ("3", 3),
        (" 3 ", 3),
        (3.0, 3),
        (3.5, -1),
        ("<the group's group_index value>", -1),
        ("", -1),
        (None, -1),
        (True, -1),            # bools are ints in Python; an index they are not
        ({"group_index": 3}, -1),
    ])
    def test_reported_group_index_coercion_table(self, echoed, expected):
        """Every shape an echo can arrive in resolves to an int or to -1."""
        from utils.validation import _reported_group_index

        assert _reported_group_index({"group_index": echoed}) == expected

    def test_reported_group_index_falls_back_to_index_then_to_minus_one(self):
        from utils.validation import _reported_group_index

        assert _reported_group_index({"index": 2}) == 2
        assert _reported_group_index({}) == -1

    def test_merge_accepts_a_group_index_echoed_as_a_numeric_string(self, temp_dir):
        """`"2"` is a transcription of a real index, not a copied placeholder,
        so the index-based fallback still routes on it."""
        groups = [make_group("MEDIUM", f"Group {i}") for i in range(3)]
        batch_metadata = prepare_batched_validation_tasks(
            groups=groups,
            context="Test context",
            output_dir=temp_dir,
            plan_file="/path/to/plan.md",
        )
        batch = batch_metadata["batches"][0]
        with open(batch["output_path"], 'w', encoding="utf-8") as f:
            json.dump({
                "groups": [
                    {
                        "group_index": str(gidx),
                        "status": "valid",
                        "reason": f"OK {gidx}",
                        "confidence": 0.9,
                    }
                    for gidx in batch["group_indices"]
                ],
                "metadata": {"model": "test", "schema_version": "2.1"},
            }, f)

        merged = merge_batched_validation_results(
            output_dir=temp_dir, batch_metadata=batch_metadata, total_groups=len(groups)
        )
        for i, result in enumerate(merged):
            assert result["group_index"] == i
            assert result["reason"] == f"OK {i}"


# ============================================================================
# Integration Tests for Reaggregation Preserving Validation
# ============================================================================

class TestValidationGroupIdIntegration:
    """Integration test for reaggregation preserving validation."""

    def test_reaggregation_preserves_validation_across_reordering(self, temp_dir):
        """Simulate reaggregation where existing groups are reordered.

        This test demonstrates that group_id matching preserves validation
        when existing groups change position in the list.

        Scenario:
        1. Initial groups: [Security (HIGH), Docs (LOW)]
        2. Validation marks Security as "valid", Docs as "invalid"
        3. Reaggregation reverses order: [Docs, Security]
        4. Validation should be preserved via group_id matching
        """
        # Step 1: Create initial groups
        security_group = {
            "theme": "Security Vulnerability",
            "category": "security",
            "models": ["model-a"],
            "suggestions": [
                {
                    "title": "Fix Auth Bypass",
                    "desc": "Prevent unauthorized access",
                    "importance": "HIGH",
                    "type": "fix"
                }
            ]
        }

        docs_group = {
            "theme": "Documentation Missing",
            "category": "docs",
            "models": ["model-b"],
            "suggestions": [
                {
                    "title": "Add API docs",
                    "desc": "Document REST endpoints",
                    "importance": "LOW",
                    "type": "addition"
                }
            ]
        }

        # Initial order: [security (HIGH), docs (LOW)]
        initial_groups = [security_group, docs_group]

        # Step 2: Create validation results with group_ids
        security_gid = generate_group_id(security_group)
        docs_gid = generate_group_id(docs_group)

        initial_validation = [
            {
                "group_index": 0,
                "group_id": security_gid,
                "status": "valid",
                "reason": "Real security issue",
                "confidence": 0.95
            },
            {
                "group_index": 1,
                "group_id": docs_gid,
                "status": "invalid",
                "reason": "Docs not needed for MVP",
                "confidence": 0.85
            }
        ]

        # Step 3: Save validation with groups parameter
        validation_path = Path(temp_dir) / "validation.json"
        save_validation_results(
            validation_results=initial_validation,
            output_path=validation_path,
            model="test-model",
            groups=initial_groups
        )

        # Step 4: Simulate reaggregation - reverse the order
        # New order: [docs (was index 1), security (was index 0)]
        reaggregated_groups = [docs_group, security_group]

        # Step 5: Load saved validation
        loaded_validation = load_validation_results(validation_path)

        # Step 6: Apply validation to reaggregated groups
        result = apply_validation_to_groups(reaggregated_groups, loaded_validation)

        # Step 7: Verify results - validation follows by group_id, not index

        # Docs (now at index 0) should get its original "invalid" status
        assert result[0]["validation_status"] == "invalid"
        assert result[0]["validation_reason"] == "Docs not needed for MVP"
        assert result[0]["validation_confidence"] == 0.85

        # Security (now at index 1) should get its original "valid" status
        assert result[1]["validation_status"] == "valid"
        assert result[1]["validation_reason"] == "Real security issue"
        assert result[1]["validation_confidence"] == 0.95

    def test_new_group_at_an_existing_index_never_inherits_a_hashed_verdict(
        self, temp_dir, capsys
    ):
        """A hashed record that matches nothing is not handed to the group at its index.

        Before D7 the index fallback was checked for every record, so a new
        group sitting at an old record's index inherited that record's status,
        reason and confidence — another group's verdict. The fallback is now for
        hash-less (pre-hash format) records only; a hashed miss leaves the group
        at the default and is counted on stdout.
        """
        # Create initial groups
        security_group = {
            "theme": "Security",
            "category": "security",
            "models": ["model-a"],
            "suggestions": [{"title": "Fix", "desc": "Security fix", "importance": "HIGH", "type": "fix"}]
        }

        # Initial validation
        security_gid = generate_group_id(security_group)
        validation_results = [
            {
                "group_index": 0,
                "group_id": security_gid,
                "status": "valid",
                "reason": "Security issue",
                "confidence": 0.9
            }
        ]

        # New group with different content
        new_group = {
            "theme": "Performance",
            "category": "perf",
            "models": ["model-b"],
            "suggestions": [{"title": "Cache", "desc": "Add caching", "importance": "MEDIUM", "type": "addition"}]
        }

        # Apply validation to just the new group at index 0
        result = apply_validation_to_groups([new_group], validation_results)

        # The security verdict is hashed to a group that is not here; the new
        # group at its index gets the default, not the security group's verdict.
        assert result[0]["validation_status"] == "needs-human-decision"
        assert result[0]["validation_reason"] == "No validation result"
        assert result[0]["validation_confidence"] == 0.0
        assert "1 of 1 groups have no validation result" in capsys.readouterr().out

        # A hash-less record is the pre-hash format, where the index *is* the
        # identity — that fallback is kept.
        legacy = [{"group_index": 0, "status": "valid", "reason": "Legacy", "confidence": 0.5}]
        assert apply_validation_to_groups([new_group], legacy)[0]["validation_status"] == "valid"

    def test_batch_validation_with_reaggregation(self, temp_dir):
        """Test batched validation workflow handles reaggregation correctly.

        Simulates a more complex scenario with batched validation results
        being merged and then reapplied after group reordering.
        """
        # Create 6 groups that will be batched
        groups = [
            make_group("HIGH", "Security", "Fix SQL injection"),
            make_group("MEDIUM", "Performance", "Add caching"),
            make_group("MEDIUM", "Reliability", "Add error handling"),
            make_group("MEDIUM", "Testing", "Add unit tests"),
            make_group("LOW", "Style", "Fix formatting"),
            make_group("LOW", "Docs", "Add comments"),
        ]

        # Prepare batched tasks
        batch_metadata = prepare_batched_validation_tasks(
            groups=groups,
            context="Test plan context",
            output_dir=temp_dir,
            plan_file="/test/plan.md",
            max_per_batch=4
        )

        # Simulate subagent writing batch results
        for batch in batch_metadata["batches"]:
            # Use global indices as subagents typically do
            batch_results = {
                "groups": [
                    {
                        "group_index": idx,
                        "status": "valid" if idx == 0 else "needs-human-decision",
                        "reason": f"Validated group {idx}",
                        "confidence": 0.9 if idx == 0 else 0.6
                    }
                    for idx in batch["group_indices"]
                ],
                "metadata": {"model": "test", "schema_version": "2.1"}
            }
            with open(batch["output_path"], 'w', encoding="utf-8") as f:
                json.dump(batch_results, f)

        # Merge batch results
        merged = merge_batched_validation_results(
            output_dir=temp_dir,
            batch_metadata=batch_metadata,
            total_groups=len(groups)
        )

        # Verify all results have group_ids
        for i, result in enumerate(merged):
            assert "group_id" in result, f"Result {i} missing group_id"

        # Now simulate reaggregation - reverse the order
        reordered_groups = list(reversed(groups))

        # Apply merged validation to reordered groups
        final_result = apply_validation_to_groups(reordered_groups, merged)

        # Find where the Security group ended up (should be last after reversal)
        security_index = 5  # Was index 0, now at index 5 after reversal

        # Verify Security group (HIGH priority, originally index 0) still has "valid"
        assert final_result[security_index]["validation_status"] == "valid"
        assert "Validated group 0" in final_result[security_index]["validation_reason"]


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
