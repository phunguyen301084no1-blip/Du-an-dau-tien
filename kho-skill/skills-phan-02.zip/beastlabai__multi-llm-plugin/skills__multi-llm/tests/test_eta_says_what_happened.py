"""The ``[ETA]`` lines say what happened, and one run is counted one way.

Fix round 24, from live run 10 (2026-10-07):

* #5 (OpenCode racing 06 and 06b): T002 timed out at its 1200 s slot
  budget, and the line read "task 2/11 done in 20m 5s · ~109m 30s
  remaining"; on the resume it timed out again after editing ``index.html``,
  and the line read "task 1/10 done in 20m 5s · ~133m 16s remaining". It
  said "done" for a task that failed, and the remaining time averaged the
  20-minute timeout in. The line of a failed task now says it failed, how,
  and whether its edits were half-applied, on both legs, and no
  remaining-time estimate counts a failed task as progress.
* #7 (the stop fixture, every host): "Organized into 3 execution batches: 5
  task(s) to dispatch", then "task 1/5" and "task 2/4" with nothing saying
  why the total dropped, and summary.md said "5 batch task(s) dispatched
  across 4 batch(es)" for a run that dispatched 4 tasks in 3 batches: T005,
  refused before dispatch, and its batch were counted. The line that drops
  the total says why, and summary.md counts what ran.
* Claude Code racing #6: "task 10/10 done … ALL TASKS COMPLETE" while the
  manual T011 and T012 were left for the user. The line says what is true:
  every dispatched task is complete, and it names what is left.
"""

from __future__ import annotations

import json
import re
from datetime import datetime, timedelta
from pathlib import Path

import pytest

from tests.test_check_gate_fixture import (  # noqa: F401  (the fixture)
    DENY,
    FINDINGS,
    _first_run,
    _policy,
    repo,
)
from tests.test_dispatch_counts import LIVE_LAYOUT, _emit, _util
from tests.test_implement_stop_account import _implement, make_repo
from utils import metrics
from utils import provider_registry as registry
from utils.retry_ladder import STATUS_TIMEOUT
from utils.subagent_executor import Attempt, TaskOutcome

#: Three edits, so a failed T002 is neither the first task nor the last.
THREE_EDITS = """# Three edits

## Overview
Three edits.

## Tasks

### T001: Edit: create the module
Create it.
- Depends on: none
- Files to modify: src/main.py

### T002: Edit: extend the module
Extend it.
- Depends on: T001
- Files to modify: src/main.py

### T003: Edit: finish the module
Finish it.
- Depends on: T002
- Files to modify: src/main.py
"""

#: Two edits, a manual task, and a code task that depends on the manual one.
WITH_MANUAL = """# With a manual task

## Overview
Two edits and a play-through.

## Tasks

### T001: Edit: create the module
Create it.
- Depends on: none
- Files to modify: src/main.py

### T002: Edit: extend the module
Extend it.
- Depends on: T001
- Files to modify: src/main.py

### T003: Play through by hand
**Type**: Manual (user action required)
Open the page and race.
- Depends on: T002

### T004: Edit: tune after the play-through
Tune it.
- Depends on: T003
- Files to modify: src/main.py
"""

#: What the manual plan leaves the user, on both legs.
LEFT_FOR_YOU = "T003 left for you (manual); T004 skipped with a manual task"


def _eta_lines(text: str) -> list:
    return [line for line in text.splitlines() if line.startswith("[ETA] implement:")]


def _run(repo_obj, capsys, *flags) -> tuple:
    code = _implement(repo_obj, *flags)
    captured = capsys.readouterr()
    return code, captured.out + captured.err


@pytest.fixture
def three_edits(tmp_path, monkeypatch):
    obj = make_repo(tmp_path, monkeypatch, THREE_EDITS)
    monkeypatch.setenv("MOCK_LLM_WRITE_IDS", json.dumps(["T001", "T002", "T003"]))
    yield obj
    registry._config = None
    registry._config_key = None


@pytest.fixture
def with_manual(tmp_path, monkeypatch):
    obj = make_repo(tmp_path, monkeypatch, WITH_MANUAL)
    monkeypatch.setenv("MOCK_LLM_WRITE_IDS", json.dumps(["T001", "T002", "T004"]))
    yield obj
    registry._config = None
    registry._config_key = None


def _time_out(monkeypatch, task_id: str, *, edit: bool) -> None:
    """Make *task_id*'s runner time out after 20 minutes, the way big-pickle
    did in live run 10 (``edit``: after changing ``src/main.py``, the 06b
    partial application)."""
    from utils.write_batch_scheduler import WriteBatchScheduler

    real = WriteBatchScheduler._dispatch_executor

    def dispatch(self, task, prompt, snapshot, profile, declared, **kwargs):
        if task.get("task_id") != task_id:
            return real(self, task, prompt, snapshot, profile, declared, **kwargs)
        if edit:
            path = Path(self.repo_root) / "src" / "main.py"
            path.write_text(path.read_text() + "# half of it\n")
        outcome = TaskOutcome(
            task_id=task_id, kind=self.kind, runner="codex:gpt-5.5",
            status=STATUS_TIMEOUT, profile=profile, duration_seconds=1205.6,
            reason="the runner exceeded its per-task timeout and was killed",
            attempts=[Attempt(index=1, status=STATUS_TIMEOUT, duration_seconds=1205.6)],
        )
        outcome.ran_out_of_time = edit
        return outcome

    monkeypatch.setattr(WriteBatchScheduler, "_dispatch_executor", dispatch)


class TestAFailedTaskSaysSoOnTheExecutor:

    def test_a_timeout_reads_failed_not_done(self, three_edits, capsys, monkeypatch):
        _time_out(monkeypatch, "T002", edit=False)
        code, text = _run(three_edits, capsys)
        assert code == 3, text
        lines = _eta_lines(text)
        assert lines[0].startswith("[ETA] implement: task 1/3 done in "), lines
        assert lines[1] == "[ETA] implement: task 2/3 failed (timeout) after 20m 5s", lines
        assert not any("task 2/3 done" in line for line in lines), lines
        assert lines[-1] == "[ETA] implement: run stopped after task 2/3 · T003 not run", lines

    def test_a_half_applied_timeout_says_its_edits_are_kept(
        self, three_edits, capsys, monkeypatch,
    ):
        _time_out(monkeypatch, "T002", edit=True)
        code, text = _run(three_edits, capsys)
        assert code == 3, text
        assert "partial application" in text, text
        lines = _eta_lines(text)
        assert lines[1] == (
            "[ETA] implement: task 2/3 failed (timeout) after 20m 5s · "
            "half-applied: its edits are kept"
        ), lines

    def test_a_failure_the_runner_reported_names_its_status(
        self, three_edits, capsys,
    ):
        """The runner said it failed and changed nothing: a clean failure."""
        three_edits.monkeypatch.setenv(
            "MOCK_LLM_EDITS_IF_PROMPT_HAS", "Title: Edit: create the module")
        three_edits.monkeypatch.setenv(
            "MOCK_LLM_WRITE_FAIL_IF_PROMPT_HAS", "Title: Edit: extend the module")
        code, text = _run(three_edits, capsys)
        assert code == 3, text
        lines = _eta_lines(text)
        assert re.fullmatch(
            r"\[ETA\] implement: task 2/3 failed \(batch failed\) after [^·]+",
            lines[1],
        ), text

    def test_a_runner_that_failed_after_editing_is_half_applied(
        self, three_edits, capsys,
    ):
        three_edits.monkeypatch.setenv(
            "MOCK_LLM_WRITE_FAIL_IF_PROMPT_HAS", "Title: Edit: extend the module")
        code, text = _run(three_edits, capsys)
        assert code == 3, text
        lines = _eta_lines(text)
        assert re.fullmatch(
            r"\[ETA\] implement: task 2/3 failed( \([^)]+\))? after [^·]+ · "
            r"half-applied: its edits are kept",
            lines[1],
        ), text
        assert "remaining" not in lines[1], lines


def _native_state(total: int, started_s_ago: float) -> dict:
    state = {"metrics": {}, "task_status": {}}
    metrics.start_phase_in_state(state, "implement", total)
    progress = state["metrics_progress"]["implement"]
    progress["started_at"] = (
        datetime.now() - timedelta(seconds=started_s_ago)
    ).isoformat()
    return state


def _fail(state: dict, task_id: str, reason: str) -> None:
    """What ``util batch-done --status failed --reason …`` records."""
    state["task_status"][task_id] = "failed"
    state.setdefault("task_status_reasons", {})[task_id] = reason
    metrics.mark_failed_in_progress(state, "implement", task_id, failed=True)


class TestAFailedTaskSaysSoOnTheNativeLeg:

    def test_the_record_after_a_failed_batch_done_reads_failed(self):
        state = _native_state(11, 1500)
        metrics.record_metric_in_state(
            state, "implement", "T001: Scaffold", duration_ms=254_000,
            total_batches=11, batch_index=1)
        _fail(state, "T002", "the subagent timed out after 20 minutes")
        line = metrics.record_metric_in_state(
            state, "implement", "T002: Build the track", duration_ms=1_205_600,
            total_batches=11, batch_index=2)
        assert line == (
            "[ETA] implement: task 2/11 failed (the subagent timed out after "
            "20 minutes) after 20m 5s"
        ), line

    def test_a_partial_record_says_half_applied(self):
        state = _native_state(10, 1300)
        # `util batch-done --status failed --partial` prefixes the reason.
        _fail(state, "T002", "half-applied: the subagent timed out")
        line = metrics.record_metric_in_state(
            state, "implement", "T002: Build the track", duration_ms=1_205_600,
            total_batches=10, batch_index=1)
        assert line == (
            "[ETA] implement: task 1/10 failed (the subagent timed out) after "
            "20m 5s · half-applied: its edits are kept"
        ), line

    def test_the_estimate_never_counts_the_failed_task(self):
        """T001 and T003 took a minute each, T002 timed out at 20: two tasks
        are left, so about two minutes, not the 14m 40s an average over the
        timeout gave."""
        state = _native_state(5, 1320)
        metrics.record_metric_in_state(
            state, "implement", "T001: a", duration_ms=60_000,
            total_batches=5, batch_index=1)
        _fail(state, "T002", "timeout")
        metrics.record_metric_in_state(
            state, "implement", "T002: b", duration_ms=1_200_000,
            total_batches=5, batch_index=2)
        line = metrics.record_metric_in_state(
            state, "implement", "T003: c", duration_ms=60_000,
            total_batches=5, batch_index=3)
        assert line == (
            "[ETA] implement: task 3/5 done in 1m 0s · ~2m 0s remaining"
        ), line

    def test_an_apply_batch_is_named_by_the_task_id_flag(self, tmp_path, capsys):
        """An apply phase's label is ``Batch {N} ({key})``: the host passes
        the batch's task id with ``--task-id``."""
        state = {"metrics": {}, "task_status": {}}
        metrics.start_phase_in_state(state, "apply-code-fixes", 2)
        state["task_status"]["apply-fix-batch-0"] = "failed"
        state["task_status_reasons"] = {"apply-fix-batch-0": "the runner exited 1"}
        metrics.mark_failed_in_progress(
            state, "apply-code-fixes", "apply-fix-batch-0", failed=True)
        state_file = tmp_path / "state.json"
        state_file.write_text(json.dumps(state), encoding="utf-8")
        code, _out, err = _util(
            capsys, "metrics", "record", "--state-file", str(state_file),
            "--phase", "apply-code-fixes", "--label", "Batch 1 (src/main.py)",
            "--task-id", "apply-fix-batch-0", "--duration-ms", "4000",
            "--total-batches", "2", "--batch-index", "1")
        assert code == 0, err
        assert (
            "[ETA] apply-code-fixes: batch 1/2 failed (the runner exited 1) "
            "after 0m 4s"
        ) in err, err
        entry = json.loads(state_file.read_text())["metrics"]["apply-code-fixes"][0]
        assert entry["task_id"] == "apply-fix-batch-0"
        assert entry["failed"] is True


class TestTheNativeRecordsReadTheBatchDoneRecord:
    """Through the CLI, as ``instructions/implement.md`` step 5 runs it."""

    def test_a_partial_record_reads_half_applied_on_its_line(self, repo, capsys):
        handoff, _out = _emit(repo, capsys)
        state_file = handoff["state_file"]
        total = str(handoff["tasks_to_dispatch"])
        assert _util(capsys, "metrics", "start", "--state-file", state_file,
                     "--phase", "implement", "--total-batches", total)[0] == 0
        code, _o, err = _util(
            capsys, "batch-done", "--phase-dir", str(repo.phase_dir),
            "--task-id", "T001", "--status", "failed", "--partial",
            "--reason", "the subagent timed out after 20 minutes")
        assert code == 0, err
        code, _o, err = _util(
            capsys, "metrics", "record", "--state-file", state_file,
            "--phase", "implement", "--label", "T001: Create the configuration",
            "--task-id", "T001", "--duration-ms", "1205600",
            "--total-batches", total, "--batch-index", "1")
        assert code == 0, err
        # Every other task depends on T001, so the host skips them: the
        # line that took them out of the total names them.
        assert _eta_lines(err) == [
            "[ETA] implement: task 1/1 failed (the subagent timed out after 20 "
            "minutes) after 20m 5s · half-applied: its edits are kept · total now "
            "1 (T002, T003, T004, T007 not run)"
        ], err

    def test_the_half_applied_prefix_is_the_schedulers(self):
        from utils.write_batch_scheduler import HALF_APPLIED_PREFIX

        assert metrics.HALF_APPLIED_PREFIX == HALF_APPLIED_PREFIX


class TestTheLineThatDropsTheTotalSaysWhy:
    """The stop fixture in the live layout: T007 waits on check T002."""

    @staticmethod
    def _live(tmp_path, monkeypatch):
        obj = make_repo(tmp_path, monkeypatch, LIVE_LAYOUT)
        _policy(obj, DENY)
        monkeypatch.setenv("MOCK_LLM_WRITE_IDS", json.dumps(
            [f"T00{n}" for n in range(1, 8)]))
        monkeypatch.setenv("MOCK_LLM_WRITE_CHECK_IF_PROMPT_HAS", "Title: Check the module")
        return obj

    def test_the_executor_names_the_held_task_on_the_checks_line(
        self, tmp_path, monkeypatch, capsys,
    ):
        obj = self._live(tmp_path, monkeypatch)
        text = _first_run(obj, capsys)
        lines = _eta_lines(text)
        assert lines[0].startswith("[ETA] implement: task 1/5 done in "), lines
        assert re.fullmatch(
            r"\[ETA\] implement: task 2/4 done in [^·]+ · total now 4 \(T007 "
            r"not run: check T002 reported problems\)( · ~[^·]+ remaining)?",
            lines[1],
        ), lines
        # Only the line that dropped it says so.
        assert not any("total now" in line for line in lines[2:]), lines

    def test_summary_md_counts_the_tasks_and_batches_that_ran(
        self, tmp_path, monkeypatch, capsys,
    ):
        obj = self._live(tmp_path, monkeypatch)
        _first_run(obj, capsys)
        summary = (obj.phase_dir / "summary.md").read_text(encoding="utf-8")
        assert "4 task(s) dispatched across 3 batch(es)" in summary, summary
        assert "batch task(s)" not in summary, summary
        assert "Refused before dispatch (no runner started): T005." in summary, summary

    def test_summary_md_of_a_resume_that_dispatched_nothing_says_so(
        self, tmp_path, monkeypatch, capsys,
    ):
        """01b: the same stop on unchanged files, nothing dispatched."""
        obj = self._live(tmp_path, monkeypatch)
        _first_run(obj, capsys)
        code, _text = _run(obj, capsys, "--resume")
        assert code == 3, _text
        summary = (obj.phase_dir / "summary.md").read_text(encoding="utf-8")
        assert (
            "Nothing was dispatched in this run. Refused before dispatch (no "
            "runner started): T005."
        ) in summary, summary
        assert "dispatched across" not in summary, summary

    def test_the_native_leg_names_it_on_the_checks_line_too(self, repo, capsys):
        handoff, _out = _emit(repo, capsys)
        state_file = handoff["state_file"]
        total = str(handoff["tasks_to_dispatch"])
        assert _util(capsys, "metrics", "start", "--state-file", state_file,
                     "--phase", "implement", "--total-batches", total)[0] == 0
        lines = []
        for index, task_id in enumerate(("T001", "T002", "T003", "T004"), 1):
            extra = (
                ("--check", "findings", "--finding", FINDINGS[0])
                if task_id == "T002" else ()
            )
            code, _o, err = _util(
                capsys, "batch-done", "--phase-dir", str(repo.phase_dir),
                "--task-id", task_id, "--status", "completed", *extra)
            assert code == 0, err
            code, _o, err = _util(
                capsys, "metrics", "record", "--state-file", state_file,
                "--phase", "implement", "--label", f"{task_id}: task",
                "--subagent-type", "agent", "--duration-ms", "1000",
                "--total-batches", total, "--batch-index", str(index))
            assert code == 0, err
            lines += _eta_lines(err)
        assert re.fullmatch(
            r"\[ETA\] implement: task 2/4 done in [^·]+ · total now 4 \(T007 "
            r"not run: check T002 reported problems\)( · ~[^·]+ remaining)?",
            lines[1],
        ), lines
        assert not any("total now" in line for line in lines[2:]), lines


class TestManualTasksAreNotComplete:

    def test_the_executor_names_what_is_left_for_you(self, with_manual, capsys):
        code, text = _run(with_manual, capsys)
        assert code == 0, text
        lines = _eta_lines(text)
        assert re.fullmatch(
            r"\[ETA\] implement: task 2/2 done in [^·]+ · ALL DISPATCHED TASKS "
            r"COMPLETE · " + re.escape(LEFT_FOR_YOU),
            lines[-2],
        ), lines
        assert "ALL TASKS COMPLETE" not in text, text
        # The phase's own closing line keeps its meaning.
        assert lines[-1].startswith("[ETA] implement: phase complete in "), lines

    def test_the_native_leg_names_the_same_tasks(self, with_manual, capsys):
        handoff, _out = _emit(with_manual, capsys)
        state_file = handoff["state_file"]
        total = str(handoff["tasks_to_dispatch"])
        assert total == "2", handoff
        assert _util(capsys, "metrics", "start", "--state-file", state_file,
                     "--phase", "implement", "--total-batches", total)[0] == 0
        err = ""
        for index, task_id in enumerate(("T001", "T002"), 1):
            code, _o, e = _util(
                capsys, "batch-done", "--phase-dir", str(with_manual.phase_dir),
                "--task-id", task_id, "--status", "completed")
            assert code == 0, e
            code, _o, e = _util(
                capsys, "metrics", "record", "--state-file", state_file,
                "--phase", "implement", "--label", f"{task_id}: task",
                "--duration-ms", "1000",
                "--total-batches", total, "--batch-index", str(index))
            assert code == 0, e
            err += e
        last = _eta_lines(err)[-1]
        assert re.fullmatch(
            r"\[ETA\] implement: task 2/2 done in [^·]+ · ALL DISPATCHED TASKS "
            r"COMPLETE · " + re.escape(LEFT_FOR_YOU),
            last,
        ), last
        code, _o, e = _util(capsys, "metrics", "finish", "--state-file", state_file,
                            "--phase", "implement")
        assert code == 0, e
        assert _eta_lines(e)[0].startswith("[ETA] implement: phase complete in "), e

    def test_a_manual_task_still_waiting_for_its_answer_is_named_too(
        self, tmp_path, monkeypatch, capsys,
    ):
        """Native pause-and-ask: the host asks at the manual task, so a
        trailing one with no dependents is still unanswered at N/N."""
        import implement_orchestrator

        obj = make_repo(tmp_path, monkeypatch, WITH_MANUAL.split("### T004")[0])
        try:
            assert implement_orchestrator.main([
                "--plan-file", str(obj.plan), "--force-strategy", "pause-and-ask",
            ]) == 0
            out = capsys.readouterr().out
            path = next(
                line.split(": ", 1)[1] for line in out.splitlines()
                if line.startswith("Output file: ")
            )
            handoff = json.loads(open(path, encoding="utf-8").read())
            state_file = handoff["state_file"]
            total = str(handoff["tasks_to_dispatch"])
            assert total == "2", out
            assert _util(capsys, "metrics", "start", "--state-file", state_file,
                         "--phase", "implement", "--total-batches", total)[0] == 0
            err = ""
            for index, task_id in enumerate(("T001", "T002"), 1):
                code, _o, e = _util(
                    capsys, "batch-done", "--phase-dir", str(obj.phase_dir),
                    "--task-id", task_id, "--status", "completed")
                assert code == 0, e
                code, _o, e = _util(
                    capsys, "metrics", "record", "--state-file", state_file,
                    "--phase", "implement", "--label", f"{task_id}: task",
                    "--duration-ms", "1000",
                    "--total-batches", total, "--batch-index", str(index))
                assert code == 0, e
                err += e
            assert _eta_lines(err)[-1].endswith(
                "· ALL DISPATCHED TASKS COMPLETE · T003 left for you (manual)"
            ), err
        finally:
            registry._config = None
            registry._config_key = None

    def test_a_run_with_nothing_set_aside_still_says_all_tasks_complete(self):
        state = {"metrics": {}}
        metrics.start_phase_in_state(state, "implement", 1)
        line = metrics.record_metric_in_state(
            state, "implement", "T001: t", duration_ms=10,
            total_batches=1, batch_index=1)
        assert line.endswith("· ALL TASKS COMPLETE"), line


class TestARecordThatNamesNoTask:
    """Fix round 25 (review of round 24, stops #2): a native ``util metrics
    record`` with no ``--task-id`` whose label does not start with ``<id>:
    `` read "done" for a task ``util batch-done`` had just recorded failed,
    and the next estimate averaged its duration in. With exactly one failed
    task of this run still unrecorded, the record is that task's; with two
    or more, it is never guessed: a ``[METRICS_NO_TASK_ID]`` line asks for
    ``--task-id``, and the record counts as no progress."""

    def test_the_one_failed_task_without_a_record_is_the_one_measured(self):
        state = _native_state(5, 200)
        metrics.record_metric_in_state(
            state, "implement", "T001: a", duration_ms=60_000,
            total_batches=5, batch_index=1, task_id="T001")
        _fail(state, "T004", "crash")
        line = metrics.record_metric_in_state(
            state, "implement", "fourth task", duration_ms=30_000,
            total_batches=5, batch_index=2)
        assert line == "[ETA] implement: task 2/5 failed (crash) after 0m 30s", line
        entry = state["metrics"]["implement"][-1]
        assert entry["task_id"] == "T004" and entry["failed"] is True

    def test_a_label_word_that_is_no_task_names_no_task(self):
        """``Retry: the fourth task`` starts with a word and a colon, not a
        task id of this run."""
        state = _native_state(5, 200)
        state["task_status"]["T001"] = "completed"
        _fail(state, "T004", "crash")
        line = metrics.record_metric_in_state(
            state, "implement", "Retry: the fourth task", duration_ms=30_000,
            total_batches=5, batch_index=2)
        assert line == "[ETA] implement: task 2/5 failed (crash) after 0m 30s", line

    def test_a_failed_task_already_measured_is_not_a_candidate(self):
        """T002's record carried its id; the next id-less record is a task
        that did not fail."""
        state = _native_state(5, 200)
        _fail(state, "T002", "timeout")
        metrics.record_metric_in_state(
            state, "implement", "T002: b", duration_ms=60_000,
            total_batches=5, batch_index=1)
        line = metrics.record_metric_in_state(
            state, "implement", "third task", duration_ms=60_000,
            total_batches=5, batch_index=2)
        assert line.startswith("[ETA] implement: task 2/5 done in 1m 0s"), line
        assert "failed" not in state["metrics"]["implement"][-1]

    def test_two_candidates_are_never_guessed_between(self, capsys):
        state = _native_state(5, 1500)
        metrics.record_metric_in_state(
            state, "implement", "T001: a", duration_ms=60_000,
            total_batches=5, batch_index=1, task_id="T001")
        _fail(state, "T002", "timeout")
        _fail(state, "T003", "crash")
        capsys.readouterr()
        line = metrics.record_metric_in_state(
            state, "implement", "a task", duration_ms=1_200_000,
            total_batches=5, batch_index=2)
        assert line is None
        err = capsys.readouterr().err
        notes = [l for l in err.splitlines() if l.startswith("[METRICS_NO_TASK_ID] ")]
        assert notes == [
            '[METRICS_NO_TASK_ID] implement: "a task" (batch 2) names no task, '
            "and T002 and T003 failed in this run with no record yet, so it is "
            "not counted as progress: pass --task-id <id> (the task it "
            "measures) on every util metrics record call of a task."], err
        entry = state["metrics"]["implement"][-1]
        assert "task_id" not in entry and "failed" not in entry
        # Its 20 minutes are averaged in nowhere: T004's estimate is T001's
        # and T004's minute each over the one task left.
        line = metrics.record_metric_in_state(
            state, "implement", "T004: d", duration_ms=60_000,
            total_batches=5, batch_index=4, task_id="T004")
        assert line == "[ETA] implement: task 4/5 done in 1m 0s · ~1m 0s remaining", line

    def test_through_the_cli(self, tmp_path, capsys):
        state = _native_state(3, 100)
        _fail(state, "T001", "timeout")
        _fail(state, "T002", "timeout")
        state_file = tmp_path / "state.json"
        state_file.write_text(json.dumps(state), encoding="utf-8")
        code, _out, err = _util(
            capsys, "metrics", "record", "--state-file", str(state_file),
            "--phase", "implement", "--label", "the first task",
            "--duration-ms", "4000", "--total-batches", "3", "--batch-index", "1")
        assert code == 0, err
        assert "[METRICS_NO_TASK_ID] " in err and "pass --task-id <id>" in err, err
        assert _eta_lines(err) == [], err
        first = json.loads(state_file.read_text())["metrics"]["implement"][0]
        code, _out, err = _util(
            capsys, "metrics", "record", "--state-file", str(state_file),
            "--phase", "implement", "--label", "the first task",
            "--duration-ms", "4000", "--total-batches", "3", "--batch-index", "1",
            "--task-id", "T001")
        assert code == 0, err
        assert _eta_lines(err) == [
            "[ETA] implement: task 1/3 failed (timeout) after 0m 4s"]
        entries = json.loads(state_file.read_text())["metrics"]["implement"]
        assert len(entries) == 1
        assert entries[0] == {
            **{k: v for k, v in first.items() if k != "no_task_id"},
            "task_id": "T001", "failed": True,
        }

    @pytest.mark.parametrize("duration", [None, 4000])
    @pytest.mark.parametrize("task_id", ["T001", "T003"])
    def test_identity_correction_keeps_one_measurement(self, duration, task_id):
        state = _native_state(3, 100)
        _fail(state, "T001", "timeout")
        _fail(state, "T002", "crash")
        metrics.record_metric_in_state(
            state, "implement", "a task", duration_ms=4000,
            total_batches=3, batch_index=1)
        line = metrics.record_metric_in_state(
            state, "implement", "a task", duration_ms=duration,
            total_batches=3, batch_index=1, task_id=task_id)
        entries = state["metrics"]["implement"]
        assert len(entries) == 1
        assert entries[0]["task_id"] == task_id
        assert entries[0]["duration_ms"] == 4000
        assert "no_task_id" not in entries[0]
        if task_id == "T001":
            assert entries[0]["failed"] is True
            assert line == "[ETA] implement: task 1/3 failed (timeout) after 0m 4s"
        else:
            assert "failed" not in entries[0]
            assert "task 1/3 done in 0m 4s" in line

    def test_changed_numbers_do_not_correct_an_ambiguous_measurement(self, capsys):
        state = _native_state(3, 100)
        _fail(state, "T001", "timeout")
        _fail(state, "T002", "crash")
        metrics.record_metric_in_state(
            state, "implement", "a task", duration_ms=4000,
            total_batches=3, batch_index=1)
        before = dict(state["metrics"]["implement"][0])
        capsys.readouterr()
        assert metrics.record_metric_in_state(
            state, "implement", "a task", duration_ms=5000,
            total_batches=3, batch_index=1, task_id="T001") is None
        assert "[METRICS_CONFLICT]" in capsys.readouterr().err
        assert state["metrics"]["implement"] == [before]

    @pytest.mark.parametrize("label, first_id", [("a task", "T001"), ("T001: task", None)])
    def test_established_identity_cannot_be_reassigned(self, label, first_id, capsys):
        state = _native_state(3, 100)
        _fail(state, "T001", "timeout")
        _fail(state, "T002", "crash")
        metrics.record_metric_in_state(
            state, "implement", label, duration_ms=4000,
            total_batches=3, batch_index=1, task_id=first_id)
        before = dict(state["metrics"]["implement"][0])
        capsys.readouterr()
        assert metrics.record_metric_in_state(
            state, "implement", label, duration_ms=4000,
            total_batches=3, batch_index=1, task_id="T002") is None
        assert "[METRICS_CONFLICT]" in capsys.readouterr().err
        assert state["metrics"]["implement"] == [before]

    def test_enriching_measurements_does_not_clear_a_recorded_failure(self):
        state = _native_state(3, 100)
        _fail(state, "T001", "timeout")
        metrics.record_metric_in_state(
            state, "implement", "a task", duration_ms=4000,
            total_batches=3, batch_index=1, task_id="T001")
        line = metrics.record_metric_in_state(
            state, "implement", "a task", duration_ms=4000, token_count=40,
            total_batches=3, batch_index=1, failed=False)
        entries = state["metrics"]["implement"]
        assert len(entries) == 1
        assert entries[0]["task_id"] == "T001"
        assert entries[0]["token_count"] == 40
        assert entries[0]["failed"] is True
        assert line == "[ETA] implement: task 1/3 failed (timeout) after 0m 4s"
