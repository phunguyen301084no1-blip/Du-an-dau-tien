#!/usr/bin/env python3
"""
Integration tests for apply_suggestions_orchestrator.py

These tests run the orchestrator with various options and verify the output.
They use mock data in plans/test-plan/ to avoid calling real LLMs.

To run these tests:
    uv run -- pytest tests/test_apply_suggestions_integration.py -v

To regenerate the test fixtures:
    uv run -- python tests/test_apply_suggestions_integration.py --setup-fixtures
"""

import copy
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

# Test directory setup
SKILL_DIR = Path(__file__).parent.parent
PLANS_DIR = SKILL_DIR / "plans"
TEST_PLAN_DIR = PLANS_DIR / "test-plan"
TEST_PLAN_FILE = PLANS_DIR / "test-plan.md"


class TestFixtures:
    """Test data fixtures for integration tests."""

    PLAN_CONTENT = """# Test Plan: User Authentication Feature

## Overview
Implement a user authentication system with login, logout, and session management.

## Step 1: Database Schema
Create the users table with the following fields:
- id: UUID primary key
- email: unique, not null
- password_hash: not null
- created_at: timestamp
- updated_at: timestamp

## Step 2: User Model
Create the User model with validation for email format and password requirements.

## Step 3: Authentication Service
Implement the authentication service with:
- login(email, password) - validates credentials and returns session token
- logout(token) - invalidates the session
- verify_token(token) - checks if token is valid

## Step 4: API Endpoints
Create REST endpoints:
- POST /auth/login - accepts email/password, returns token
- POST /auth/logout - invalidates current session
- GET /auth/me - returns current user info

## Step 5: Session Management
Implement session storage using Redis with:
- 24-hour TTL for session tokens
- Automatic renewal on activity
- Multi-device support

## Step 6: Security Measures
Add security features:
- Rate limiting on login attempts
- Password hashing with bcrypt
- HTTPS enforcement
- CSRF protection

## Step 7: Testing
Write comprehensive tests:
- Unit tests for User model
- Integration tests for auth service
- E2E tests for API endpoints
"""

    GROUPED_SUGGESTIONS = [
        {
            "theme": "Add input validation for email",
            "category": "security",
            "models": ["claude-sonnet", "gpt-4"],
            "suggestions": [{
                "title": "Add email format validation",
                "desc": "Add regex validation to ensure email addresses are in valid format.",
                "type": "addition",
                "reference": "### Step 2: User Model",
                "importance": "HIGH",
                "source_model": "claude-sonnet"
            }]
        },
        {
            "theme": "Add password complexity requirements",
            "category": "security",
            "models": ["gpt-4"],
            "suggestions": [{
                "title": "Enforce password complexity",
                "desc": "Require passwords to have at least 8 characters with mixed case and special chars.",
                "type": "addition",
                "reference": "### Step 2: User Model",
                "importance": "MEDIUM",
                "source_model": "gpt-4"
            }]
        },
        {
            "theme": "Add account lockout after failed attempts",
            "category": "security",
            "models": ["claude-sonnet", "gpt-4", "gemini-pro"],
            "suggestions": [{
                "title": "Implement account lockout",
                "desc": "Lock account for 15 minutes after 5 failed login attempts.",
                "type": "addition",
                "reference": "### Step 6: Security Measures",
                "importance": "HIGH",
                "source_model": "claude-sonnet"
            }]
        },
        {
            "theme": "Add session activity logging",
            "category": "monitoring",
            "models": ["claude-sonnet"],
            "suggestions": [{
                "title": "Log session activities",
                "desc": "Add logging for login, logout, and token refresh events.",
                "type": "addition",
                "reference": "### Step 5: Session Management",
                "importance": "LOW",
                "source_model": "claude-sonnet"
            }]
        },
        {
            "theme": "Clarify token storage approach",
            "category": "architecture",
            "models": ["gpt-4"],
            "suggestions": [{
                "title": "Specify token storage location",
                "desc": "The plan doesn't specify whether to use cookies or localStorage.",
                "type": "clarification",
                "reference": "### Step 4: API Endpoints",
                "importance": "MEDIUM",
                "source_model": "gpt-4"
            }]
        },
        {
            "theme": "Add refresh token mechanism",
            "category": "architecture",
            "models": ["gemini-pro"],
            "suggestions": [{
                "title": "Implement refresh tokens",
                "desc": "Add refresh token support for long-lived sessions.",
                "type": "addition",
                "reference": "### Step 3: Authentication Service",
                "importance": "MEDIUM",
                "source_model": "gemini-pro"
            }]
        },
        {
            "theme": "Remove redundant HTTPS mention",
            "category": "cleanup",
            "models": ["claude-sonnet"],
            "suggestions": [{
                "title": "Remove HTTPS enforcement from plan",
                "desc": "HTTPS is typically handled at infrastructure level.",
                "type": "deletion",
                "reference": "### Step 6: Security Measures",
                "importance": "LOW",
                "source_model": "claude-sonnet"
            }]
        },
        {
            "theme": "Add database indexes",
            "category": "performance",
            "models": ["gpt-4", "gemini-pro"],
            "suggestions": [{
                "title": "Add index on email column",
                "desc": "Add a unique index on the email column to speed up login queries.",
                "type": "addition",
                "reference": "### Step 1: Database Schema",
                "importance": "MEDIUM",
                "source_model": "gpt-4"
            }]
        },
        {
            "theme": "Add password reset functionality",
            "category": "feature",
            "models": ["claude-sonnet", "gpt-4"],
            "suggestions": [{
                "title": "Add password reset flow",
                "desc": "The authentication system should include a password reset mechanism.",
                "type": "addition",
                "reference": "### Step 4: API Endpoints",
                "importance": "HIGH",
                "source_model": "claude-sonnet"
            }]
        },
        {
            "theme": "Update test coverage requirements",
            "category": "testing",
            "models": ["gemini-pro"],
            "suggestions": [{
                "title": "Specify minimum coverage threshold",
                "desc": "Add requirement for minimum 80% code coverage.",
                "type": "modification",
                "reference": "### Step 7: Testing",
                "importance": "LOW",
                "source_model": "gemini-pro"
            }]
        }
    ]

    VALIDATION_RESULTS = {
        "metadata": {
            "schema_version": "2.0",
            "validated_at": "2025-01-30T10:00:00",
            "model": "mock-llm",
            "plan_hash": "abc123",
            "total_groups": 10
        },
        "groups": [
            {"group_index": 0, "status": "valid", "reason": "Email validation is clear.", "confidence": 0.95},
            {"group_index": 1, "status": "valid", "reason": "Password complexity is well-defined.", "confidence": 0.90},
            {"group_index": 2, "status": "needs-human-decision", "reason": "Lockout config needs business input.",
             "confidence": 0.60, "error_type": "real_ambiguity", "recoverable": False},
            {"group_index": 3, "status": "valid", "reason": "Session logging is straightforward.", "confidence": 0.88},
            {"group_index": 4, "status": "needs-human-decision", "reason": "Multiple valid token storage options.",
             "confidence": 0.45, "error_type": "real_ambiguity", "recoverable": False},
            {"group_index": 5, "status": "validation_failed", "reason": "Failed to parse LLM response.",
             "confidence": 0.0, "error_type": "parsing_error", "recoverable": True},
            {"group_index": 6, "status": "valid", "reason": "HTTPS clarification is valid.", "confidence": 0.82},
            {"group_index": 7, "status": "validation_failed", "reason": "Request timed out.",
             "confidence": 0.0, "error_type": "timeout", "recoverable": True},
            {"group_index": 8, "status": "validation_failed", "reason": "Rate limit exceeded.",
             "confidence": 0.0, "error_type": "rate_limited", "recoverable": True},
            {"group_index": 9, "status": "invalid", "reason": "Too vague and not related.", "confidence": 0.75}
        ]
    }


def get_plan_hash() -> str:
    """Compute the actual plan hash for the test plan."""
    sys.path.insert(0, str(SKILL_DIR))
    from utils.state_manager import StateManager
    sm = StateManager(TEST_PLAN_FILE)
    return sm._compute_plan_hash()


def setup_test_fixtures(force: bool = False) -> None:
    """Create or refresh test fixtures.

    With ``force=True`` the whole ``plans/test-plan/`` tree is removed first, so
    the fixtures never inherit state from an earlier test or an earlier run
    (e.g. a leftover ``review-plan/report.md``, which the orchestrator would
    read as "user preferences" and which would silently change behaviour).
    """
    if TEST_PLAN_DIR.exists() and not force:
        return

    # Start from a clean tree: only ever touches this test's own fixture paths.
    if TEST_PLAN_DIR.exists():
        shutil.rmtree(TEST_PLAN_DIR)

    # Create directories
    review_plan_dir = TEST_PLAN_DIR / "review-plan"
    review_plan_dir.mkdir(parents=True, exist_ok=True)

    # Write plan file
    TEST_PLAN_FILE.write_text(TestFixtures.PLAN_CONTENT, encoding="utf-8")

    # Write grouped suggestions
    (review_plan_dir / "grouped.json").write_text(
        json.dumps(TestFixtures.GROUPED_SUGGESTIONS, indent=2), encoding="utf-8"
    )

    # Write validation results
    (review_plan_dir / "validation.json").write_text(
        json.dumps(TestFixtures.VALIDATION_RESULTS, indent=2), encoding="utf-8"
    )

    # Write backup
    (review_plan_dir / "backup.md").write_text(
        TestFixtures.PLAN_CONTENT, encoding="utf-8"
    )

    # Write state file with correct plan hash
    plan_hash = get_plan_hash()

    # Get actual group IDs
    sys.path.insert(0, str(SKILL_DIR))
    from utils.state_manager import generate_group_id

    group_ids = [generate_group_id(g) for g in TestFixtures.GROUPED_SUGGESTIONS]

    state = {
        "version": "1",
        "plan_file": "plans/test-plan.md",
        "plan_hash": plan_hash,
        "created_at": "2025-01-30T09:00:00",
        "updated_at": "2025-01-30T10:30:00",
        "human_decisions_apply-suggestions": {
            group_ids[2]: {  # Account lockout suggestion
                "decision": "approved",
                "timestamp": "2025-01-30T10:15:00",
                "reason": "User approved during previous session",
                "batch_context": {"batch_id": "batch_20250130_101500"}
            }
        },
        "processed_apply-suggestions": {
            group_ids[0]: {  # Email validation suggestion
                "status": "applied",
                "timestamp": "2025-01-30T10:20:00"
            }
        },
        "progress_apply-suggestions": {
            "last_batch_index": 1,
            "total_batches": 4,
            "started_at": "2025-01-30T10:00:00"
        }
    }
    (TEST_PLAN_DIR / "state.json").write_text(
        json.dumps(state, indent=2), encoding="utf-8"
    )


def run_orchestrator(*args, no_confirm: bool = True) -> subprocess.CompletedProcess:
    """Run the orchestrator with given arguments.

    ``no_confirm`` defaults to True: without it the orchestrator hits its
    "no user selections found" confirmation gate (no user_selections.json, no
    consolidated_user_selections.json, no edits in report.md) and short-circuits
    to a ``status: confirmation_needed`` payload instead of producing its real
    output. These tests exercise the real output path, so they opt out of the
    gate explicitly rather than depending on a stray report.md being left behind
    by an earlier test or an earlier run. Pass ``no_confirm=False`` to
    deliberately exercise the gate. (``--no-confirm`` only bypasses that prompt;
    it has no other effect on filtering, batching or output.)

    ``encoding="utf-8"`` is explicit because the orchestrator emits UTF-8 and
    the Windows default (cp1252) cannot decode it.
    """
    cmd = [
        "uv", "run", "--",
        "python", "apply_suggestions_orchestrator.py",
        "--plan-file", str(TEST_PLAN_FILE),
        "--output-format", "json",
        *(["--no-confirm"] if no_confirm else []),
        *args
    ]
    return subprocess.run(
        cmd,
        cwd=str(SKILL_DIR),
        capture_output=True,
        text=True,
        encoding="utf-8",
    )


@pytest.fixture(autouse=True)
def setup_fixtures():
    """Give every test a clean, complete set of fixtures.

    Function-scoped (not module-scoped) so no test can observe files written by
    a previous test or by a previous run of the suite: tests pass from a clean
    tree, in any order, and when run twice in a row.
    """
    setup_test_fixtures(force=True)
    yield


class TestDryRunApproveAllLow:
    """Test dry-run with --approve-all-low option."""

    def test_dry_run_shows_what_would_be_approved(self):
        """Verify dry-run correctly reports LOW items that would be auto-approved."""
        result = run_orchestrator("--approve-all-low", "--dry-run")

        assert result.returncode == 0
        # Should show dry-run report
        assert "DRY RUN" in result.stderr or "DRY RUN" in result.stdout

    def test_dry_run_identifies_valid_suggestions(self):
        """Verify dry-run identifies valid suggestions to apply."""
        result = run_orchestrator("--dry-run")

        assert result.returncode == 0
        assert "Valid (to apply):" in result.stderr

    def test_dry_run_identifies_human_review_items(self):
        """Verify dry-run identifies items needing human review."""
        result = run_orchestrator("--dry-run")

        assert result.returncode == 0
        assert "Needs human review:" in result.stderr

    def test_dry_run_shows_batching_stats(self):
        """Verify dry-run shows batching efficiency stats."""
        result = run_orchestrator("--dry-run")

        assert result.returncode == 0
        assert "Batching results:" in result.stderr
        assert "Total suggestions:" in result.stderr
        assert "Total batches:" in result.stderr


class TestRevalidation:
    """Test revalidation options."""

    def test_revalidate_dry_run_identifies_failed_items(self):
        """Verify --revalidate --dry-run identifies validation_failed items."""
        result = run_orchestrator("--revalidate", "--dry-run")

        assert result.returncode == 0
        assert "REVALIDATION MODE" in result.stderr
        assert "Would revalidate" in result.stderr
        # Should identify 3 validation_failed items
        assert "parsing_error" in result.stderr
        assert "timeout" in result.stderr
        assert "rate_limited" in result.stderr

    def test_revalidate_counts_correct_items(self):
        """Verify correct number of items would be revalidated."""
        result = run_orchestrator("--revalidate", "--dry-run")

        assert result.returncode == 0
        # Should find 3 items (groups 5, 7, 8 with validation_failed status)
        assert "3 items" in result.stderr


class TestResume:
    """Test resume interrupted session functionality."""

    def test_resume_skips_processed_items(self):
        """Verify --resume skips already-processed items."""
        result = run_orchestrator("--resume", "--dry-run")

        assert result.returncode == 0
        # Should show 1 already processed (group 0 - email validation)
        assert "1 already processed" in result.stderr
        # Note: The resume count may be 9 or 10 depending on whether
        # user-edited descriptions change the group_id hash. When report.md
        # descriptions differ from grouped.json, the desc edit changes the
        # group_id, preventing the resume match for that group.
        assert "remaining" in result.stderr

    def test_resume_applies_previous_human_decisions(self):
        """Verify --resume applies previous human decisions."""
        # Run without resume first to get baseline
        baseline = run_orchestrator("--dry-run")

        # Run with resume
        resumed = run_orchestrator("--resume", "--dry-run")

        # Both should succeed
        assert baseline.returncode == 0
        assert resumed.returncode == 0

        # With resume, should have fewer items needing human review
        # (group 2 - account lockout was pre-approved)


class TestSkipAllHuman:
    """Test --skip-all-human option."""

    def test_skip_all_human_skips_human_review_items(self):
        """Verify --skip-all-human skips needs-human-decision items."""
        result = run_orchestrator("--skip-all-human", "--dry-run")

        assert result.returncode == 0
        # Should have 0 items in needs_human_review
        assert "Needs human review: 0" in result.stderr


class TestApproveValidationFailed:
    """Test --approve-validation-failed option."""

    def test_approve_validation_failed_auto_approves_recoverable(self):
        """Verify --approve-validation-failed auto-approves recoverable failures."""
        result = run_orchestrator("--approve-validation-failed", "--dry-run")

        assert result.returncode == 0
        # Should show auto-approval in dry-run report
        assert "would_auto_approve" in result.stdout or "Would auto-approve" in result.stderr


class TestApproveAll:
    """Test --approve-all option."""

    def test_approve_all_requires_confirmation(self):
        """Verify --approve-all requires --yes or --force."""
        result = run_orchestrator("--approve-all")

        # Should fail without --yes
        assert result.returncode != 0
        assert "requires --yes or --force" in result.stderr

    def test_approve_all_with_yes_succeeds(self):
        """Verify --approve-all --yes works (with --include-high for HIGH items)."""
        result = run_orchestrator("--approve-all", "--yes", "--include-high", "--dry-run")

        assert result.returncode == 0


class TestBatchingOptions:
    """Test batching-related options."""

    def test_no_batch_disables_batching(self):
        """Verify --no-batch processes suggestions individually."""
        result = run_orchestrator("--no-batch", "--output-format", "json")

        assert result.returncode == 0
        output = json.loads(result.stdout)
        # Check batching is disabled
        assert output["batching_stats"]["batching_enabled"] is False
        # Each batch should have exactly 1 suggestion
        for batch in output["batches"]:
            assert batch["suggestion_count"] == 1

    def test_max_batch_size_limits_batch(self):
        """Verify --max-batch-size limits suggestions per batch."""
        result = run_orchestrator("--max-batch-size", "2", "--dry-run")

        assert result.returncode == 0
        # Batches should have at most 2 suggestions


class TestFreshStart:
    """Test --fresh option."""

    def test_fresh_clears_previous_progress(self):
        """Verify --fresh clears previous state and starts fresh."""
        # First run with resume to verify state exists
        with_resume = run_orchestrator("--resume", "--dry-run")
        assert "1 already processed" in with_resume.stderr

        # Run with fresh
        fresh = run_orchestrator("--fresh", "--dry-run")
        assert fresh.returncode == 0
        assert "Fresh start requested" in fresh.stderr
        # No restore needed: the autouse setup_fixtures fixture rebuilds the
        # fixture tree from scratch before every test.


class TestOutputFormat:
    """Test output format options."""

    def test_json_output_is_valid(self):
        """Verify JSON output is valid JSON."""
        result = run_orchestrator("--output-format", "json")

        assert result.returncode == 0
        # stdout should be valid JSON
        output = json.loads(result.stdout)
        assert "plan_file" in output
        assert "batches" in output
        assert "summary" in output

    def test_json_output_contains_required_fields(self):
        """Verify JSON output contains all required fields."""
        result = run_orchestrator("--output-format", "json")

        output = json.loads(result.stdout)
        assert "plan_file" in output
        assert "prefix" in output
        assert "output_dir" in output
        assert "timestamp" in output
        assert "batches" in output
        assert "to_apply" in output
        assert "needs_human_review" in output
        assert "batching_stats" in output
        assert "human_review_config" in output
        assert "resume_info" in output
        assert "summary" in output

    def test_text_output_is_readable(self):
        """Verify text output is human-readable."""
        result = run_orchestrator("--output-format", "text")

        assert result.returncode == 0
        assert "SUGGESTIONS TO APPLY" in result.stdout


class TestApproveImportanceLevels:
    """Test --approve-importance option."""

    def test_approve_importance_single_level(self):
        """Verify --approve-importance with single level."""
        result = run_orchestrator("--approve-importance", "LOW", "--dry-run")

        assert result.returncode == 0

    def test_approve_importance_multiple_levels(self):
        """Verify --approve-importance with multiple levels."""
        result = run_orchestrator("--approve-importance", "LOW", "MEDIUM", "--dry-run")

        assert result.returncode == 0


class TestMinPriority:
    """Test --min-priority option."""

    def test_min_priority_low_includes_all(self):
        """Verify --min-priority low includes all valid suggestions."""
        result = run_orchestrator("--min-priority", "low", "--output-format", "json")

        assert result.returncode == 0
        output = json.loads(result.stdout)
        # With min_priority=low, all valid items should be included
        # Check that LOW importance items are in to_apply if they're valid
        valid_count = output["summary"]["valid_count"]
        assert valid_count > 0

    def test_min_priority_medium_skips_low(self):
        """Verify --min-priority medium skips LOW importance suggestions."""
        # Get baseline with low
        result_low = run_orchestrator("--min-priority", "low", "--output-format", "json")
        result_medium = run_orchestrator("--min-priority", "medium", "--output-format", "json")

        assert result_low.returncode == 0
        assert result_medium.returncode == 0

        output_low = json.loads(result_low.stdout)
        output_medium = json.loads(result_medium.stdout)

        # Medium should have fewer or equal valid items (LOW skipped)
        assert output_medium["summary"]["valid_count"] <= output_low["summary"]["valid_count"]
        # Medium should have more or equal skipped items
        assert output_medium["summary"]["skipped_count"] >= output_low["summary"]["skipped_count"]

    def test_min_priority_high_only_high(self):
        """Verify --min-priority high only includes HIGH importance suggestions."""
        result = run_orchestrator("--min-priority", "high", "--output-format", "json")

        assert result.returncode == 0
        output = json.loads(result.stdout)

        # All items in to_apply should be HIGH importance
        for item in output["to_apply"]:
            assert item["importance"] == "HIGH"

    def test_min_priority_default_is_low(self):
        """Verify default behavior (no --min-priority) is same as --min-priority low."""
        result_default = run_orchestrator("--output-format", "json")
        result_low = run_orchestrator("--min-priority", "low", "--output-format", "json")

        assert result_default.returncode == 0
        assert result_low.returncode == 0

        output_default = json.loads(result_default.stdout)
        output_low = json.loads(result_low.stdout)

        # Should have same counts
        assert output_default["summary"]["valid_count"] == output_low["summary"]["valid_count"]
        assert output_default["summary"]["skipped_count"] == output_low["summary"]["skipped_count"]

    def test_include_low_deprecated_still_works(self):
        """Verify deprecated --include-low still works but shows warning."""
        result = run_orchestrator("--include-low", "--output-format", "json")

        assert result.returncode == 0
        # Should show deprecation warning
        assert "deprecated" in result.stderr.lower() or "DEPRECATED" in result.stderr

    def test_include_low_and_min_priority_conflict(self):
        """Verify warning when both --include-low and --min-priority are used."""
        result = run_orchestrator("--include-low", "--min-priority", "medium")

        # Should succeed with warning (--min-priority takes precedence)
        assert "WARNING" in result.stderr
        assert "--min-priority" in result.stderr


class TestBatchReviewMode:
    """Test --batch-review-mode option."""

    def test_batch_review_mode_individual(self):
        """Verify --batch-review-mode individual."""
        result = run_orchestrator("--batch-review-mode", "individual", "--output-format", "json")

        assert result.returncode == 0
        output = json.loads(result.stdout)
        assert output["human_review_config"]["mode"] == "individual"
        assert output["human_review_config"]["batch_enabled"] is False

    def test_batch_review_mode_by_importance(self):
        """Verify --batch-review-mode by-importance (default)."""
        result = run_orchestrator("--batch-review-mode", "by-importance", "--output-format", "json")

        assert result.returncode == 0
        output = json.loads(result.stdout)
        assert output["human_review_config"]["mode"] == "by-importance"
        assert output["human_review_config"]["batch_enabled"] is True

    def test_batch_review_mode_summary_only(self):
        """Verify --batch-review-mode summary-only."""
        result = run_orchestrator("--batch-review-mode", "summary-only", "--output-format", "json")

        assert result.returncode == 0
        output = json.loads(result.stdout)
        assert output["human_review_config"]["mode"] == "summary-only"


class TestEdgeCases:
    """Test edge cases and error handling."""

    def test_nonexistent_plan_file(self):
        """Verify error on nonexistent plan file."""
        cmd = [
            "uv", "run", "--",
            "python", "apply_suggestions_orchestrator.py",
            "--plan-file", "nonexistent.md"
        ]
        result = subprocess.run(
            cmd, cwd=str(SKILL_DIR), capture_output=True, text=True, encoding="utf-8"
        )

        assert result.returncode != 0
        assert "not found" in result.stderr.lower()

    def test_missing_review_plan_dir(self, tmp_path):
        """Verify error when review-plan directory is missing."""
        # Create a plan file without review-plan directory
        plan_file = tmp_path / "test.md"
        plan_file.write_text("# Test Plan", encoding="utf-8")

        cmd = [
            "uv", "run", "--",
            "python", "apply_suggestions_orchestrator.py",
            "--plan-file", str(plan_file)
        ]
        result = subprocess.run(
            cmd, cwd=str(SKILL_DIR), capture_output=True, text=True, encoding="utf-8"
        )

        assert result.returncode != 0
        assert "not found" in result.stderr.lower() or "Run --review-plan first" in result.stderr


class TestUserSkipFunctionality:
    """Test user skip checkbox functionality in report.md."""

    def test_user_skip_filters_suggestions(self):
        """Verify user-marked [x] Skip suggestions are filtered out."""
        # Create a report.md with skip markers
        review_plan_dir = TEST_PLAN_DIR / "review-plan"
        report_content = '''# Review Report

## HIGH

### S001: Add email format validation
- [ ] Skip
**Validation:** ✓ Valid | **Model:** claude-sonnet | **Type:** addition | **Section:** Step 2

Description.

---

### S003: Implement account lockout
- [x] Skip
**Validation:** ✓ Valid | **Model:** claude-sonnet | **Type:** addition | **Section:** Step 6

Description.

---

## MEDIUM

### S002: Enforce password complexity
- [x] Skip
**Validation:** ✓ Valid | **Model:** gpt-4 | **Type:** addition | **Section:** Step 2

Description.

---
'''
        # encoding is explicit: the fixture contains non-ASCII (e.g. '✓'), which
        # the Windows default codec (cp1252) cannot encode.
        (review_plan_dir / "report.md").write_text(report_content, encoding="utf-8")

        result = run_orchestrator("--output-format", "json")

        assert result.returncode == 0
        # Should show user skipped message
        assert "User skipped" in result.stderr
        assert "S002" in result.stderr or "S003" in result.stderr

    def test_user_skip_with_dry_run(self):
        """Verify dry-run shows user skip filtering."""
        # Create a report.md with skip markers
        review_plan_dir = TEST_PLAN_DIR / "review-plan"
        report_content = '''# Review Report

## HIGH

### S001: Test suggestion
- [x] Skip
**Validation:** ✓ Valid | **Model:** test | **Type:** addition | **Section:** Step 1

Description.

---
'''
        # encoding is explicit: the fixture contains non-ASCII (e.g. '✓'), which
        # the Windows default codec (cp1252) cannot encode.
        (review_plan_dir / "report.md").write_text(report_content, encoding="utf-8")

        result = run_orchestrator("--dry-run")

        assert result.returncode == 0
        assert "User skipped" in result.stderr

    def test_no_report_file_works_normally(self):
        """Verify orchestrator works when report.md doesn't exist."""
        # Remove report.md if it exists
        review_plan_dir = TEST_PLAN_DIR / "review-plan"
        report_path = review_plan_dir / "report.md"
        if report_path.exists():
            report_path.unlink()

        result = run_orchestrator("--dry-run")

        # Should still work without report.md
        assert result.returncode == 0

    def test_empty_skip_checkboxes_filters_nothing(self):
        """Verify no filtering when all checkboxes are unchecked."""
        # Create a report.md without skip markers
        review_plan_dir = TEST_PLAN_DIR / "review-plan"
        report_content = '''# Review Report

## HIGH

### S001: Test suggestion
- [ ] Skip
**Validation:** ✓ Valid | **Model:** test | **Type:** addition | **Section:** Step 1

Description.

---

### S003: Another suggestion
- [ ] Skip
**Validation:** ✓ Valid | **Model:** test | **Type:** addition | **Section:** Step 6

Description.

---
'''
        # encoding is explicit: the fixture contains non-ASCII (e.g. '✓'), which
        # the Windows default codec (cp1252) cannot encode.
        (review_plan_dir / "report.md").write_text(report_content, encoding="utf-8")

        result = run_orchestrator("--output-format", "json")

        assert result.returncode == 0
        # Should NOT show user skipped message (no skips marked)
        assert "User skipped 0" not in result.stderr or "User skipped" not in result.stderr


class TestGroupBasedSkipping:
    """Test group-based skip functionality (G{n} groups and G{n}S{m} suggestions)."""

    def test_skip_entire_group_removes_all_suggestions(self):
        """Marking group as skipped removes all its suggestions."""
        review_plan_dir = TEST_PLAN_DIR / "review-plan"
        report_content = '''# Review Report

## G1: Error handling improvements
- [x] Skip this group

### G1S1: Add try/catch block
- [ ] Skip
**Validation:** ✓ Valid | **Model:** claude-sonnet | **Type:** addition | **Section:** Step 2

Description.

---

### G1S2: Add logging
- [ ] Skip
**Validation:** ✓ Valid | **Model:** claude-sonnet | **Type:** addition | **Section:** Step 2

Description.

---

## G2: Security improvements
- [ ] Skip this group

### G2S1: Add validation
- [ ] Skip
**Validation:** ✓ Valid | **Model:** gpt-4 | **Type:** addition | **Section:** Step 3

Description.

---
'''
        # encoding is explicit: the fixture contains non-ASCII (e.g. '✓'), which
        # the Windows default codec (cp1252) cannot encode.
        (review_plan_dir / "report.md").write_text(report_content, encoding="utf-8")

        result = run_orchestrator("--output-format", "json")

        assert result.returncode == 0
        assert "User skipped 1 groups" in result.stderr

    def test_skip_individual_suggestion_keeps_others(self):
        """Skipping an individual suggestion via bracket-notation hash."""
        review_plan_dir = TEST_PLAN_DIR / "review-plan"
        # Use v2 bracket-notation with the actual suggestion hash for
        # G2S1 ("Enforce password complexity") = 364825472afa4119
        # from the test fixture's grouped.json.
        report_content = '''# Review Report

## G1 [37cb243b0635c1ed]: Add input validation for email
- [ ] Skip this group

### G1S1 [8bcf94998a487ed7]: Add email format validation
- [ ] Skip
**Validation:** ✓ Valid | **Model:** claude-sonnet | **Type:** addition | **Section:** Step 2

Description.

---

## G2 [1440c45af71cc3a1]: Add password complexity requirements
- [ ] Skip this group

### G2S1 [364825472afa4119]: Enforce password complexity
- [x] Skip
**Validation:** ✓ Valid | **Model:** gpt-4 | **Type:** addition | **Section:** Step 2

Description.

---
'''
        # encoding is explicit: the fixture contains non-ASCII (e.g. '✓'), which
        # the Windows default codec (cp1252) cannot encode.
        (review_plan_dir / "report.md").write_text(report_content, encoding="utf-8")

        result = run_orchestrator("--output-format", "json")

        assert result.returncode == 0
        assert "User skipped 1 individual suggestions" in result.stderr
        assert "364825472afa4119" in result.stderr

    def test_mixed_group_and_individual_skips(self):
        """Skip G1 entirely, skip G2S1 individually using bracket-notation hashes."""
        review_plan_dir = TEST_PLAN_DIR / "review-plan"
        # Use v2 bracket-notation with actual hashes from the test fixture.
        # G1 = 37cb243b0635c1ed ("Add input validation for email")
        # G2S1 = 364825472afa4119 ("Enforce password complexity")
        report_content = '''# Review Report

## G1 [37cb243b0635c1ed]: Add input validation for email
- [x] Skip this group

### G1S1 [8bcf94998a487ed7]: Add email format validation
- [ ] Skip
**Validation:** ✓ Valid

---

## G2 [1440c45af71cc3a1]: Add password complexity requirements
- [ ] Skip this group

### G2S1 [364825472afa4119]: Enforce password complexity
- [x] Skip
**Validation:** ✓ Valid

---
'''
        # encoding is explicit: the fixture contains non-ASCII (e.g. '✓'), which
        # the Windows default codec (cp1252) cannot encode.
        (review_plan_dir / "report.md").write_text(report_content, encoding="utf-8")

        result = run_orchestrator("--output-format", "json")

        assert result.returncode == 0
        assert "User skipped 1 groups" in result.stderr
        assert "User skipped 1 individual suggestions" in result.stderr
        assert "364825472afa4119" in result.stderr

    def test_backward_compatibility_old_format(self):
        """Old S001 format still works."""
        review_plan_dir = TEST_PLAN_DIR / "review-plan"
        # Use old format with S### IDs
        report_content = '''# Review Report

## HIGH

### S001: Add error handling
- [ ] Skip
**Validation:** ✓ Valid | **Model:** claude-sonnet | **Type:** addition | **Section:** Step 3

Description.

---

### S002: Add validation
- [x] Skip
**Validation:** ✓ Valid | **Model:** gpt-4 | **Type:** addition | **Section:** Step 2

Description.

---
'''
        # encoding is explicit: the fixture contains non-ASCII (e.g. '✓'), which
        # the Windows default codec (cp1252) cannot encode.
        (review_plan_dir / "report.md").write_text(report_content, encoding="utf-8")

        result = run_orchestrator("--output-format", "json")

        assert result.returncode == 0
        # Should show old format skipped
        assert "old format" in result.stderr.lower() or "S002" in result.stderr


class TestReportFormat:
    """Test the new report format with skip checkboxes and explicit validation."""

    def test_report_contains_skip_checkbox_placeholder(self):
        """Verify a generated report carries skip checkboxes and a validation line.

        The report is generated here from the production formatter over this
        module's fixture groups, rather than read from whatever report.md a
        previous test happened to leave in plans/test-plan/ — that made the
        assertions silently vanish on a clean tree.
        """
        from utils.review_orchestrator_base import format_group

        lines: list = []
        for idx, group in enumerate(TestFixtures.GROUPED_SUGGESTIONS, 1):
            lines.extend(format_group(copy.deepcopy(group), idx))
        content = "\n".join(lines)

        # Round-trip through disk with an explicit encoding: the report contains
        # non-ASCII and must survive a write/read on any platform.
        report_path = TEST_PLAN_DIR / "review-plan" / "report.md"
        report_path.write_text(content, encoding="utf-8")
        content = report_path.read_text(encoding="utf-8")

        # New format: per-group and per-suggestion skip checkboxes, plus an
        # explicit validation line (old format put badges in the title instead).
        assert "- [ ] Skip this group" in content
        assert "- [ ] Skip" in content
        assert "**Validation:**" in content
        # Suggestions are addressed as G{n}S{m}, not the legacy S### ids.
        assert "### G1S1:" in content


class TestPerSuggestionOverrides:
    """Test the REAL per-suggestion validation override code path.

    These tests instantiate ``ApplySuggestionsOrchestrator`` and call the
    production ``apply_suggestion_validation_overrides()`` directly (rather than
    a stale, duplicated helper). This ensures they exercise the actual logic,
    including ``judge_decide`` marker handling and group-level propagation.
    """

    @staticmethod
    def _run_overrides(groups, suggestion_overrides):
        """Apply per-suggestion overrides via the real orchestrator method.

        Returns the mutated ``self.merged`` and the orchestrator instance so
        callers can also assert on ``judge_decide_overrides`` etc.
        """
        from apply_suggestions_orchestrator import ApplySuggestionsOrchestrator

        orch = ApplySuggestionsOrchestrator.__new__(ApplySuggestionsOrchestrator)
        orch.merged = copy.deepcopy(groups)
        orch.suggestion_validation_overrides = dict(suggestion_overrides)
        orch.judge_decide_overrides = set()
        orch.apply_suggestion_validation_overrides()
        return orch.merged, orch

    def test_suggestion_override_invalid_removes_suggestion(self):
        """Override G1S2 as invalid removes it from the group, keeps others."""
        groups = [
            {
                "theme": "Error handling",
                "validation_status": "valid",
                "suggestions": [
                    {"title": "Add try/catch", "desc": "Add error handling"},
                    {"title": "Add logging", "desc": "Add debug logging"},
                    {"title": "Add retry", "desc": "Add retry logic"},
                ],
            }
        ]
        overrides = {"G1S2": "invalid"}
        result, _ = self._run_overrides(groups, overrides)

        # G1S2 (Add logging) should be removed
        assert len(result[0]["suggestions"]) == 2
        remaining_titles = [s["title"] for s in result[0]["suggestions"]]
        assert "Add try/catch" in remaining_titles
        assert "Add retry" in remaining_titles
        assert "Add logging" not in remaining_titles

    def test_suggestion_override_valid_promotes_group(self):
        """Mark all suggestions in a needs-human-decision group as valid, group becomes valid."""
        groups = [
            {
                "theme": "Security fix",
                "validation_status": "needs-human-decision",
                "validation_reason": "Ambiguous lockout policy",
                "suggestions": [
                    {"title": "Add rate limiting", "desc": "Limit login attempts"},
                    {"title": "Add lockout", "desc": "Lock after failures"},
                ],
            }
        ]
        overrides = {"G1S1": "valid", "G1S2": "valid"}
        result, _ = self._run_overrides(groups, overrides)

        # Group should be promoted to valid
        assert result[0]["validation_status"] == "valid"
        assert "All suggestions individually marked valid" in result[0]["validation_reason"]
        assert result[0]["user_override"] is True
        # Both suggestions should still be present
        assert len(result[0]["suggestions"]) == 2

    def test_suggestion_override_partial_no_group_promotion(self):
        """Mark only some suggestions valid, group status unchanged."""
        groups = [
            {
                "theme": "Performance",
                "validation_status": "needs-human-decision",
                "validation_reason": "Unclear caching strategy",
                "suggestions": [
                    {"title": "Add caching", "desc": "Cache responses"},
                    {"title": "Add pooling", "desc": "Pool connections"},
                    {"title": "Add indexing", "desc": "Add DB indexes"},
                ],
            }
        ]
        # Only mark first suggestion valid, leave others untouched
        overrides = {"G1S1": "valid"}
        result, _ = self._run_overrides(groups, overrides)

        # Group should NOT be promoted (not all suggestions marked valid)
        assert result[0]["validation_status"] == "needs-human-decision"
        assert result[0]["validation_reason"] == "Unclear caching strategy"
        assert "user_override" not in result[0]
        # All 3 suggestions should still be present
        assert len(result[0]["suggestions"]) == 3

    def test_suggestion_override_judge_decide_propagates_to_group(self):
        """A judge_decide marker on one suggestion routes the whole group to the judge."""
        groups = [
            {
                "group_hash": "g_judge_decide",
                "theme": "Refactor",
                "validation_status": "needs-human-decision",
                "validation_reason": "Unclear blast radius",
                "suggestions": [
                    {"title": "Extract helper", "desc": "Pull out shared logic"},
                    {"title": "Rename module", "desc": "Clarify naming"},
                ],
            }
        ]
        # Mark only the first suggestion judge_decide.
        overrides = {"G1S1": "judge_decide"}
        result, orch = self._run_overrides(groups, overrides)

        group = result[0]
        # The marked suggestion is kept (not dropped) and tagged.
        assert len(group["suggestions"]) == 2
        assert group["suggestions"][0]["judge_decide"] is True
        # The group is routed to the judge: marker propagated up and registered.
        assert group["judge_decide"] is True
        assert "g_judge_decide" in orch.judge_decide_overrides
        # Status is NOT promoted to valid (judge_decide must win).
        assert group["validation_status"] == "needs-human-decision"
        assert "user_override" not in group

    def test_suggestion_override_judge_decide_wins_over_valid(self):
        """judge_decide must block group promotion even if survivors are all 'valid'."""
        groups = [
            {
                "group_hash": "g_mixed",
                "theme": "Mixed",
                "validation_status": "needs-human-decision",
                "validation_reason": "Needs review",
                "suggestions": [
                    {"title": "Tighten validation", "desc": "Stricter checks"},
                    {"title": "Add audit log", "desc": "Record changes"},
                ],
            }
        ]
        # One marked valid, the other judge_decide. judge_decide must win:
        # the group should route to the judge, NOT be promoted to valid.
        overrides = {"G1S1": "valid", "G1S2": "judge_decide"}
        result, orch = self._run_overrides(groups, overrides)

        group = result[0]
        assert group["validation_status"] == "needs-human-decision"
        assert "user_override" not in group
        assert group["judge_decide"] is True
        assert "g_mixed" in orch.judge_decide_overrides


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--setup-fixtures", action="store_true",
                        help="Set up test fixtures without running tests")
    args = parser.parse_args()

    if args.setup_fixtures:
        print("Setting up test fixtures...")
        setup_test_fixtures(force=True)
        print(f"Fixtures created in {TEST_PLAN_DIR}")
    else:
        # Run with pytest
        pytest.main([__file__, "-v"])


# ---------------------------------------------------------------------------
# format_item_for_output — group_id + judge_decide routing flag
# ---------------------------------------------------------------------------

from apply_suggestions_orchestrator import ApplySuggestionsOrchestrator  # noqa: E402
import argparse as _argparse  # noqa: E402


class TestFormatItemClaudeDecide:
    """ApplySuggestionsOrchestrator.format_item_for_output routing fields."""

    def _make_orchestrator(self):
        orch = ApplySuggestionsOrchestrator.__new__(ApplySuggestionsOrchestrator)
        orch.args = _argparse.Namespace(plan_file="p.md")
        return orch

    def _group(self, **extra):
        g = {
            "group_hash": "sugg_g_hash",
            "theme": "Theme",
            "validation_status": "needs-human-decision",
            "suggestions": [{"title": "T", "desc": "d"}],
        }
        g.update(extra)
        return g

    def test_group_id_on_every_item(self):
        orch = self._make_orchestrator()
        result = orch.format_item_for_output(self._group(), 0)
        assert result["group_id"] == "sugg_g_hash"
        assert "decision_mode" not in result

    def test_decision_mode_for_marked_group(self):
        orch = self._make_orchestrator()
        result = orch.format_item_for_output(self._group(judge_decide=True), 0)
        assert result["group_id"] == "sugg_g_hash"
        assert result["decision_mode"] == "judge_auto_decide"


class TestOrchestratorOutputClaudeDecideShape:
    """The serialized orchestrator_output.json carries the new routing fields."""

    def _orch(self, tmp_path):
        orch = ApplySuggestionsOrchestrator.__new__(ApplySuggestionsOrchestrator)
        orch.args = _argparse.Namespace(
            plan_file="p.md", batch_review_mode="by-importance", agent_decide=False
        )
        orch.out_dir = str(tmp_path)
        orch.plan_path = "p.md"
        orch.prefix = "feat"
        orch.formatted_valid = []
        orch.formatted_skipped = []
        orch.user_skipped_items = []
        orch.skipped = []
        orch.valid = []
        orch.needs_human = []
        orch.merged = []
        orch.groups = []
        orch.batching_stats = {}
        orch.edit_log = []
        return orch

    def test_written_output_has_group_id_and_decision_mode(self, tmp_path):
        orch = self._orch(tmp_path)
        marked = orch.format_item_for_output(
            {"group_hash": "h_marked", "theme": "M",
             "validation_status": "needs-human-decision",
             "judge_decide": True,
             "suggestions": [{"title": "A", "desc": "a", "importance": "HIGH"}]},
            0,
        )
        plain = orch.format_item_for_output(
            {"group_hash": "h_plain", "theme": "P",
             "validation_status": "needs-human-decision",
             "suggestions": [{"title": "B", "desc": "b", "importance": "MEDIUM"}]},
            1,
        )
        orch.formatted_human = [marked, plain]

        output = orch.build_output_json([])
        # Serialize to disk and read back to assert the on-disk shape.
        out_path = tmp_path / "orchestrator_output.json"
        out_path.write_text(json.dumps(output), encoding="utf-8")
        on_disk = json.loads(out_path.read_text(encoding="utf-8"))

        nhr = on_disk["needs_human_review"]
        # Every human-review item carries group_id == source group_hash.
        assert {it["group_id"] for it in nhr} == {"h_marked", "h_plain"}
        # Only the marked item carries the per-item routing flag.
        marked_items = [it for it in nhr if it.get("decision_mode") == "judge_auto_decide"]
        assert len(marked_items) == 1
        assert marked_items[0]["group_id"] == "h_marked"

        cfg = on_disk["human_review_config"]
        assert cfg["judge_decide_item_ids"] == ["h_marked"]
        # Per-item routing does not flip the global mode.
        assert cfg["decision_mode"] == "interactive"


class TestTheNativeEmitMaterializesTheWriteTaskFile:
    """The native leg writes `{phase}/write_tasks.json` — the executor's own
    task file — so `util write-prompt` can bind each batch's prompt from the
    same seam the executor dispatches from (2026-10-05)."""

    def test_write_tasks_json_exists_and_each_batch_renders(self):
        from utils import write_prompt
        from utils.write_phase_bridge import WRITE_TASK_FILENAME

        result = run_orchestrator("--approve-all", "--yes", "--include-high")
        assert result.returncode == 0, result.stderr[-800:]
        phase_dir = TEST_PLAN_DIR / "apply-suggestions"
        assert f"[WRITE_TASKS_FILE] {phase_dir / WRITE_TASK_FILENAME}" in result.stderr
        document = json.loads((phase_dir / WRITE_TASK_FILENAME).read_text(encoding="utf-8"))
        output = json.loads((phase_dir / "orchestrator_output.json").read_text(encoding="utf-8"))
        assert document["kind"] == "apply_suggestions"
        assert len(document["batches"]) == len(output["batches"]) > 0
        # Same batches, same order, same prior-changes ids as the host appends under.
        assert [t["prior_changes_id"] for t in document["batches"]] == [
            b["prior_changes_id"] for b in output["batches"]
        ]
        for task in document["batches"]:
            text, _task, _info = write_prompt.render_write_prompt(phase_dir, task["task_id"])
            assert "{prior_changes_context}" not in text
            assert "## Result (required" in text
