---
name: copilot-cli
description: Use GitHub Copilot CLI as a subagent. Lets the main agent prompt GitHub Copilot CLI from the terminal in headless mode with the `copilot` command, and send the goal, the decisions and the scope with the task. Use when the user asks to delegate work to GitHub Copilot CLI, when a task needs a second independent agent, or when a plan needs a fresh perspective.
allowed-tools:
  - Bash
  - Read
  - Write
  - Grep
  - Glob
---

# GitHub Copilot CLI (subagent / task delegation)

<!-- =============================================================================
     GLOBAL HALF — sections 1 to 5.
     These sections are identical in every skill in this repository.
     Copy them without any change. Do not put a vendor name or a flag in them.
     A change here must be made in all skills at the same time.
     ============================================================================= -->

## What is it

This skill teaches your agent to use an agent from another vendor as a subagent.

Almost every coding agent has a headless mode. Headless mode runs the agent from the terminal with
one command and returns the answer to stdout. This skill gives the command pattern for one such
agent, and the protocol to transfer enough context with the task.

You stay the main agent. You keep the plan, the decisions and the conversation with the user. The
subagent does one bounded task and reports back.

## When to delegate

- **The user asks for it.** The user names another agent, or asks for a second opinion.
- **Large or multi-step work.** The task covers several files, phases or checkpoints.
- **Code review with a fresh mind.** Another agent reviews the work with a different lens and no
  memory of the decisions that produced it.
- **Planning that needs different ideas.** A second agent proposes options that you did not consider.
- **An internal council.** Several subagents answer the same question, and you compare the answers.
- **Deep research.** The other CLI has web search, web extraction or browser automation.
- **Background investigation.** A long task runs in the background while you continue in the
  foreground.

## When not to delegate

- **Small or single-step tasks.** One or two edits, or a short explanation, are faster in this thread.
- **Tight feedback loops.** The user wants quick back-and-forth in one conversation.
- **Secrets or policy-sensitive work.** Do not pipe credentials into a subagent. Redact first.
- **Context you already hold.** Repeating the whole plan in a prompt adds no value.
- **Low return on investment.** If writing the handoff costs more than doing the edit, do the edit.
- **Work that needs high precision and full judgement.** A subagent without your context will break a
  task that depends on a detail only this session knows.

## Delegation and context transfer protocol

An isolated subagent saves tokens, but it splits the story. The subagent does not see this
conversation. It has no memory of the goal you agreed with the user, the decisions you already made,
or the paths you agreed not to touch. A poor handoff causes misread tasks, wrong assumptions about
the stack or the style, and wasted edits.

Treat every call as **stateless delegation**: the subagent keeps nothing between calls, so each
command must carry its own state. A good handoff happens when you keep these practices in mind:

- **Shared state handoff.** The prompt carries the original goal, the decisions already made, and the
  explicit scope, to bridge the subagent's missing session history.
- **Contextual preservation.** The high-volume work stays in the isolated process, so the bulk never
  enters this conversation and no "split story" forms from missing history.
- **Result reconciliation.** What comes back is folded into this thread afterwards, so there is a
  single source of truth.

Write the prompt as a transfer of shared state, not as a title. Include all six fields:

| Include | Why |
|---|---|
| **Goal** | The same objective as the user, not only the immediate micro-task. |
| **Decisions** | Framework, patterns, naming, "use X not Y" — anything that would otherwise be guessed wrong. |
| **Scope** | The absolute paths and modules to touch, and the areas to leave alone. A relative path may not resolve where you expect. |
| **Constraints** | Performance, accessibility, compatibility, review gates, "no new dependencies". |
| **Verification** | The exact command the subagent must run and pass before it returns. |
| **Output** | For example: "report only, no edits", "apply edits with a minimal diff", "list the files changed". |

Prefer sequential delegations with explicit carry-over. Parallel runs diverge unless every run gets
the same briefing.

**Run the subagent in the mode that does the work without asking for approval.** Headless mode has
nobody to answer a permission prompt. Any mode that stops to ask will stall, or return an empty
answer with a success exit code. Each CLI names this mode differently — take the flag from the vendor
card below.

**Never call a subagent in plan mode.** Many CLIs have a plan or read-only mode. That mode makes the
other agent write a plan *for itself*, which is not what you asked for: you want its work or its
answer, and you keep the planning. Plan mode also waits for someone to approve that plan, so the run
comes back with nothing. If you want no file changes, keep the auto-approving mode and write "report
only, no edits" in the **Output** field. Do not use plan mode to make a run read-only.

After the subagent returns:

- **Report to the user.** Give a short summary. Do not paste long logs unless the user asks.
- **Reconcile the context.** Record the decisions it made, the files it changed, and the open risks,
  so this session stays the single source of truth.

## CLI failure modes

Every vendor has its own terminal rules. A headless run fails quietly more often than it fails
loudly.

- **Wrap the call in an external timeout.** A headless CLI can stall before its own timeout starts.
- **Exit code 0 is not success.** If stdout is empty, treat the run as failed and read stderr. A
  permission the CLI could not ask for, and a prompt that never arrived, both look like success.
- **Never carry a flag habit from one CLI to another.** The same short flag means different things in
  different tools. In OpenCode, `-p` is `--password`: passing a prompt to it empties the message and
  the run waits on stdin forever. Confirm every flag against the CLI's own `--help`.
- **An unrecognized-flag error means this skill is stale, not that the task is impossible.** Read
  `--help`, continue with the flags that exist, and tell the user which line in this file is wrong.

<!-- =============================================================================
     VENDOR HALF — section 6.
     Everything below is specific to this CLI.
     Keep all seven sub-headings, in this order, even if the answer is "none".
     Take every flag from the installed binary (`<cli> --help`), not from memory
     and not from another skill in this repository.
     ============================================================================= -->

## Vendor card

### Binary and prompt form

- **Binary:** `copilot`
- **Prompt form:** **flag.** The prompt is the value of `-p` / `--prompt`, e.g.
  `copilot -p "prompt text"` — "execute a prompt in non-interactive mode; the CLI runs the prompt
  and exits when done." A bare `copilot` with no `-p` opens the interactive interface and never
  returns. Piped stdin also works: `echo "Fix this bug" | copilot -p`.

### Headless and output flags

| Need | Flag |
|---|---|
| Run once and exit | `-p`, `--prompt <PROMPT>` |
| Output only the agent's response, no decorations/stats | `-s` |
| Output format | `--output-format=text` or `json` (JSONL, one object per line) |
| Attach a file to the initial prompt | `--attachment <path>` (images or native documents) |
| Export the session transcript to Markdown | `--share [path]` |

### Approvals and permissions

- **`--allow-all`** (alias **`--yolo`**) — grants all permissions (tools and URL fetches).
- **`--allow-all-tools`** — narrower: allows every *tool* to run without per-call confirmation, but
  does not by itself grant URL access.
- **`--allow-tool=<TOOL>`**, **`--allow-url=<URL>`** — grant only specific tools/URLs; the official
  docs recommend this narrower form over `--allow-all` outside a sandbox.
- **`--deny-tool=<TOOL>`**, **`--deny-url=<URL>`** — explicit denials.
- **What happens with nobody to answer:** not explicitly documented for the case where a call falls
  outside every allow flag in headless mode. Do not rely on a graceful denial — pass `--allow-all`
  (or the precise `--allow-tool`/`--allow-url` set the task needs) before running headless so the
  question never comes up.

### Models and how to list them

No CLI subcommand or flag to print the model catalog is documented. The official docs say: "to see
the model strings for all available models, run the `/model` command in an interactive Copilot CLI
session" — there is no headless-only way to list them. Copilot is a **multi-provider gateway**, so
availability varies by plan, org policy, and region. Select with `--model=<identifier>`; pick a
custom agent with `--agent=<AGENT>`.

If the user names a model, use it. Otherwise start an interactive session once to run `/model` and
capture the current identifiers, and check [Artificial Analysis](https://artificialanalysis.ai/) for
capability and price comparisons — default to the cheapest suitable tier.

### Command pattern

```bash
copilot -p "GOAL: [goal] | DECISIONS: [decisions] | SCOPE: [paths, @ FILENAME as needed] | CONSTRAINTS: [constraints] | VERIFICATION: [test_command] | OUTPUT: [format]" \
  --allow-all -s --model=<identifier> 2>&1
```

With a specific custom agent:

```bash
copilot -p "[task]" --agent=<agent-name> --allow-all -s 2>&1
```

### Prompt examples

- **Implement:** `copilot -p "GOAL: [goal] | DECISIONS: [decisions] | SCOPE: [paths] | CONSTRAINTS: [constraints] | VERIFICATION: [test_command] | OUTPUT: [format]" --allow-all -s`
- **Investigate:** `copilot -p "GOAL: Map how [feature] works | SCOPE: [paths] | CONSTRAINTS: report only, no edits | OUTPUT: concise file:line map" --allow-tool=read --allow-tool=grep -s`
- **Audit:** `copilot -p "GOAL: Audit the codebase for security issues | SCOPE: [paths] | CONSTRAINTS: report only, no edits | OUTPUT: security report" --allow-all -s`

### Docs and reference

- Flags, JSON output, delegation checklist: [reference.md](reference.md)
- Vendor documentation:
  <https://docs.github.com/en/copilot/reference/copilot-cli-reference/cli-programmatic-reference>
  and <https://docs.github.com/copilot/concepts/agents/about-copilot-cli>
- **Checked against the official GitHub documentation on 2026-09-19. Not run against an installed
  binary — confirm with `copilot --help` before trusting a flag.** Note: the previous version of
  this card used `--yolo` and `--allow-all-tools` together as if they were both required; the
  official docs treat `--allow-all` (aliased `--yolo`) as the single broad grant, with
  `--allow-all-tools` as a narrower tools-only variant.
