---
name: first-50-users
description: "Get the first 50 real users through channels the user's ICP already uses. Use when the product shipped and nobody came, the user is \"posting more\" with no result, or is reaching for paid ads before product-market fit."
---

# Your first 50 users

> You don't get your first 50 users by posting more. You get them by going where your users *already* discover tools, and, at the start, by doing things that don't scale.

**Use this when:** you launched to silence, you're spraying every channel hoping one works, or you're about to buy ads to fix a problem ads can't fix.

## The core idea

Every developer audience has an existing **technology-discovery loop**: the specific places they already go to find new tools. Your job isn't to invent demand; it's to position yourself *inside that loop*. And your first cohort is hand-to-hand: the TAB members from `talk-to-users` are your first users.

## Framework: the top of the DREAM funnel (Frankl)

- **Discovery**: be where developers look: the communities, newsletters, influencers, and searches your ICP already uses. Metric: unique humans, not pageviews.
- **Research**: give the interested dev a next step *before they forget you*: newsletter, Discord, free tier, docs. Developers can sit in Research for months, so sustain the relationship.

Then **Evaluation** decides everything (see `know-if-its-working`): can a new dev get value **over a weekend, from docs and Stack Overflow, with no support call?** If not, more traffic just fills a leaky bucket.

## Framework: channels by stage (Czakon)

**Pre-PMF (you are here for the first 50):** unscalable, direct, high-touch.
- The people who posted about the problem (HN/Reddit/GitHub issues/X), DM them, personally.
- Your TAB → convert to design partners / first users.
- Founder posting *genuinely useful* things where the ICP hangs out (not "we launched!").
- One deep launch (see `launch-it`), not ten shallow ones.

**Post-PMF (later):** content/SEO, community, dev-influencer partnerships, then paid to *amplify* what already converts, never to *discover* it. And once the first 50 are in and retention holds, the hand-to-hand work graduates: build the self-reinforcing engine in `growth-loops`.

## How to pick the channel (don't do all of them)

You should already have two sources: the ranked watering holes in `docs/gtm-cofounder/market-research.md` (from `research-the-market`), and what real users told you in `talk-to-users` question 7 ("where do you go to stay current?"). Where they agree, that's your channel. Where they disagree, trust the users. If there's no research file yet, or it's more than a quarter old, run `research-the-market` first: picking channels from memory is how you end up "posting more" in rooms your ICP isn't in.

Rank channels by **where your specific ICP is**, and go deep on **one** before adding a second. Always by name: a specific subreddit, Discord, newsletter, or GitHub issue thread, never "Reddit" or "communities".

```
Is your ICP concentrated somewhere specific (a subreddit, a Discord, a conference, a tag)?
├─ YES → go all-in there first. Depth beats spread at 0→50.
└─ NO  → your ICP may be too broad → tighten it in `who-is-this-for`.
```

## Mistakes that look reasonable

- **"Post more"**: volume without a channel thesis is noise.
- **Paid ads pre-PMF**: you'll pay to accelerate a message that doesn't convert yet.
- **Building a community at 5 users**: a Discord with 3 lurkers is a graveyard that signals "dead." Wait for real traction.
- **Optimizing acquisition over a leaky bucket**: if week-2 retention is near zero, fix Evaluation/Activation first.
- **Launching ten times, shallow**: one well-prepared launch > ten "we shipped X" tweets.

## Your next 30 minutes

- [ ] Write down the 3 exact places your ICP discovers tools, by name and link (from `market-research.md`, checked against `talk-to-users` Q7).
- [ ] List 20 people who publicly posted about your problem (start from "the problem in their words" in `market-research.md`). DM 5 today, helpful, not pitchy.
- [ ] Turn your best 5 TAB members into your first 5 users this week.
- [ ] Confirm a new user can hit first value **in under an hour**. If not, that's the real priority.

---
Built from real dev-tool GTM experience, with frameworks from Adam Frankl (*The Developer-Facing Startup*) and Jakub Czakon (*markepear.dev*).
If the first users aren't coming and you're out of channels to try, reach out to me on [LinkedIn](https://www.linkedin.com/in/devtoolgtm/).
