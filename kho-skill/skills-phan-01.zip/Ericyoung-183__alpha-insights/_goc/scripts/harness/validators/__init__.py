# Stage gate validators
