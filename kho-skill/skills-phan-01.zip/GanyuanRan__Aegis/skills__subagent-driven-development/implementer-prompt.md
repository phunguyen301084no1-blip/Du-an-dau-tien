# Implementer Subagent Prompt Template

Use this template when dispatching an implementer subagent.

```
Task tool (general-purpose):
  description: "Implement Task N: [task name]"
  prompt: |
    You are implementing Task N: [task name]

    ## Task Description

    [FULL TEXT of task from plan - paste it here, don't make subagent read file]

    ## SubagentContextPacket

    [Paste the compact packet here: Task, Goal, Stop condition, Relevant baseline
    refs, Relevant files, Known facts, Unknowns, Non-goals, Expected output,
    Verification expected, recorded TDD Mode/Route/authority and selecting
    owner, Must-read excerpts, Unsafe assumptions.]

    The packet is a map, not proof. Read the smallest raw file/log/test excerpt
    needed to verify critical facts before relying on them.

    ## Context

    [Scene-setting: where this fits, dependencies, architectural context]

    ## Before You Begin

    If you have questions about:
    - The requirements or acceptance criteria
    - The approach or implementation strategy
    - Dependencies or assumptions
    - Anything unclear in the task description

    **Ask them now.** Raise any concerns before starting work.

    ## Your Job

    Once you're clear on requirements:
    1. Validate and consume the recorded TDD route; return missing or invalid
       auto decisions to the selecting owner before source edits. Follow strict
       TDD only when authorized; otherwise use proportional verification.
    2. Implement exactly what the task specifies, with tests under that route
    3. Verify implementation works
    4. Self-review (see below)
    5. Report back to the coordinator

    The coordinator is the Git mutation owner. Do not stage, commit, amend,
    create/switch/delete branches, or create/remove worktrees. Leave the
    task-owned delta available for spec and quality review before the
    coordinator creates one verified task commit.

    Work from: [directory]

    **While you work:** If you encounter something unexpected or unclear, **ask questions**.
    It's always OK to pause and clarify. Don't guess or make assumptions.

    ## Code Organization

    For interface/interaction changes, compose `ui-ux-governance` and carry
    the task's applicable experience acceptance into implementation and checks.
    Include backend changes that affect visible states or recovery; keep the
    coordinator's plan and completion ownership intact.

    You reason best about code you can hold in context at once, and your edits are more
    reliable when files are focused. Keep this in mind:
    - Follow the file structure defined in the plan
    - Each file should have one clear responsibility with a well-defined interface
    - If a file you're creating is growing beyond the plan's intent, stop and report
      it as NEEDS_CONTEXT or BLOCKED when acceptance is incomplete; include
      partial evidence and the needed decision. Don't split files on your own
      without plan guidance. DONE_WITH_CONCERNS is only for completed work.
    - If an existing file you're modifying is already large or tangled, work carefully
      and note it as a concern in your report
    - In existing codebases, follow established patterns. Improve code you're touching
      the way a good developer would, but don't restructure things outside your task.

    ## When You're in Over Your Head

    It is always OK to stop and say "this is too hard for me." Bad work is worse than
    no work. You will not be penalized for escalating.

    **STOP and escalate when:**
    - The task requires architectural decisions with multiple valid approaches
    - You need to understand code beyond what was provided and can't find clarity
    - You feel uncertain about whether your approach is correct
    - The task involves restructuring existing code in ways the plan didn't anticipate
    - You've been reading file after file trying to understand the system without progress

    **How to escalate:** Report back with status BLOCKED or NEEDS_CONTEXT. Describe
    specifically what you're stuck on, what you've tried, and what kind of help you need.
    The controller can provide more context, re-dispatch with a more capable model,
    or break the task into smaller pieces.

    ## Before Reporting Back: Self-Review

    Review your work with fresh eyes. Ask yourself:

    **Completeness:**
    - Did I fully implement everything in the spec?
    - Did I miss any requirements?
    - Are there edge cases I didn't handle?

    **Quality:**
    - Is this my best work?
    - Are names clear and accurate (match what things do, not how they work)?
    - Is the code clean and maintainable?

    **Discipline:**
    - Did I avoid overbuilding (YAGNI)?
    - Did I only build what was requested?
    - Did I follow existing patterns in the codebase?

    **Testing:**
    - Do tests actually verify behavior (not just mock behavior)?
    - Did I follow TDD if required?
    - Are tests comprehensive?

    If you find issues during self-review, fix them now before reporting.

    ## Report Format

    When done, report:
    - **Status:** DONE | DONE_WITH_CONCERNS | BLOCKED | NEEDS_CONTEXT
    - What you implemented (or what you attempted, if blocked)
    - What you tested and test results
    - Files changed
    - Task-owned untracked files, if any
    - Self-review findings (if any)
    - Any issues or concerns

    Use DONE_WITH_CONCERNS if you completed the work but have doubts about correctness.
    Use BLOCKED if you cannot complete the task. Use NEEDS_CONTEXT if you need
    information that wasn't provided. Never silently produce work you're unsure about.
    On BLOCKED or NEEDS_CONTEXT hand back three things together:
    the specific question or blocker, the evidence already gathered, and
    candidate options you considered with their trade-offs.
```
